# AutoNest — Second-Hand Vehicle Marketplace

AutoNest is a responsive, frontend-only marketplace for buying and selling pre-owned vehicles (cars, bikes, SUVs, sedans, hatchbacks). Buyers can search, filter, compare, and save vehicles, contact sellers, book test drives, and estimate EMIs. Sellers can list a vehicle with their own photos, save drafts, and manage listings and inquiries from a personal dashboard.

All data lives in the browser via `localStorage` — there is no backend, database, or payment system.

## Features

- **Homepage** — hero search with city picker, body-type categories, featured and recently added listings, trust highlights, and customer reviews.
- **Vehicle search & filtering** — search across brand, model, variant, and title; filter by vehicle type, fuel type, transmission, price presets or custom range, year presets (2026, 2025, 2024, 2023, 2022, Older) or custom from/to years, and city.
- **Sorting** — price low→high / high→low, year newest/oldest, mileage low/high.
- **Vehicle details** — photo gallery with thumbnails, full technical specs, inspection score breakdown, RTO/insurance info, seller profile, EMI calculator, and similar vehicles.
- **Contact seller** — inquiry, price offer, and test-drive booking dialog with validation.
- **Favorites** — save vehicles, persisted in the browser, with a dedicated favorites page.
- **Comparison** — compare up to 4 vehicles side by side with best-value highlighting and a floating comparison dock.
- **Sell your vehicle** — upload up to 10 photos (compressed in-browser), cover-photo badge, remove controls, form validation, draft saving, live preview, and publishing.
- **Auth (demo)** — register, login with Remember Me, forgot-password reset flow (6-digit code), and a user dashboard with active listings, received inquiries, and saved vehicles.
- **Accessibility** — labeled form controls, alt text on images, and toast feedback for actions.

## Tech Stack

- **React 19** + **TypeScript**
- **TanStack Start v1** (TanStack Router, file-based routing, SSR)
- **Vite 7** build tool
- **Tailwind CSS v4** + **shadcn/ui** (Radix primitives)
- **zod** for form validation, **sonner** for toasts
- **bun** as package manager (npm works too)

## Installation & Setup

```sh
git clone <repository-url>
cd autonest
bun install        # or: npm install
```

## Run / Build Commands

| Command | Description |
| --- | --- |
| `bun run dev` | Start the dev server (http://localhost:8080) |
| `bun run build` | Production build |
| `bun run preview` | Preview the production build |
| `bun run lint` | Run ESLint |
| `bun run test` | Run Vitest tests |

## Routes

| Path | Page |
| --- | --- |
| `/` | Homepage |
| `/vehicles` | Search, filter, sort, and browse listings |
| `/vehicles/:id` | Vehicle details |
| `/sell` | List a vehicle for sale |
| `/favorites` | Saved vehicles |
| `/compare` | Side-by-side comparison (up to 4) |
| `/login` | Sign in (Remember Me, Forgot password) |
| `/register` | Create account |
| `/forgot-password` | Reset password (demo code flow) |
| `/dashboard` | My listings, inquiries, saved vehicles |
| `/contact` | Contact page |
| `/about` | About AutoNest |
| `/terms` | Terms of use |
| `/privacy` | Privacy policy |
| `/inspection` | Inspection program info |
| `/emi-calculator` | Standalone EMI calculator |
| `/404` | Not found |

## Browser Storage (localStorage)

| Key | Contents |
| --- | --- |
| `favoriteVehicles` | Array of favorited vehicle IDs |
| `compareVehicles` | Array of vehicle IDs in the comparison dock (max 4) |
| `userData` | Demo session: logged-in user profile and remembered email |
| `sellerListings` | User-published vehicle listings |
| `autonest:inquiries` | Buyer inquiries / offers / test-drive requests |
| `autonest:sell-draft` | Saved draft of the sell form |

Data from earlier versions of the app is migrated automatically on first load, so existing favorites, comparisons, listings, and sessions are preserved.

## Project Structure

```text
src/
├── components/
│   ├── site/            # Navbar, VehicleCard, CompareDock, EmiCalculator,
│   │                    # ContactSellerDialog, PageHeader
│   └── ui/              # shadcn/ui primitives
├── hooks/               # Shared React hooks
├── lib/
│   ├── vehicles.ts      # Vehicle types, constants, 20 mock vehicles, helpers
│   └── store.tsx        # Global store (favorites, compare, session, listings)
├── routes/              # File-based routes (see Routes table)
├── styles.css           # Tailwind v4 theme tokens
└── test/                # Test setup
```

## Mock Data

- `src/lib/vehicles.ts` ships **20 detailed mock vehicles** (IDs `an-1001`…`an-1020`) covering the Indian used-vehicle market: hatchbacks, sedans, SUVs, EVs, and bikes, each with specs, pricing, mileage, inspection scores, RTO/insurance details, and seller info.
- Vehicle photos are stock image URLs; replace them with real inventory photos for production.
- Reviews, seller profiles, and legal page copy are placeholder content.

## Screenshots

> Replace these placeholders with real screenshots before release.

| Page | Screenshot |
| --- | --- |
| Homepage | `![Homepage](docs/screenshots/home.png)` |
| Vehicle search & filters | `![Search](docs/screenshots/search.png)` |
| Vehicle details | `![Details](docs/screenshots/details.png)` |
| Comparison | `![Compare](docs/screenshots/compare.png)` |
| Sell your vehicle | `![Sell](docs/screenshots/sell.png)` |
| Dashboard | `![Dashboard](docs/screenshots/dashboard.png)` |

## Notes & Limitations

- **Frontend-only demo:** authentication accepts any valid-looking email/password; nothing leaves the browser. Listings and inquiries are visible only on the device where they were created.
- No backend, database, or payment processing is included by design.
