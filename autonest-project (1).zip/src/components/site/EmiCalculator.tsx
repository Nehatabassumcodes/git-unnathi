import { useMemo, useState } from "react";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { emi, formatINR } from "@/lib/vehicles";

export function EmiCalculator({ price = 800000, schedule = false }: { price?: number; schedule?: boolean }) {
  const [amount, setAmount] = useState(Math.round(price * 0.8));
  const [rate, setRate] = useState(9.5);
  const [months, setMonths] = useState(48);
  const monthly = useMemo(() => emi(amount, rate, months), [amount, rate, months]);
  const total = monthly * months;
  const rows = useMemo(() => {
    if (!schedule) return [];
    const r = rate / 1200; let bal = amount; const out: { y: number; p: number; i: number; bal: number }[] = [];
    for (let y = 1; y <= Math.ceil(months / 12); y++) {
      let p = 0, i = 0;
      for (let m = 0; m < 12 && (y - 1) * 12 + m < months; m++) { const int = bal * r; const pr = monthly - int; i += int; p += pr; bal -= pr; }
      out.push({ y, p, i, bal: Math.max(0, bal) });
    }
    return out;
  }, [schedule, amount, rate, months, monthly]);

  const max = Math.max(2000000, Math.round(price * 1.2));
  return (
    <div className="rounded-xl border bg-card p-5">
      <h2 className="font-display text-lg font-semibold">EMI calculator</h2>
      <div className="mt-4 space-y-5">
        <div>
          <div className="flex justify-between text-sm"><Label id="amt">Loan amount</Label><span className="font-semibold">{formatINR(amount)}</span></div>
          <Slider aria-labelledby="amt" className="mt-2" min={50000} max={max} step={10000} value={[amount]} onValueChange={([v]) => setAmount(v)} />
        </div>
        <div>
          <div className="flex justify-between text-sm"><Label id="rate">Interest rate</Label><span className="font-semibold">{rate.toFixed(1)}%</span></div>
          <Slider aria-labelledby="rate" className="mt-2" min={6} max={20} step={0.1} value={[rate]} onValueChange={([v]) => setRate(v)} />
        </div>
        <div>
          <p className="text-sm font-medium">Tenure</p>
          <div className="mt-2 flex flex-wrap gap-2" role="radiogroup" aria-label="Tenure">
            {[12, 24, 36, 48, 60, 72, 84].map((m) => (
              <button key={m} role="radio" aria-checked={months === m} onClick={() => setMonths(m)} className={`rounded-md border px-3 py-1.5 text-sm ${months === m ? "border-primary bg-primary text-primary-foreground" : "hover:bg-muted"}`}>{m / 12} yr</button>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-5 rounded-lg bg-secondary p-4">
        <p className="text-sm text-muted-foreground">Monthly EMI</p>
        <p className="font-display text-3xl font-bold text-primary">₹{Math.round(monthly).toLocaleString("en-IN")}</p>
        <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
          <p>Total interest<br /><b>₹{Math.round(total - amount).toLocaleString("en-IN")}</b></p>
          <p>Total payable<br /><b>₹{Math.round(total).toLocaleString("en-IN")}</b></p>
        </div>
      </div>
      {schedule && (
        <div className="mt-5 overflow-x-auto">
          <table className="w-full text-sm">
            <caption className="mb-2 text-left font-semibold">Yearly amortization schedule</caption>
            <thead className="text-left text-muted-foreground"><tr><th className="py-2">Year</th><th>Principal</th><th>Interest</th><th>Balance</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.y} className="border-t"><td className="py-2">{r.y}</td><td>₹{Math.round(r.p).toLocaleString("en-IN")}</td><td>₹{Math.round(r.i).toLocaleString("en-IN")}</td><td>₹{Math.round(r.bal).toLocaleString("en-IN")}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
