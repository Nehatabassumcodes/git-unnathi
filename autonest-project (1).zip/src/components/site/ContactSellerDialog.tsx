import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import type { Vehicle } from "@/lib/vehicles";

type Kind = "inquiry" | "offer" | "testdrive";
const schema = z.object({
  name: z.string().trim().min(2, "Enter your name").max(80),
  phone: z.string().trim().regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit mobile number"),
  message: z.string().trim().max(500, "Max 500 characters"),
});

export function ContactSellerDialog({ v, open, onOpenChange, initial = "inquiry" }: { v: Vehicle; open: boolean; onOpenChange: (o: boolean) => void; initial?: Kind }) {
  const { user, addInquiry } = useStore();
  const [kind, setKind] = useState<Kind>(initial);
  const [form, setForm] = useState({ name: user?.name ?? "", phone: user?.phone ?? "", message: "", offer: "", date: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = schema.safeParse(form);
    const errs: Record<string, string> = {};
    if (!r.success) r.error.issues.forEach((i) => (errs[i.path[0] as string] = i.message));
    if (kind === "offer" && (!Number(form.offer) || Number(form.offer) < v.price * 0.5)) errs.offer = "Enter a reasonable offer amount";
    if (kind === "testdrive" && !form.date) errs.date = "Pick a preferred date";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    addInquiry({
      id: crypto.randomUUID(), vehicleId: v.id, vehicleTitle: v.title,
      kind: { inquiry: "Inquiry", offer: "Price offer", testdrive: "Test drive" }[kind],
      name: form.name, phone: form.phone, message: form.message,
      offer: kind === "offer" ? Number(form.offer) : undefined, date: kind === "testdrive" ? form.date : undefined,
      createdAt: new Date().toISOString(),
    });
    toast.success(kind === "testdrive" ? "Test drive requested" : kind === "offer" ? "Offer sent to seller" : "Message sent", { description: `${v.seller.name} will contact you shortly.` });
    onOpenChange(false);
  };
  const field = (id: keyof typeof form, label: string, props: React.ComponentProps<typeof Input> = {}) => (
    <div>
      <Label htmlFor={`cs-${id}`}>{label}</Label>
      <Input id={`cs-${id}`} value={form[id]} aria-invalid={!!errors[id]} aria-describedby={errors[id] ? `cs-${id}-err` : undefined} onChange={(e) => setForm({ ...form, [id]: e.target.value })} className="mt-1" {...props} />
      {errors[id] && <p id={`cs-${id}-err`} className="mt-1 text-xs text-destructive">{errors[id]}</p>}
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Contact {v.seller.name}</DialogTitle>
          <DialogDescription>{v.title}</DialogDescription>
        </DialogHeader>
        <Tabs value={kind} onValueChange={(k) => setKind(k as Kind)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="inquiry">Inquiry</TabsTrigger>
            <TabsTrigger value="offer">Make offer</TabsTrigger>
            <TabsTrigger value="testdrive">Test drive</TabsTrigger>
          </TabsList>
        </Tabs>
        <form onSubmit={submit} className="space-y-3" noValidate>
          {field("name", "Your name", { autoComplete: "name" })}
          {field("phone", "Mobile number", { inputMode: "numeric", maxLength: 10, autoComplete: "tel" })}
          {kind === "offer" && field("offer", "Your offer (₹)", { type: "number", inputMode: "numeric" })}
          {kind === "testdrive" && field("date", "Preferred date", { type: "date", min: new Date().toISOString().slice(0, 10) })}
          <div>
            <Label htmlFor="cs-message">Message (optional)</Label>
            <Textarea id="cs-message" className="mt-1" rows={3} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Is the price negotiable? Any service records?" />
            {errors.message && <p className="mt-1 text-xs text-destructive">{errors.message}</p>}
          </div>
          <Button type="submit" className="w-full">{kind === "testdrive" ? "Book test drive" : kind === "offer" ? "Send offer" : "Send message"}</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
