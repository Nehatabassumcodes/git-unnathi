import { Link } from "@tanstack/react-router";
import { Heart, GitCompare, ShieldCheck, BadgeCheck, Fuel, Gauge, Settings2, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { formatINR, formatKm, type Vehicle } from "@/lib/vehicles";
import { cn } from "@/lib/utils";

export function VehicleCard({ v, list }: { v: Vehicle; list?: boolean }) {
  const { favorites, compare, toggleFavorite, toggleCompare } = useStore();
  const fav = favorites.includes(v.id);
  const cmp = compare.includes(v.id);
  return (
    <article className={cn("group overflow-hidden rounded-xl border bg-card shadow-sm transition hover:shadow-md", list && "sm:flex")}>
      <Link to="/vehicles/$id" params={{ id: v.id }} className={cn("relative block aspect-[4/3] overflow-hidden bg-muted", list && "sm:w-72 sm:shrink-0")}>
        <img src={v.images[0]} alt={v.title} loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
        <div className="absolute left-2 top-2 flex flex-wrap gap-1">
          {v.inspected && <span className="inline-flex items-center gap-1 rounded-full bg-success px-2 py-0.5 text-xs font-semibold text-success-foreground"><ShieldCheck className="h-3 w-3" aria-hidden />Inspected {v.inspectionScore}</span>}
          <span className="rounded-full bg-background/90 px-2 py-0.5 text-xs font-semibold">{v.type}</span>
        </div>
      </Link>
      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-start justify-between gap-2">
          <Link to="/vehicles/$id" params={{ id: v.id }} className="font-display font-semibold leading-snug hover:text-primary">{v.title}</Link>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">{v.city}</p>
        <p className="mt-2 font-display text-2xl font-bold text-primary">{formatINR(v.price)}</p>
        <ul className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs text-muted-foreground">
          <li className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5" aria-hidden />{v.year}</li>
          <li className="flex items-center gap-1.5"><Gauge className="h-3.5 w-3.5" aria-hidden />{formatKm(v.km)}</li>
          <li className="flex items-center gap-1.5"><Fuel className="h-3.5 w-3.5" aria-hidden />{v.fuel}</li>
          <li className="flex items-center gap-1.5"><Settings2 className="h-3.5 w-3.5" aria-hidden />{v.transmission}</li>
        </ul>
        <p className="mt-3 flex items-center gap-1 text-xs font-medium">
          {v.seller.verified && <BadgeCheck className="h-3.5 w-3.5 text-primary" aria-hidden />}
          {v.seller.type === "Dealer" ? "Certified dealer" : "Individual seller"}
        </p>
        <div className="mt-4 flex gap-2 sm:mt-auto sm:pt-4">
          <Button asChild size="sm" className="flex-1"><Link to="/vehicles/$id" params={{ id: v.id }}>View details</Link></Button>
          <Button size="icon" variant={fav ? "default" : "outline"} className="h-9 w-9" aria-pressed={fav} aria-label={fav ? "Remove from favorites" : "Add to favorites"} onClick={() => toggleFavorite(v.id)}>
            <Heart className={cn("h-4 w-4", fav && "fill-current")} />
          </Button>
          <Button size="icon" variant={cmp ? "default" : "outline"} className="h-9 w-9" aria-pressed={cmp} aria-label={cmp ? "Remove from comparison" : "Add to comparison"} onClick={() => toggleCompare(v.id)}>
            <GitCompare className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </article>
  );
}

export function CompareDock() {
  const { compare, allVehicles, toggleCompare, clearCompare } = useStore();
  if (compare.length === 0) return null;
  const items = compare.map((id) => allVehicles.find((v) => v.id === id)).filter(Boolean) as Vehicle[];
  return (
    <div className="fixed inset-x-0 bottom-0 z-30 border-t bg-ink text-ink-foreground shadow-2xl" role="region" aria-label="Comparison dock">
      <div className="mx-auto flex max-w-7xl items-center gap-3 overflow-x-auto px-4 py-3">
        <span className="shrink-0 text-sm font-semibold">Compare ({items.length}/4)</span>
        {items.map((v) => (
          <div key={v.id} className="flex shrink-0 items-center gap-2 rounded-lg bg-ink-foreground/10 py-1 pl-1 pr-2">
            <img src={v.images[0]} alt="" className="h-9 w-12 rounded object-cover" />
            <span className="max-w-32 truncate text-xs">{v.brand} {v.model}</span>
            <button onClick={() => toggleCompare(v.id)} aria-label={`Remove ${v.title} from comparison`} className="text-lg leading-none opacity-70 hover:opacity-100">×</button>
          </div>
        ))}
        <div className="ml-auto flex shrink-0 gap-2">
          <Button size="sm" variant="ghost" onClick={clearCompare} className="text-ink-foreground hover:bg-ink-foreground/10 hover:text-ink-foreground">Clear</Button>
          <Button asChild size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" disabled={items.length < 2}><Link to="/compare">Compare now</Link></Button>
        </div>
      </div>
    </div>
  );
}

export function PageHeader({ title, sub }: { title: string; sub?: string }) {
  return (
    <div className="border-b bg-secondary/50">
      <div className="mx-auto max-w-7xl px-4 py-10">
        <h1 className="text-3xl font-bold md:text-4xl">{title}</h1>
        {sub && <p className="mt-2 max-w-2xl text-muted-foreground">{sub}</p>}
      </div>
    </div>
  );
}
