import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Heart, GitCompare, Menu, Search, User, Car } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useStore } from "@/lib/store";

const NAV = [
  { to: "/vehicles", label: "Buy" },
  { to: "/sell", label: "Sell" },
  { to: "/emi-calculator", label: "EMI" },
  { to: "/inspection", label: "Inspection" },
  { to: "/about", label: "About" },
] as const;

export function Navbar() {
  const { favorites, compare, user, logout } = useStore();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate({ to: "/vehicles", search: { q: q.trim() || undefined } });
    setOpen(false);
  };
  const Counter = ({ n }: { n: number }) =>
    n > 0 ? <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-accent px-1 text-[11px] font-bold text-accent-foreground">{n}</span> : null;

  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4">
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-primary text-primary-foreground"><Car className="h-5 w-5" aria-hidden /></span>
          Auto<span className="text-primary">Nest</span>
        </Link>
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground" activeProps={{ className: "text-foreground" }}>{n.label}</Link>
          ))}
        </nav>
        <form onSubmit={submit} className="relative ml-auto hidden max-w-xs flex-1 md:block" role="search">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input aria-label="Search vehicles" placeholder="Search brand, model…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
        </form>
        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <Button asChild variant="ghost" size="icon" className="relative" aria-label={`Favorites (${favorites.length})`}>
            <Link to="/favorites"><Heart className="h-5 w-5" /><Counter n={favorites.length} /></Link>
          </Button>
          <Button asChild variant="ghost" size="icon" className="relative" aria-label={`Compare (${compare.length})`}>
            <Link to="/compare"><GitCompare className="h-5 w-5" /><Counter n={compare.length} /></Link>
          </Button>
          <div className="hidden items-center gap-2 lg:flex">
            {user ? (
              <>
                <Button asChild variant="ghost" size="sm"><Link to="/dashboard"><User className="h-4 w-4" />{user.name.split(" ")[0]}</Link></Button>
                <Button variant="outline" size="sm" onClick={logout}>Sign out</Button>
              </>
            ) : (
              <Button asChild variant="ghost" size="sm"><Link to="/login">Sign in</Link></Button>
            )}
            <Button asChild size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90"><Link to="/sell">Sell your vehicle</Link></Button>
          </div>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open menu"><Menu className="h-5 w-5" /></Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <SheetTitle className="font-display">Menu</SheetTitle>
              <form onSubmit={submit} className="mt-4" role="search">
                <Input aria-label="Search vehicles" placeholder="Search vehicles…" value={q} onChange={(e) => setQ(e.target.value)} />
              </form>
              <nav className="mt-4 flex flex-col" aria-label="Mobile">
                {[...NAV, { to: "/favorites", label: "Favorites" }, { to: "/compare", label: "Compare" }, { to: "/contact", label: "Contact" }].map((n) => (
                  <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="rounded-md px-3 py-3 font-medium hover:bg-muted">{n.label}</Link>
                ))}
                {user ? (
                  <>
                    <Link to="/dashboard" onClick={() => setOpen(false)} className="rounded-md px-3 py-3 font-medium hover:bg-muted">Dashboard</Link>
                    <button onClick={() => { logout(); setOpen(false); }} className="rounded-md px-3 py-3 text-left font-medium hover:bg-muted">Sign out</button>
                  </>
                ) : (
                  <Link to="/login" onClick={() => setOpen(false)} className="rounded-md px-3 py-3 font-medium hover:bg-muted">Sign in</Link>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-20 bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="font-display text-xl font-bold">AutoNest</p>
          <p className="mt-2 text-sm opacity-75">India's trusted marketplace for certified pre-owned cars, bikes and SUVs. Zero commission for sellers.</p>
        </div>
        {[
          ["Marketplace", [["/vehicles", "Buy vehicles"], ["/sell", "Sell vehicle"], ["/compare", "Compare"], ["/emi-calculator", "EMI calculator"]]],
          ["Company", [["/about", "About us"], ["/inspection", "Inspection"], ["/contact", "Contact"]]],
          ["Legal", [["/terms", "Terms of use"], ["/privacy", "Privacy policy"]]],
        ].map(([h, links]) => (
          <div key={h as string}>
            <p className="font-semibold">{h as string}</p>
            <ul className="mt-3 space-y-2 text-sm opacity-80">
              {(links as string[][]).map(([to, l]) => <li key={to}><Link to={to} className="hover:underline">{l}</Link></li>)}
            </ul>
          </div>
        ))}
      </div>
      <p className="border-t border-ink-foreground/10 py-4 text-center text-xs opacity-60">© {2026} AutoNest. Demo marketplace.</p>
    </footer>
  );
}
