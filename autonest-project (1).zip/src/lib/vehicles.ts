export type VehicleType = "Car" | "Bike" | "SUV" | "Sedan" | "Hatchback";
export type Fuel = "Petrol" | "Diesel" | "Electric" | "CNG" | "Hybrid";
export type Transmission = "Manual" | "Automatic";

export interface Vehicle {
  id: string;
  title: string;
  brand: string;
  model: string;
  variant: string;
  type: VehicleType;
  fuel: Fuel;
  transmission: Transmission;
  price: number;
  year: number;
  regYear: number;
  km: number;
  city: string;
  owners: number;
  color: string;
  engine: string;
  power: string;
  mileage: string;
  seats: number;
  images: string[];
  inspectionScore: number;
  inspected: boolean;
  rto: string;
  insurance: string;
  insuranceValid: string;
  seller: { name: string; type: "Dealer" | "Individual"; rating: number; since: number; phone: string; verified: boolean };
  features: string[];
  description: string;
  featured?: boolean;
  addedDaysAgo: number;
}

export const VEHICLE_TYPES: VehicleType[] = ["Car", "Bike", "SUV", "Sedan", "Hatchback"];
export const FUELS: Fuel[] = ["Petrol", "Diesel", "Electric", "CNG", "Hybrid"];
export const TRANSMISSIONS: Transmission[] = ["Manual", "Automatic"];
export const CITIES = ["Mumbai", "Delhi", "Bengaluru", "Pune", "Hyderabad", "Chennai", "Ahmedabad", "Kolkata"];

const u = (id: string) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1200&q=70`;
const CAR = [
  "photo-1494976388531-d1058494cdd8",
  "photo-1503376780353-7e6692767b70",
  "photo-1552519507-da3b142c6e3d",
  "photo-1583121274602-3e2820c69888",
  "photo-1542362567-b07e54358753",
  "photo-1549317661-bd32c8ce0db2",
  "photo-1580273916550-e323be2ae537",
  "photo-1606664515524-ed2f786a0bd6",
];
const SUV = ["photo-1519641471654-76ce0107ad1b", "photo-1533473359331-0135ef1b58bf", "photo-1511919884226-fd3cad34687c", "photo-1617469767053-d3b523a0b982"];
const BIKE = ["photo-1558981806-ec527fa84c39", "photo-1568772585407-9361f9bf3a87", "photo-1609630875171-b1321377ee65"];

function pics(type: VehicleType, seed: number) {
  const pool = type === "Bike" ? BIKE : type === "SUV" ? SUV : CAR;
  return [0, 1, 2, 3].map((i) => u(pool[(seed + i) % pool.length]));
}

type Row = [string, string, string, VehicleType, Fuel, Transmission, number, number, number, string, string, string, string, number, number, boolean?];
// brand, model, variant, type, fuel, trans, price, year, km, city, engine, power, mileage, seats, score, featured
const ROWS: Row[] = [
  ["Maruti Suzuki", "Swift", "ZXi Plus", "Hatchback", "Petrol", "Manual", 625000, 2021, 28000, "Mumbai", "1197 cc", "89 bhp", "22.4 kmpl", 5, 92, true],
  ["Hyundai", "Creta", "SX (O) Turbo", "SUV", "Petrol", "Automatic", 1495000, 2022, 19500, "Bengaluru", "1398 cc", "138 bhp", "16.8 kmpl", 5, 95, true],
  ["Honda", "City", "VX CVT", "Sedan", "Petrol", "Automatic", 1125000, 2020, 41000, "Delhi", "1498 cc", "119 bhp", "18.4 kmpl", 5, 88, true],
  ["Tata", "Nexon EV", "Max XZ+ Lux", "SUV", "Electric", "Automatic", 1590000, 2023, 12000, "Pune", "40.5 kWh", "141 bhp", "437 km range", 5, 97, true],
  ["Royal Enfield", "Classic 350", "Signals", "Bike", "Petrol", "Manual", 175000, 2022, 9800, "Hyderabad", "349 cc", "20 bhp", "35 kmpl", 2, 90, true],
  ["Mahindra", "XUV700", "AX7 L Diesel", "SUV", "Diesel", "Automatic", 2350000, 2022, 34000, "Chennai", "2184 cc", "182 bhp", "15 kmpl", 7, 93, true],
  ["Toyota", "Innova Crysta", "2.4 VX", "SUV", "Diesel", "Manual", 1850000, 2019, 78000, "Ahmedabad", "2393 cc", "148 bhp", "13.6 kmpl", 7, 84],
  ["Maruti Suzuki", "Wagon R", "VXi CNG", "Hatchback", "CNG", "Manual", 465000, 2021, 52000, "Delhi", "998 cc", "56 bhp", "34 km/kg", 5, 86],
  ["Toyota", "Camry", "Hybrid", "Sedan", "Hybrid", "Automatic", 3250000, 2021, 30000, "Mumbai", "2487 cc", "215 bhp", "19.1 kmpl", 5, 96, true],
  ["Kia", "Seltos", "HTX Plus D", "SUV", "Diesel", "Manual", 1380000, 2021, 45000, "Kolkata", "1493 cc", "114 bhp", "20.8 kmpl", 5, 89],
  ["Hyundai", "i20", "Asta (O)", "Hatchback", "Petrol", "Manual", 745000, 2021, 26000, "Pune", "1197 cc", "82 bhp", "20.3 kmpl", 5, 91],
  ["Honda", "Activa 6G", "DLX", "Bike", "Petrol", "Automatic", 68000, 2022, 7400, "Bengaluru", "109 cc", "7.7 bhp", "50 kmpl", 2, 87],
  ["Bajaj", "Pulsar NS200", "ABS", "Bike", "Petrol", "Manual", 112000, 2021, 15200, "Chennai", "199 cc", "24 bhp", "36 kmpl", 2, 85],
  ["Skoda", "Slavia", "1.5 TSI Style DSG", "Sedan", "Petrol", "Automatic", 1450000, 2023, 11000, "Hyderabad", "1498 cc", "148 bhp", "19.4 kmpl", 5, 94],
  ["Volkswagen", "Virtus", "GT Plus", "Sedan", "Petrol", "Manual", 1390000, 2022, 21000, "Mumbai", "1498 cc", "148 bhp", "18.7 kmpl", 5, 90],
  ["Tata", "Tiago", "XZ Plus CNG", "Car", "CNG", "Manual", 595000, 2022, 31000, "Ahmedabad", "1199 cc", "72 bhp", "26.5 km/kg", 5, 88],
  ["Ather", "450X", "Gen 3", "Bike", "Electric", "Automatic", 118000, 2023, 5200, "Bengaluru", "3.7 kWh", "8.5 bhp", "146 km range", 2, 93],
  ["Mahindra", "Thar", "LX 4WD Hard Top", "SUV", "Diesel", "Manual", 1520000, 2021, 39000, "Delhi", "2184 cc", "130 bhp", "15.2 kmpl", 4, 87],
  ["Maruti Suzuki", "Baleno", "Alpha", "Car", "Petrol", "Automatic", 815000, 2022, 18000, "Kolkata", "1197 cc", "89 bhp", "22.9 kmpl", 5, 91],
  ["Hyundai", "Verna", "SX Diesel", "Sedan", "Diesel", "Manual", 895000, 2019, 64000, "Pune", "1493 cc", "113 bhp", "25 kmpl", 5, 82],
];

const SELLERS = [
  { name: "Prime Wheels Motors", type: "Dealer" as const, rating: 4.8, since: 2014 },
  { name: "Rahul Mehta", type: "Individual" as const, rating: 4.6, since: 2021 },
  { name: "AutoHub Certified", type: "Dealer" as const, rating: 4.9, since: 2011 },
  { name: "Priya Nair", type: "Individual" as const, rating: 4.7, since: 2022 },
];
const COLORS = ["Pearl White", "Midnight Black", "Fiery Red", "Silky Silver", "Ocean Blue", "Graphite Grey"];

export const VEHICLES: Vehicle[] = ROWS.map((r, i) => {
  const [brand, model, variant, type, fuel, transmission, price, year, km, city, engine, power, mileage, seats, score, featured] = r;
  const s = SELLERS[i % SELLERS.length];
  const stateCode = { Mumbai: "MH-02", Pune: "MH-12", Delhi: "DL-8C", Bengaluru: "KA-03", Hyderabad: "TS-09", Chennai: "TN-09", Ahmedabad: "GJ-01", Kolkata: "WB-02" }[city] ?? "MH-01";
  return {
    id: `an-${1001 + i}`,
    title: `${year} ${brand} ${model} ${variant}`,
    brand, model, variant, type, fuel, transmission, price, year,
    regYear: year, km, city,
    owners: (i % 3) + 1 > 2 ? 2 : (i % 3) + 1,
    color: COLORS[i % COLORS.length],
    engine, power, mileage, seats,
    images: pics(type, i),
    inspectionScore: score,
    inspected: score >= 85,
    rto: stateCode,
    insurance: i % 2 ? "Comprehensive" : "Zero Depreciation",
    insuranceValid: `${["Mar", "Jun", "Sep", "Dec"][i % 4]} ${2026 + (i % 2)}`,
    seller: { ...s, phone: `+91 98${(20000000 + i * 137531).toString().slice(0, 8)}`, verified: s.type === "Dealer" || i % 2 === 0 },
    features: type === "Bike"
      ? ["ABS", "Digital Console", "LED Headlamp", "USB Charging"].slice(0, 2 + (i % 3))
      : ["Touchscreen Infotainment", "Rear Camera", "Airbags", "Climate Control", "Cruise Control", "Sunroof", "Alloy Wheels", "Keyless Entry"].slice(0, 4 + (i % 5)),
    description: `Well-maintained ${brand} ${model} ${variant} with complete service history from authorised workshops. ${transmission} gearbox, ${fuel.toLowerCase()} powertrain and ${km.toLocaleString("en-IN")} km on the odometer. Single-hand driven in ${city}, no accidental history, all documents ready for transfer.`,
    featured: !!featured,
    addedDaysAgo: (i * 7) % 23,
  };
});

export const formatINR = (n: number) =>
  n >= 100000 ? `₹${(n / 100000).toFixed(2).replace(/\.?0+$/, "")} Lakh` : `₹${n.toLocaleString("en-IN")}`;
export const formatKm = (n: number) => `${n.toLocaleString("en-IN")} km`;

export function emi(principal: number, annualRate: number, months: number) {
  const r = annualRate / 12 / 100;
  if (r === 0) return principal / months;
  return (principal * r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1);
}
