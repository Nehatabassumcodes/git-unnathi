import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { VEHICLES, type Vehicle } from "./vehicles";

export interface User { name: string; email: string; phone?: string }
export interface Inquiry { id: string; vehicleId: string; vehicleTitle: string; kind: string; name: string; phone: string; message: string; offer?: number; date?: string; createdAt: string }

interface Store {
  hydrated: boolean;
  favorites: string[];
  compare: string[];
  user: User | null;
  listings: Vehicle[];
  inquiries: Inquiry[];
  allVehicles: Vehicle[];
  toggleFavorite: (id: string) => void;
  toggleCompare: (id: string) => void;
  clearCompare: () => void;
  login: (u: User, remember?: boolean) => void;
  logout: () => void;
  addListing: (v: Vehicle) => void;
  removeListing: (id: string) => void;
  addInquiry: (i: Inquiry) => void;
}

const Ctx = createContext<Store | null>(null);
const LEGACY_KEY = "autonest:v1";
const K = { fav: "favoriteVehicles", cmp: "compareVehicles", user: "userData", list: "sellerListings", inq: "autonest:inquiries", remember: "rememberMe" };

function read<T>(storage: Storage, key: string): T | undefined {
  try { const v = storage.getItem(key); return v ? (JSON.parse(v) as T) : undefined; } catch { return undefined; }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [favorites, setFav] = useState<string[]>([]);
  const [compare, setCompare] = useState<string[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [remember, setRemember] = useState(true);
  const [listings, setListings] = useState<Vehicle[]>([]);
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);

  useEffect(() => {
    const legacy = read<Record<string, any>>(localStorage, LEGACY_KEY) ?? {};
    setFav(read(localStorage, K.fav) ?? legacy.favorites ?? []);
    setCompare(read(localStorage, K.cmp) ?? legacy.compare ?? []);
    const rem = read<boolean>(localStorage, K.remember) ?? true;
    setRemember(rem);
    setUser(read(localStorage, K.user) ?? read(sessionStorage, K.user) ?? legacy.user ?? null);
    setListings(read(localStorage, K.list) ?? legacy.listings ?? []);
    setInquiries(read(localStorage, K.inq) ?? legacy.inquiries ?? []);
    try { localStorage.removeItem(LEGACY_KEY); } catch { /* ignore */ }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(K.fav, JSON.stringify(favorites));
      localStorage.setItem(K.cmp, JSON.stringify(compare));
      localStorage.setItem(K.list, JSON.stringify(listings));
      localStorage.setItem(K.inq, JSON.stringify(inquiries));
      localStorage.setItem(K.remember, JSON.stringify(remember));
      localStorage.removeItem(K.user); sessionStorage.removeItem(K.user);
      if (user) (remember ? localStorage : sessionStorage).setItem(K.user, JSON.stringify(user));
    } catch {
      toast.error("Storage is full — try fewer or smaller photos.");
    }
  }, [hydrated, favorites, compare, user, remember, listings, inquiries]);

  const value: Store = {
    hydrated, favorites, compare, user, listings, inquiries,
    allVehicles: [...listings, ...VEHICLES],
    toggleFavorite: (id) =>
      setFav((f) => {
        if (f.includes(id)) { toast("Removed from favorites"); return f.filter((x) => x !== id); }
        toast.success("Saved to favorites"); return [...f, id];
      }),
    toggleCompare: (id) =>
      setCompare((c) => {
        if (c.includes(id)) return c.filter((x) => x !== id);
        if (c.length >= 4) { toast.error("You can compare up to 4 vehicles"); return c; }
        toast.success("Added to comparison"); return [...c, id];
      }),
    clearCompare: () => setCompare([]),
    login: (u, rem = true) => { setRemember(rem); setUser(u); },
    logout: () => { setUser(null); toast("Signed out"); },
    addListing: (v) => setListings((l) => [v, ...l]),
    removeListing: (id) => setListings((l) => l.filter((x) => x.id !== id)),
    addInquiry: (i) => setInquiries((q) => [i, ...q]),
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useStore outside provider");
  return c;
}
