import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Heart, GitCompare, ShieldCheck, BadgeCheck, Phone, Star, MapPin, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { EmiCalculator } from "@/components/site/EmiCalculator";
import { ContactSellerDialog } from "@/components/site/ContactSellerDialog";
import { VehicleCard } from "@/components/site/VehicleCard";
import { useStore } from "@/lib/store";
import { VEHICLES, formatINR, formatKm } from "@/lib/vehicles";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/vehicles/$id")({
  head: ({ params }) => {
    const v = VEHICLES.find((x) => x.id === params.id);
    const t = v ? `${v.title} for ${formatINR(v.price)} — AutoNest` : "Vehicle details — AutoNest";
    const d = v ? `${v.year} ${v.brand} ${v.model}, ${formatKm(v.km)}, ${v.fuel}, ${v.transmission} in ${v.city}. Inspection score ${v.inspectionScore}/100.` : "Pre-owned vehicle details on AutoNest.";
    return {
      meta: [
        { title: t }, { name: "description", content: d },
        { property: "og:title", content: t }, { property: "og:description", content: d },
        ...(v ? [{ property: "og:image", content: v.images[0] }, { name: "twitter:image", content: v.images[0] }] : []),
      ],
    };
  },
  component: Details,
});

function Details() {
  const { id } = Route.useParams();
  const { allVehicles, hydrated, favorites, compare, toggleFavorite, toggleCompare } = useStore();
  const v = allVehicles.find((x) => x.id === id);
  const [img, setImg] = useState(0);
  const [contact, setContact] = useState<null | "inquiry" | "offer" | "testdrive">(null);

  if (!v) {
    if (!hydrated) return <div className="p-20 text-center text-muted-foreground">Loading…</div>;
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <h1 className="text-2xl font-bold">Vehicle not found</h1>
        <p className="mt-2 text-muted-foreground">This listing may have been sold or removed.</p>
        <Button asChild className="mt-6"><Link to="/vehicles">Browse vehicles</Link></Button>
      </div>
    );
  }
  const fav = favorites.includes(v.id);
  const cmp = compare.includes(v.id);
  const similar = allVehicles.filter((x) => x.type === v.type && x.id !== v.id).slice(0, 3);
  const specs: [string, string | number][] = [
    ["Brand", v.brand], ["Model", v.model], ["Variant", v.variant], ["Body type", v.type], ["Fuel", v.fuel], ["Transmission", v.transmission],
    ["Engine", v.engine], ["Power", v.power], ["Mileage", v.mileage], ["Seats", v.seats], ["Manufacturing year", v.year], ["Registration year", v.regYear],
    ["Kilometers", formatKm(v.km)], ["Owners", v.owners === 1 ? "1st owner" : `${v.owners}nd owner`], ["Colour", v.color], ["City", v.city],
  ];
  const checks = [["Engine & transmission", Math.min(100, v.inspectionScore + 2)], ["Body & paint", v.inspectionScore - 4], ["Interior", v.inspectionScore - 1], ["Electricals", Math.min(100, v.inspectionScore + 3)], ["Tyres & brakes", v.inspectionScore - 6]] as const;

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <Link to="/vehicles" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ChevronLeft className="h-4 w-4" />Back to listings</Link>
      <div className="mt-4 grid gap-8 lg:grid-cols-[1fr_380px]">
        <div className="min-w-0">
          <div className="overflow-hidden rounded-xl bg-muted">
            <img src={v.images[img]} alt={`${v.title} — photo ${img + 1} of ${v.images.length}`} className="aspect-[16/10] w-full object-cover" />
          </div>
          <div className="mt-3 grid grid-cols-4 gap-2 sm:grid-cols-6" role="tablist" aria-label="Photo thumbnails">
            {v.images.map((src, i) => (
              <button key={i} role="tab" aria-selected={img === i} aria-label={`Show photo ${i + 1}`} onClick={() => setImg(i)} className={cn("overflow-hidden rounded-lg border-2", img === i ? "border-primary" : "border-transparent opacity-70 hover:opacity-100")}>
                <img src={src} alt="" className="aspect-[4/3] w-full object-cover" />
              </button>
            ))}
          </div>

          <section className="mt-8">
            <h2 className="text-xl font-bold">Technical specifications</h2>
            <dl className="mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-xl border bg-border sm:grid-cols-4">
              {specs.map(([k, val]) => (
                <div key={k} className="bg-card p-3"><dt className="text-xs text-muted-foreground">{k}</dt><dd className="font-semibold">{val}</dd></div>
              ))}
            </dl>
          </section>

          <section className="mt-8 grid gap-6 md:grid-cols-2">
            <div className="rounded-xl border bg-card p-5">
              <h2 className="flex items-center gap-2 text-lg font-bold"><ShieldCheck className="h-5 w-5 text-success" aria-hidden />Inspection report</h2>
              <p className="mt-2"><span className="font-display text-4xl font-bold text-success">{v.inspectionScore}</span><span className="text-muted-foreground">/100</span></p>
              <ul className="mt-4 space-y-3">
                {checks.map(([k, s]) => (
                  <li key={k}><div className="flex justify-between text-sm"><span>{k}</span><span className="font-semibold">{s}</span></div><Progress value={s} className="mt-1 h-1.5" aria-label={`${k} score`} /></li>
                ))}
              </ul>
            </div>
            <div className="rounded-xl border bg-card p-5">
              <h2 className="text-lg font-bold">RTO & insurance</h2>
              <dl className="mt-3 space-y-2 text-sm">
                {[["RTO", v.rto], ["Registration", `${v.regYear}, ${v.city}`], ["Ownership", `${v.owners} owner(s)`], ["Insurance type", v.insurance], ["Insurance valid till", v.insuranceValid], ["Hypothecation", "None — clear title"]].map(([k, val]) => (
                  <div key={k} className="flex justify-between border-b pb-2 last:border-0"><dt className="text-muted-foreground">{k}</dt><dd className="font-medium">{val}</dd></div>
                ))}
              </dl>
            </div>
          </section>

          <section className="mt-8">
            <h2 className="text-xl font-bold">About this vehicle</h2>
            <p className="mt-2 text-muted-foreground">{v.description}</p>
            <ul className="mt-4 flex flex-wrap gap-2">{v.features.map((f) => <li key={f} className="rounded-full bg-secondary px-3 py-1 text-sm">{f}</li>)}</ul>
          </section>
        </div>

        <aside className="space-y-6 lg:sticky lg:top-20 lg:self-start">
          <div className="rounded-xl border bg-card p-5">
            <h1 className="text-xl font-bold leading-snug">{v.title}</h1>
            <p className="mt-1 flex items-center gap-1 text-sm text-muted-foreground"><MapPin className="h-4 w-4" aria-hidden />{v.city} · {formatKm(v.km)} · {v.fuel}</p>
            <p className="mt-3 font-display text-3xl font-bold text-primary">{formatINR(v.price)}</p>
            <p className="text-xs text-muted-foreground">Fixed on-road price · Zero buyer fees</p>
            <div className="mt-4 grid gap-2">
              <Button onClick={() => setContact("inquiry")}>Contact seller</Button>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={() => setContact("offer")}>Make offer</Button>
                <Button variant="outline" onClick={() => setContact("testdrive")}>Book test drive</Button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="ghost" aria-pressed={fav} onClick={() => toggleFavorite(v.id)}><Heart className={cn("h-4 w-4", fav && "fill-current text-destructive")} />{fav ? "Saved" : "Save"}</Button>
                <Button variant="ghost" aria-pressed={cmp} onClick={() => toggleCompare(v.id)}><GitCompare className="h-4 w-4" />{cmp ? "In compare" : "Compare"}</Button>
              </div>
            </div>
          </div>
          <div className="rounded-xl border bg-card p-5">
            <h2 className="font-display font-semibold">Seller</h2>
            <div className="mt-3 flex items-center gap-3">
              <div className="grid h-12 w-12 place-items-center rounded-full bg-primary font-display text-lg font-bold text-primary-foreground" aria-hidden>{v.seller.name[0]}</div>
              <div>
                <p className="flex items-center gap-1 font-semibold">{v.seller.name}{v.seller.verified && <BadgeCheck className="h-4 w-4 text-primary" aria-label="Verified" />}</p>
                <p className="text-sm text-muted-foreground">{v.seller.type === "Dealer" ? "Certified dealer" : "Individual seller"} · since {v.seller.since}</p>
              </div>
            </div>
            <p className="mt-3 flex items-center gap-1 text-sm"><Star className="h-4 w-4 fill-accent text-accent" aria-hidden />{v.seller.rating} seller rating</p>
            <p className="mt-1 flex items-center gap-1 text-sm text-muted-foreground"><Phone className="h-4 w-4" aria-hidden />{v.seller.phone.slice(0, 8)}••••• (shared after inquiry)</p>
          </div>
          <EmiCalculator price={v.price} />
        </aside>
      </div>

      {similar.length > 0 && (
        <section className="mt-14">
          <h2 className="text-xl font-bold">Similar {v.type.toLowerCase()}s</h2>
          <div className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{similar.map((s) => <VehicleCard key={s.id} v={s} />)}</div>
        </section>
      )}
      {contact && <ContactSellerDialog key={contact} v={v} initial={contact} open onOpenChange={(o) => !o && setContact(null)} />}
    </div>
  );
}
