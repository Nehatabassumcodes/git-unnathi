import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/VehicleCard";
import { EmiCalculator } from "@/components/site/EmiCalculator";
function Page() { return <><PageHeader title="EMI calculator" sub="Plan your vehicle loan." /><div className="mx-auto max-w-2xl px-4 py-10"><EmiCalculator price={800000} schedule /></div></>; }
export const Route = createFileRoute("/emi-calculator")({
  head: () => ({ meta: [{ title: "EMI Calculator — AutoNest" }, { name: "description", content: "Calculate monthly loan EMI and amortization for a used vehicle." }, { property: "og:title", content: "EMI Calculator — AutoNest" }, { property: "og:description", content: "Calculate monthly loan EMI and amortization for a used vehicle." }] }),
  component: Page,
});
