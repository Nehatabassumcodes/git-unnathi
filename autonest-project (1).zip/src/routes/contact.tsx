import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/site/VehicleCard";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [{ title: "Contact Us — AutoNest" }, { name: "description", content: "Get help with buying, selling or financing a vehicle." }, { property: "og:title", content: "Contact Us — AutoNest" }, { property: "og:description", content: "Reach the AutoNest support team." }] }),
  component: Contact,
});

function Contact() {
  const [f, setF] = useState({ name: "", email: "", message: "" });
  const [err, setErr] = useState<Record<string, string>>({});
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const x: Record<string, string> = {};
    if (f.name.trim().length < 2) x.name = "Enter your name";
    if (!/^\S+@\S+\.\S+$/.test(f.email)) x.email = "Enter a valid email";
    if (f.message.trim().length < 10) x.message = "At least 10 characters";
    setErr(x);
    if (Object.keys(x).length) return;
    toast.success("Message sent — we'll reply within 24 hours");
    setF({ name: "", email: "", message: "" });
  };
  return (
    <>
      <PageHeader title="Contact us" sub="We usually reply within a day." />
      <form onSubmit={submit} noValidate className="mx-auto max-w-lg space-y-4 px-4 py-10">
        {(["name", "email"] as const).map((k) => (
          <div key={k}><Label htmlFor={k} className="capitalize">{k}</Label><Input id={k} type={k === "email" ? "email" : "text"} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} aria-invalid={!!err[k]} className="mt-1" />{err[k] && <p className="mt-1 text-xs text-destructive">{err[k]}</p>}</div>
        ))}
        <div><Label htmlFor="message">Message</Label><Textarea id="message" rows={5} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} aria-invalid={!!err.message} className="mt-1" />{err.message && <p className="mt-1 text-xs text-destructive">{err.message}</p>}</div>
        <Button type="submit" className="w-full">Send message</Button>
      </form>
    </>
  );
}
