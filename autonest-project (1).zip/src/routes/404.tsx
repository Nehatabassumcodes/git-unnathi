import { createFileRoute } from "@tanstack/react-router";
import { NotFoundComponent } from "./__root";
export const Route = createFileRoute("/404")({
  head: () => ({ meta: [{ title: "Page Not Found — AutoNest" }, { name: "description", content: "This page doesn't exist." }, { property: "og:title", content: "Page Not Found — AutoNest" }, { property: "og:description", content: "This page doesn't exist." }] }),
  component: NotFoundComponent,
});
