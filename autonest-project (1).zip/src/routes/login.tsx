import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign In — AutoNest" }, { name: "description", content: "Sign in to manage listings and inquiries." }, { property: "og:title", content: "Sign In — AutoNest" }, { property: "og:description", content: "Sign in to AutoNest." }] }),
  component: () => <AuthForm mode="login" />,
});

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const { login } = useStore();
  const navigate = useNavigate();
  const [f, setF] = useState({ name: "", email: "", phone: "", password: "" });
  const [remember, setRemember] = useState(true);
  const [err, setErr] = useState<Record<string, string>>({});
  useEffect(() => {
    const saved = localStorage.getItem("rememberedEmail");
    if (saved && mode === "login") setF((p) => ({ ...p, email: saved }));
  }, [mode]);
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const x: Record<string, string> = {};
    if (mode === "register" && f.name.trim().length < 2) x.name = "Enter your name";
    if (!/^\S+@\S+\.\S+$/.test(f.email)) x.email = "Enter a valid email";
    if (mode === "register" && !/^[6-9]\d{9}$/.test(f.phone)) x.phone = "Enter a valid 10-digit mobile";
    if (f.password.length < 6) x.password = "At least 6 characters";
    setErr(x);
    if (Object.keys(x).length) return;
    if (remember) localStorage.setItem("rememberedEmail", f.email);
    else localStorage.removeItem("rememberedEmail");
    login({ name: f.name.trim() || f.email.split("@")[0], email: f.email, phone: f.phone || undefined }, remember);
    toast.success(mode === "login" ? "Welcome back!" : "Account created");
    navigate({ to: "/dashboard" });
  };
  const fld = (k: keyof typeof f, label: string, type = "text") => (
    <div>
      <Label htmlFor={k}>{label}</Label>
      <Input id={k} type={type} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} aria-invalid={!!err[k]} className="mt-1" />
      {err[k] && <p className="mt-1 text-xs text-destructive">{err[k]}</p>}
    </div>
  );
  return (
    <div className="mx-auto max-w-sm px-4 py-16">
      <h1 className="text-3xl font-bold">{mode === "login" ? "Sign in" : "Create account"}</h1>
      <p className="mt-1 text-sm text-muted-foreground">Demo only — details stay in this browser.</p>
      <form onSubmit={submit} noValidate className="mt-6 space-y-4">
        {mode === "register" && fld("name", "Full name")}
        {fld("email", "Email", "email")}
        {mode === "register" && fld("phone", "Mobile number", "tel")}
        {fld("password", "Password", "password")}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Checkbox id="remember" checked={remember} onCheckedChange={(c) => setRemember(c === true)} />
            <Label htmlFor="remember" className="font-normal">Remember me</Label>
          </div>
          {mode === "login" && <Link to="/forgot-password" className="text-sm font-semibold text-primary">Forgot password?</Link>}
        </div>
        <Button type="submit" className="w-full">{mode === "login" ? "Sign in" : "Register"}</Button>
      </form>
      <p className="mt-4 text-center text-sm">
        {mode === "login" ? <>New here? <Link to="/register" className="font-semibold text-primary">Create an account</Link></> : <>Have an account? <Link to="/login" className="font-semibold text-primary">Sign in</Link></>}
      </p>
    </div>
  );
}
