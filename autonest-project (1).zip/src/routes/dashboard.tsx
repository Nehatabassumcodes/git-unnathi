import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PageHeader, VehicleCard } from "@/components/site/VehicleCard";
import { useStore } from "@/lib/store";
import { formatINR } from "@/lib/vehicles";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "My Dashboard — AutoNest" }, { name: "description", content: "Your listings, inquiries and saved vehicles." }, { property: "og:title", content: "My Dashboard — AutoNest" }, { property: "og:description", content: "Manage your AutoNest activity." }] }),
  component: Dashboard,
});

function Dashboard() {
  const { user, hydrated, listings, inquiries, favorites, allVehicles, removeListing } = useStore();
  if (!hydrated) return null;
  if (!user) return (
    <div className="mx-auto max-w-md px-4 py-24 text-center">
      <h1 className="text-2xl font-bold">Sign in to view your dashboard</h1>
      <Button asChild className="mt-6"><Link to="/login">Sign in</Link></Button>
    </div>
  );
  const favs = allVehicles.filter((v) => favorites.includes(v.id));
  return (
    <>
      <PageHeader title={`Hi, ${user.name}`} sub={user.email} />
      <div className="mx-auto max-w-7xl space-y-12 px-4 py-8">
        <div className="grid gap-4 sm:grid-cols-3">
          {[["Active listings", listings.length], ["Inquiries", inquiries.length], ["Saved", favs.length]].map(([l, n]) => (
            <div key={l} className="rounded-xl border bg-card p-5"><p className="text-sm text-muted-foreground">{l}</p><p className="font-display text-3xl font-bold">{n}</p></div>
          ))}
        </div>
        <section>
          <div className="flex items-center justify-between"><h2 className="text-xl font-bold">My listings</h2><Button asChild size="sm"><Link to="/sell">New listing</Link></Button></div>
          {listings.length === 0 ? <p className="mt-3 text-muted-foreground">No listings yet.</p> : (
            <div className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {listings.map((v) => <div key={v.id}><VehicleCard v={v} /><Button variant="ghost" size="sm" className="mt-1 text-destructive" onClick={() => removeListing(v.id)}>Remove listing</Button></div>)}
            </div>
          )}
        </section>
        <section>
          <h2 className="text-xl font-bold">Inquiries</h2>
          {inquiries.length === 0 ? <p className="mt-3 text-muted-foreground">No inquiries yet.</p> : (
            <ul className="mt-4 divide-y rounded-xl border bg-card">
              {inquiries.map((q) => (
                <li key={q.id} className="p-4 text-sm">
                  <p className="font-semibold">{q.kind} · <Link to="/vehicles/$id" params={{ id: q.vehicleId }} className="text-primary">{q.vehicleTitle}</Link></p>
                  <p className="text-muted-foreground">{q.name} · {q.phone} · {new Date(q.createdAt).toLocaleDateString("en-IN")}{q.offer ? ` · Offer ${formatINR(q.offer)}` : ""}{q.date ? ` · Test drive ${q.date}` : ""}</p>
                  {q.message && <p className="mt-1">{q.message}</p>}
                </li>
              ))}
            </ul>
          )}
        </section>
        <section>
          <h2 className="text-xl font-bold">Saved vehicles</h2>
          {favs.length === 0 ? <p className="mt-3 text-muted-foreground">Nothing saved yet.</p> : <div className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{favs.map((v) => <VehicleCard key={v.id} v={v} />)}</div>}
        </section>
      </div>
    </>
  );
}
