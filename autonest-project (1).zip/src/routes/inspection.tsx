import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/VehicleCard";
const A = [["Engine & transmission","Compression, leaks, gear shifts, clutch"],["Body & paint","Panel gaps, repaint, rust, accident signs"],["Interior","Upholstery, AC, infotainment, controls"],["Electricals","Battery, lights, sensors, wiring"],["Tyres & brakes","Tread depth, pads, discs, alignment"],["Documents","RC, insurance, PUC, loan clearance"]];
function Page() { return <><PageHeader title="200-point inspection" sub="Certified vehicles are scored out of 100 by trained engineers." /><div className="mx-auto grid max-w-5xl gap-4 px-4 py-10 sm:grid-cols-2 lg:grid-cols-3">{A.map(([t,d]) => <div key={t} className="rounded-xl border bg-card p-5"><h2 className="font-semibold">{t}</h2><p className="mt-1 text-sm text-muted-foreground">{d}</p></div>)}</div></>; }
export const Route = createFileRoute("/inspection")({
  head: () => ({ meta: [{ title: "200-Point Vehicle Inspection — AutoNest" }, { name: "description", content: "What AutoNest inspects before certifying a pre-owned vehicle." }, { property: "og:title", content: "200-Point Vehicle Inspection — AutoNest" }, { property: "og:description", content: "What AutoNest inspects before certifying a pre-owned vehicle." }] }),
  component: Page,
});
