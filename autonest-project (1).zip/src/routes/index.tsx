import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Search, ShieldCheck, BadgePercent, FileCheck2, Headphones, Star, Car, Bike, Truck, CarFront, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { VehicleCard } from "@/components/site/VehicleCard";
import { VEHICLES, VEHICLE_TYPES, CITIES, type VehicleType } from "@/lib/vehicles";
import { useStore } from "@/lib/store";

const HERO = "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1920&q=70";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AutoNest — Buy & Sell Certified Pre-Owned Vehicles in India" },
      { name: "description", content: "Search inspected second-hand cars, bikes and SUVs, compare models, calculate EMI and sell with zero commission." },
      { property: "og:title", content: "AutoNest — Certified Pre-Owned Vehicles" },
      { property: "og:description", content: "Inspected used cars, bikes and SUVs across India with zero-commission selling." },
      { property: "og:image", content: HERO },
      { name: "twitter:image", content: HERO },
    ],
  }),
  component: Home,
});

const TYPE_ICON: Record<VehicleType, typeof Car> = { Car: Car, Bike: Bike, SUV: Truck, Sedan: CarFront, Hatchback: Gauge };

function Home() {
  const navigate = useNavigate();
  const { listings } = useStore();
  const [q, setQ] = useState("");
  const [city, setCity] = useState("");
  const featured = VEHICLES.filter((v) => v.featured).slice(0, 6);
  const recent = [...listings, ...[...VEHICLES].sort((a, b) => a.addedDaysAgo - b.addedDaysAgo)].slice(0, 4);

  return (
    <>
      <section className="relative isolate overflow-hidden bg-ink text-ink-foreground">
        <img src={HERO} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover opacity-35" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink via-ink/85 to-ink/30" />
        <div className="mx-auto max-w-7xl px-4 py-20 md:py-28">
          <p className="inline-flex items-center gap-2 rounded-full bg-accent/20 px-3 py-1 text-sm font-semibold text-accent"><ShieldCheck className="h-4 w-4" aria-hidden />200-point inspected vehicles</p>
          <h1 className="mt-5 max-w-2xl text-4xl font-extrabold leading-tight md:text-6xl">Your next ride, already road-tested.</h1>
          <p className="mt-4 max-w-xl text-lg opacity-80">Verified pre-owned cars, bikes and SUVs from trusted dealers and owners across India.</p>
          <form
            role="search"
            onSubmit={(e) => { e.preventDefault(); navigate({ to: "/vehicles", search: { q: q.trim() || undefined, city: city || undefined } }); }}
            className="mt-8 flex max-w-2xl flex-col gap-2 rounded-xl bg-card p-2 text-card-foreground shadow-2xl sm:flex-row"
          >
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
              <Input aria-label="Search by brand, model or variant" placeholder="Try “Creta”, “Swift ZXi”, “Classic 350”" value={q} onChange={(e) => setQ(e.target.value)} className="h-12 border-0 pl-9 shadow-none focus-visible:ring-0" />
            </div>
            <select aria-label="City" value={city} onChange={(e) => setCity(e.target.value)} className="h-12 rounded-md border-0 bg-muted px-3 text-sm">
              <option value="">All cities</option>
              {CITIES.map((c) => <option key={c}>{c}</option>)}
            </select>
            <Button type="submit" size="lg" className="h-12 bg-accent text-accent-foreground hover:bg-accent/90">Search</Button>
          </form>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14" aria-labelledby="types">
        <h2 id="types" className="text-2xl font-bold">Browse by body type</h2>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {VEHICLE_TYPES.map((t) => {
            const Icon = TYPE_ICON[t];
            return (
              <Link key={t} to="/vehicles" search={{ type: t }} className="group rounded-xl border bg-card p-5 transition hover:border-primary hover:shadow-md">
                <Icon className="h-8 w-8 text-primary" aria-hidden />
                <p className="mt-3 font-display font-semibold">{t}</p>
                <p className="text-sm text-muted-foreground">{VEHICLES.filter((v) => v.type === t).length} listings</p>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-6" aria-labelledby="featured">
        <div className="flex items-end justify-between">
          <h2 id="featured" className="text-2xl font-bold">Featured vehicles</h2>
          <Link to="/vehicles" className="text-sm font-semibold text-primary hover:underline">View all →</Link>
        </div>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{featured.map((v) => <VehicleCard key={v.id} v={v} />)}</div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14" aria-labelledby="recent">
        <h2 id="recent" className="text-2xl font-bold">Recently added</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">{recent.map((v) => <VehicleCard key={v.id} v={v} />)}</div>
      </section>

      <section className="bg-secondary/60 py-14" aria-labelledby="trust">
        <div className="mx-auto max-w-7xl px-4">
          <h2 id="trust" className="text-2xl font-bold">Why buyers trust AutoNest</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              [ShieldCheck, "200-point inspection", "Every certified vehicle is checked by trained engineers."],
              [FileCheck2, "Verified RTO papers", "Registration, insurance and ownership validated."],
              [BadgePercent, "Zero commission", "Sellers keep 100% of the sale price."],
              [Headphones, "Buyer support", "Help with financing, transfer and test drives."],
            ].map(([Icon, t, d]) => {
              const I = Icon as typeof ShieldCheck;
              return (
                <div key={t as string} className="rounded-xl bg-card p-5">
                  <I className="h-7 w-7 text-primary" aria-hidden />
                  <p className="mt-3 font-display font-semibold">{t as string}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{d as string}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14" aria-labelledby="reviews">
        <h2 id="reviews" className="text-2xl font-bold">What our customers say</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {[
            ["Ankit S., Pune", "Bought a Nexon EV with a 97 inspection score. The report matched the car exactly — zero surprises."],
            ["Meera K., Bengaluru", "Listed my i20 on a Monday, had three test drives by Thursday. No commission at all."],
            ["Farhan A., Mumbai", "The comparison tool helped me pick between Creta and Seltos in minutes."],
          ].map(([n, t]) => (
            <figure key={n} className="rounded-xl border bg-card p-6">
              <div className="flex gap-0.5 text-accent" aria-label="5 out of 5 stars">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" aria-hidden />)}</div>
              <blockquote className="mt-3 text-sm">“{t}”</blockquote>
              <figcaption className="mt-3 text-sm font-semibold">{n}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4">
        <div className="flex flex-col items-start justify-between gap-4 rounded-2xl bg-primary p-8 text-primary-foreground md:flex-row md:items-center">
          <div>
            <h2 className="text-2xl font-bold">Selling your vehicle?</h2>
            <p className="mt-1 opacity-85">List in 5 minutes. Reach thousands of verified buyers.</p>
          </div>
          <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90"><Link to="/sell">Start listing</Link></Button>
        </div>
      </section>
    </>
  );
}
