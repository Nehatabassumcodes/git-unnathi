import { createFileRoute, Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader, VehicleCard } from "@/components/site/VehicleCard";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/favorites")({
  head: () => ({
    meta: [
      { title: "Your Saved Vehicles — AutoNest" },
      { name: "description", content: "Vehicles you've saved on AutoNest, kept on this device." },
      { property: "og:title", content: "Saved vehicles — AutoNest" },
      { property: "og:description", content: "Your shortlist of pre-owned vehicles." },
    ],
  }),
  component: () => {
    const { favorites, allVehicles, hydrated } = useStore();
    const items = allVehicles.filter((v) => favorites.includes(v.id));
    return (
      <>
        <PageHeader title="Favorites" sub="Your shortlist, saved on this device." />
        <div className="mx-auto max-w-7xl px-4 py-8">
          {hydrated && items.length === 0 ? (
            <div className="rounded-xl border border-dashed p-12 text-center">
              <Heart className="mx-auto h-10 w-10 text-muted-foreground" aria-hidden />
              <p className="mt-3 font-display text-lg font-semibold">No favorites yet</p>
              <p className="text-sm text-muted-foreground">Tap the heart on any vehicle to save it here.</p>
              <Button asChild className="mt-5"><Link to="/vehicles">Browse vehicles</Link></Button>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{items.map((v) => <VehicleCard key={v.id} v={v} />)}</div>
          )}
        </div>
      </>
    );
  },
});
