import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/VehicleCard";
function Page() { return <><PageHeader title="About AutoNest" sub="Making pre-owned vehicles trustworthy." /><div className="mx-auto max-w-3xl space-y-4 px-4 py-10 text-muted-foreground"><p>AutoNest is a marketplace for certified pre-owned cars, bikes and SUVs across India. Every certified listing passes a 200-point inspection and comes with verified RTO and insurance papers.</p><p>Sellers list for free and keep 100% of the sale price. Buyers get transparent pricing, comparison tools and financing help.</p></div></>; }
export const Route = createFileRoute("/about")({
  head: () => ({ meta: [{ title: "About Us — AutoNest" }, { name: "description", content: "AutoNest helps India buy and sell certified pre-owned vehicles with zero commission." }, { property: "og:title", content: "About Us — AutoNest" }, { property: "og:description", content: "AutoNest helps India buy and sell certified pre-owned vehicles with zero commission." }] }),
  component: Page,
});
