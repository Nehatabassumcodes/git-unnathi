import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { ImagePlus, X, Eye, Save, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { PageHeader, VehicleCard } from "@/components/site/VehicleCard";
import { useStore } from "@/lib/store";
import { CITIES, FUELS, TRANSMISSIONS, VEHICLE_TYPES, type Vehicle, type VehicleType, type Fuel, type Transmission } from "@/lib/vehicles";

export const Route = createFileRoute("/sell")({
  head: () => ({
    meta: [
      { title: "Sell Your Vehicle — Zero Commission | AutoNest" },
      { name: "description", content: "List your used car, bike or SUV with photos in minutes and reach verified buyers." },
      { property: "og:title", content: "Sell your vehicle on AutoNest" },
      { property: "og:description", content: "Zero-commission listings with photo uploads and instant publishing." },
    ],
  }),
  component: SellPage,
});

const DRAFT_KEY = "autonest:sell-draft";
const empty = { brand: "", model: "", variant: "", type: "Car", fuel: "Petrol", transmission: "Manual", year: "", km: "", price: "", city: "", owners: "1", color: "", engine: "", description: "", sellerName: "", phone: "" };
type Form = typeof empty;

const schema = z.object({
  brand: z.string().trim().min(2, "Brand is required").max(40),
  model: z.string().trim().min(1, "Model is required").max(40),
  variant: z.string().trim().max(40),
  year: z.coerce.number().int().min(1995, "Year must be 1995 or later").max(2026, "Year can't be in the future"),
  km: z.coerce.number().int().min(0, "Invalid kilometers").max(1000000, "Too high"),
  price: z.coerce.number().min(10000, "Price must be at least ₹10,000").max(50000000, "Price seems too high"),
  city: z.string().min(1, "Select a city"),
  description: z.string().trim().min(20, "Describe the vehicle in at least 20 characters").max(1000),
  sellerName: z.string().trim().min(2, "Enter your name").max(60),
  phone: z.string().trim().regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit mobile number"),
});

function compress(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const scale = Math.min(1, 1000 / img.width);
        const c = document.createElement("canvas");
        c.width = img.width * scale; c.height = img.height * scale;
        c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL("image/jpeg", 0.7));
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}

function SellPage() {
  const { user, addListing } = useStore();
  const navigate = useNavigate();
  const [form, setForm] = useState<Form>(empty);
  const [images, setImages] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      const d = JSON.parse(localStorage.getItem(DRAFT_KEY) || "null");
      if (d) { setForm({ ...empty, ...d.form }); setImages(d.images ?? []); toast("Draft restored"); }
      else if (user) setForm((f) => ({ ...f, sellerName: user.name, phone: user.phone ?? "" }));
    } catch { /* ignore */ }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const onFiles = async (files: FileList | null) => {
    if (!files) return;
    const list = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (images.length + list.length > 10) toast.error("Maximum 10 photos");
    const room = list.slice(0, 10 - images.length);
    const bad = room.find((f) => f.size > 8 * 1024 * 1024);
    if (bad) { toast.error(`${bad.name} is larger than 8 MB`); return; }
    const urls = await Promise.all(room.map(compress));
    setImages((i) => [...i, ...urls]);
    if (urls.length) toast.success(`${urls.length} photo${urls.length > 1 ? "s" : ""} added`);
    if (fileRef.current) fileRef.current.value = "";
  };

  const build = (): Vehicle => {
    const year = Number(form.year) || 2020;
    return {
      id: `user-${Date.now()}`, title: `${year} ${form.brand} ${form.model} ${form.variant}`.trim(),
      brand: form.brand, model: form.model, variant: form.variant, type: form.type as VehicleType, fuel: form.fuel as Fuel, transmission: form.transmission as Transmission,
      price: Number(form.price) || 0, year, regYear: year, km: Number(form.km) || 0, city: form.city || "—", owners: Number(form.owners), color: form.color || "—",
      engine: form.engine || "—", power: "—", mileage: "—", seats: form.type === "Bike" ? 2 : 5,
      images: images.length ? images : ["https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&w=1200&q=70"],
      inspectionScore: 0, inspected: false, rto: "Pending", insurance: "—", insuranceValid: "—",
      seller: { name: form.sellerName || "You", type: "Individual", rating: 5, since: 2026, phone: `+91 ${form.phone}`, verified: false },
      features: [], description: form.description, addedDaysAgo: 0,
    };
  };

  const validate = () => {
    const r = schema.safeParse(form);
    const errs: Record<string, string> = {};
    if (!r.success) r.error.issues.forEach((i) => (errs[i.path[0] as string] ??= i.message));
    if (images.length === 0) errs.images = "Add at least one photo";
    setErrors(errs);
    if (Object.keys(errs).length) { toast.error("Please fix the highlighted fields"); document.getElementById(`f-${Object.keys(errs)[0]}`)?.focus(); }
    return Object.keys(errs).length === 0;
  };

  const saveDraft = () => {
    try { localStorage.setItem(DRAFT_KEY, JSON.stringify({ form, images })); toast.success("Draft saved"); }
    catch { toast.error("Couldn't save draft — try removing some photos"); }
  };
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    const v = build();
    addListing(v);
    localStorage.removeItem(DRAFT_KEY);
    toast.success("Your listing is live!", { description: v.title });
    navigate({ to: "/vehicles/$id", params: { id: v.id } });
  };

  const set = (k: keyof Form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setForm({ ...form, [k]: e.target.value });
  const Field = ({ k, label, type = "text", ...rest }: { k: keyof Form; label: string; type?: string } & React.ComponentProps<typeof Input>) => (
    <div>
      <Label htmlFor={`f-${k}`}>{label}</Label>
      <Input id={`f-${k}`} type={type} value={form[k]} onChange={set(k)} aria-invalid={!!errors[k]} aria-describedby={errors[k] ? `e-${k}` : undefined} className="mt-1" {...rest} />
      {errors[k] && <p id={`e-${k}`} className="mt-1 text-xs text-destructive">{errors[k]}</p>}
    </div>
  );
  const Select = ({ k, label, opts }: { k: keyof Form; label: string; opts: readonly string[] }) => (
    <div>
      <Label htmlFor={`f-${k}`}>{label}</Label>
      <select id={`f-${k}`} value={form[k]} onChange={set(k)} aria-invalid={!!errors[k]} className="mt-1 h-9 w-full rounded-md border bg-background px-2 text-sm">
        {k === "city" && <option value="">Select city</option>}
        {opts.map((o) => <option key={o}>{o}</option>)}
      </select>
      {errors[k] && <p className="mt-1 text-xs text-destructive">{errors[k]}</p>}
    </div>
  );

  return (
    <>
      <PageHeader title="Sell your vehicle" sub="Zero commission. Add photos, set your price and go live instantly." />
      <form onSubmit={submit} noValidate className="mx-auto grid max-w-5xl gap-8 px-4 py-8">
        {!user && <p className="rounded-lg bg-secondary p-3 text-sm"><Link to="/login" className="font-semibold text-primary underline">Sign in</Link> to manage this listing and its inquiries from your dashboard.</p>}
        <section className="rounded-xl border bg-card p-6">
          <h2 className="text-lg font-bold">1. Photos</h2>
          <p className="text-sm text-muted-foreground">Up to 10 photos. The first one is the cover.</p>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4 md:grid-cols-5">
            {images.map((src, i) => (
              <div key={i} className="group relative overflow-hidden rounded-lg border">
                <img src={src} alt={`Uploaded photo ${i + 1}`} className="aspect-[4/3] w-full object-cover" />
                {i === 0 ? (
                  <span className="absolute left-1 top-1 rounded bg-accent px-1.5 py-0.5 text-[10px] font-bold text-accent-foreground">COVER</span>
                ) : (
                  <button type="button" onClick={() => setImages((im) => [im[i], ...im.filter((_, j) => j !== i)])} className="absolute left-1 top-1 rounded bg-background/90 p-1" aria-label={`Make photo ${i + 1} the cover`}><Star className="h-3 w-3" /></button>
                )}
                <button type="button" onClick={() => setImages((im) => im.filter((_, j) => j !== i))} className="absolute right-1 top-1 rounded-full bg-destructive p-1 text-destructive-foreground" aria-label={`Remove photo ${i + 1}`}><X className="h-3 w-3" /></button>
              </div>
            ))}
            {images.length < 10 && (
              <label htmlFor="f-images" className="flex aspect-[4/3] cursor-pointer flex-col items-center justify-center gap-1 rounded-lg border-2 border-dashed text-sm text-muted-foreground hover:border-primary hover:text-primary">
                <ImagePlus className="h-6 w-6" aria-hidden />Add photos
                <input ref={fileRef} id="f-images" type="file" accept="image/*" multiple className="sr-only" onChange={(e) => onFiles(e.target.files)} />
              </label>
            )}
          </div>
          {errors.images && <p className="mt-2 text-xs text-destructive">{errors.images}</p>}
        </section>

        <section className="rounded-xl border bg-card p-6">
          <h2 className="text-lg font-bold">2. Vehicle details</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {Field({ k: "brand", label: "Brand *", placeholder: "Hyundai" })}
            {Field({ k: "model", label: "Model *", placeholder: "Creta" })}
            {Field({ k: "variant", label: "Variant", placeholder: "SX (O)" })}
            {Select({ k: "type", label: "Vehicle type", opts: VEHICLE_TYPES })}
            {Select({ k: "fuel", label: "Fuel", opts: FUELS })}
            {Select({ k: "transmission", label: "Transmission", opts: TRANSMISSIONS })}
            {Field({ k: "year", label: "Year *", type: "number", min: 1995, max: 2026, inputMode: "numeric" })}
            {Field({ k: "km", label: "Kilometers driven *", type: "number", min: 0, inputMode: "numeric" })}
            {Field({ k: "price", label: "Expected price (₹) *", type: "number", min: 0, inputMode: "numeric" })}
            {Select({ k: "city", label: "City *", opts: CITIES })}
            {Select({ k: "owners", label: "Owners", opts: ["1", "2", "3", "4"] })}
            {Field({ k: "color", label: "Colour" })}
            {Field({ k: "engine", label: "Engine (cc / kWh)" })}
          </div>
          <div className="mt-4">
            <Label htmlFor="f-description">Description *</Label>
            <Textarea id="f-description" rows={4} value={form.description} onChange={set("description")} aria-invalid={!!errors.description} className="mt-1" placeholder="Service history, condition, accessories…" />
            {errors.description && <p className="mt-1 text-xs text-destructive">{errors.description}</p>}
          </div>
        </section>

        <section className="rounded-xl border bg-card p-6">
          <h2 className="text-lg font-bold">3. Contact</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {Field({ k: "sellerName", label: "Your name *", autoComplete: "name" })}
            {Field({ k: "phone", label: "Mobile number *", inputMode: "numeric", maxLength: 10, autoComplete: "tel" })}
          </div>
        </section>

        <div className="flex flex-wrap justify-end gap-3">
          <Button type="button" variant="outline" onClick={saveDraft}><Save className="h-4 w-4" />Save draft</Button>
          <Button type="button" variant="secondary" onClick={() => setPreview(true)}><Eye className="h-4 w-4" />Preview</Button>
          <Button type="submit" className="bg-accent text-accent-foreground hover:bg-accent/90">Publish listing</Button>
        </div>
      </form>

      <Dialog open={preview} onOpenChange={setPreview}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Listing preview</DialogTitle><DialogDescription>This is how buyers will see your vehicle.</DialogDescription></DialogHeader>
          <div className="pointer-events-none"><VehicleCard v={build()} /></div>
        </DialogContent>
      </Dialog>
    </>
  );
}
