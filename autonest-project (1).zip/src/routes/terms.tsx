import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/VehicleCard";
function Page() { return <><PageHeader title="Terms of use" /><div className="mx-auto max-w-3xl space-y-4 px-4 py-10 text-muted-foreground"><p>AutoNest is a demo marketplace connecting buyers and sellers. Listings are provided by sellers, who are responsible for their accuracy.</p><p>Buyers should verify documents and inspect vehicles before payment. AutoNest is not a party to transactions.</p></div></>; }
export const Route = createFileRoute("/terms")({
  head: () => ({ meta: [{ title: "Terms of Use — AutoNest" }, { name: "description", content: "Terms governing use of the AutoNest marketplace." }, { property: "og:title", content: "Terms of Use — AutoNest" }, { property: "og:description", content: "Terms governing use of the AutoNest marketplace." }] }),
  component: Page,
});
