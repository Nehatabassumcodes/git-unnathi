import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/VehicleCard";
function Page() { return <><PageHeader title="Privacy policy" /><div className="mx-auto max-w-3xl space-y-4 px-4 py-10 text-muted-foreground"><p>In this demo, your favorites, comparisons, listings, inquiries and sign-in details are stored only in your browser and never sent to a server.</p><p>Clearing your browser storage removes all of this data.</p></div></>; }
export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [{ title: "Privacy Policy — AutoNest" }, { name: "description", content: "How AutoNest handles your data." }, { property: "og:title", content: "Privacy Policy — AutoNest" }, { property: "og:description", content: "How AutoNest handles your data." }] }),
  component: Page,
});
