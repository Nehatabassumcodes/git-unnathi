import { createFileRoute } from "@tanstack/react-router";
import { AuthForm } from "./login";

export const Route = createFileRoute("/register")({
  head: () => ({ meta: [{ title: "Create Account — AutoNest" }, { name: "description", content: "Register to sell vehicles and track inquiries." }, { property: "og:title", content: "Create Account — AutoNest" }, { property: "og:description", content: "Join AutoNest." }] }),
  component: () => <AuthForm mode="register" />,
});
