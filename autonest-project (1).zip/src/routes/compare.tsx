import { createFileRoute, Link } from "@tanstack/react-router";
import { GitCompare, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/site/VehicleCard";
import { useStore } from "@/lib/store";
import { formatINR, formatKm, type Vehicle } from "@/lib/vehicles";

export const Route = createFileRoute("/compare")({
  head: () => ({
    meta: [
      { title: "Compare Vehicles Side by Side — AutoNest" },
      { name: "description", content: "Compare price, specs, features and inspection scores of up to 4 pre-owned vehicles." },
      { property: "og:title", content: "Compare vehicles — AutoNest" },
      { property: "og:description", content: "Side-by-side comparison of up to 4 vehicles." },
    ],
  }),
  component: ComparePage,
});

const ROWS: [string, (v: Vehicle) => string | number][] = [
  ["Price", (v) => formatINR(v.price)], ["Year", (v) => v.year], ["Kilometers", (v) => formatKm(v.km)], ["Body type", (v) => v.type],
  ["Fuel", (v) => v.fuel], ["Transmission", (v) => v.transmission], ["Engine", (v) => v.engine], ["Power", (v) => v.power],
  ["Mileage", (v) => v.mileage], ["Seats", (v) => v.seats], ["Owners", (v) => v.owners], ["Inspection score", (v) => (v.inspectionScore ? `${v.inspectionScore}/100` : "Pending")],
  ["Insurance", (v) => v.insurance], ["City", (v) => v.city], ["Seller", (v) => `${v.seller.name} (${v.seller.type})`], ["Features", (v) => v.features.join(", ") || "—"],
];

function ComparePage() {
  const { compare, allVehicles, toggleCompare, clearCompare, hydrated } = useStore();
  const items = compare.map((id) => allVehicles.find((v) => v.id === id)).filter(Boolean) as Vehicle[];
  const best = (fn: (v: Vehicle) => number, low = true) => {
    if (items.length < 2) return null;
    const vals = items.map(fn); const t = low ? Math.min(...vals) : Math.max(...vals);
    return items[vals.indexOf(t)].id;
  };
  const bestPrice = best((v) => v.price), bestKm = best((v) => v.km), bestScore = best((v) => v.inspectionScore, false);
  const highlight = (label: string, v: Vehicle) =>
    (label === "Price" && v.id === bestPrice) || (label === "Kilometers" && v.id === bestKm) || (label === "Inspection score" && v.id === bestScore);

  return (
    <>
      <PageHeader title="Compare vehicles" sub="Up to 4 vehicles side by side. Best values are highlighted." />
      <div className="mx-auto max-w-7xl px-4 py-8">
        {hydrated && items.length === 0 ? (
          <div className="rounded-xl border border-dashed p-12 text-center">
            <GitCompare className="mx-auto h-10 w-10 text-muted-foreground" aria-hidden />
            <p className="mt-3 font-display text-lg font-semibold">Nothing to compare yet</p>
            <p className="text-sm text-muted-foreground">Use the compare button on vehicle cards to add up to 4.</p>
            <Button asChild className="mt-5"><Link to="/vehicles">Browse vehicles</Link></Button>
          </div>
        ) : (
          <>
            <div className="mb-4 flex justify-end"><Button variant="outline" size="sm" onClick={clearCompare}>Clear all</Button></div>
            <div className="overflow-x-auto rounded-xl border bg-card">
              <table className="w-full min-w-[640px] text-sm">
                <caption className="sr-only">Vehicle comparison</caption>
                <thead>
                  <tr>
                    <th scope="col" className="w-40 p-4 text-left align-bottom text-muted-foreground">Specification</th>
                    {items.map((v) => (
                      <th key={v.id} scope="col" className="p-4 text-left align-top font-normal">
                        <div className="relative">
                          <img src={v.images[0]} alt={v.title} className="aspect-[4/3] w-full rounded-lg object-cover" />
                          <button onClick={() => toggleCompare(v.id)} className="absolute right-1 top-1 rounded-full bg-background p-1" aria-label={`Remove ${v.title}`}><X className="h-4 w-4" /></button>
                        </div>
                        <Link to="/vehicles/$id" params={{ id: v.id }} className="mt-2 block font-display font-semibold hover:text-primary">{v.title}</Link>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {ROWS.map(([label, fn]) => (
                    <tr key={label} className="border-t">
                      <th scope="row" className="p-4 text-left font-medium text-muted-foreground">{label}</th>
                      {items.map((v) => (
                        <td key={v.id} className={`p-4 ${highlight(label, v) ? "font-bold text-success" : ""}`}>{fn(v)}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </>
  );
}
