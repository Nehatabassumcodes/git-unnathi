import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Reset Password — AutoNest" },
      { name: "description", content: "Reset your AutoNest demo account password." },
      { property: "og:title", content: "Reset Password — AutoNest" },
      { property: "og:description", content: "Recover access to your AutoNest account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ForgotPassword,
});

function ForgotPassword() {
  const [step, setStep] = useState<"email" | "code" | "done">("email");
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState("");
  const [code, setCode] = useState("");
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [err, setErr] = useState("");

  const sendCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) return setErr("Enter a valid email");
    const c = String(Math.floor(100000 + Math.random() * 900000));
    setSent(c); setErr(""); setStep("code");
    toast.success(`Demo reset code: ${c}`, { duration: 15000 });
  };
  const reset = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.trim() !== sent) return setErr("Incorrect reset code");
    if (pw.length < 6) return setErr("Password must be at least 6 characters");
    if (pw !== pw2) return setErr("Passwords do not match");
    setErr(""); setStep("done");
    localStorage.setItem("rememberedEmail", email);
    toast.success("Password updated");
  };

  return (
    <div className="mx-auto max-w-sm px-4 py-16">
      <h1 className="text-3xl font-bold">Reset password</h1>
      <p className="mt-1 text-sm text-muted-foreground">Demo only — the reset code is shown on screen instead of emailed.</p>
      {step === "email" && (
        <form onSubmit={sendCode} noValidate className="mt-6 space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} aria-invalid={!!err} className="mt-1" />
          </div>
          {err && <p className="text-xs text-destructive" role="alert">{err}</p>}
          <Button type="submit" className="w-full">Send reset code</Button>
        </form>
      )}
      {step === "code" && (
        <form onSubmit={reset} noValidate className="mt-6 space-y-4">
          <p className="text-sm">Code sent to <b>{email}</b></p>
          <div><Label htmlFor="code">Reset code</Label><Input id="code" inputMode="numeric" value={code} onChange={(e) => setCode(e.target.value)} className="mt-1" /></div>
          <div><Label htmlFor="pw">New password</Label><Input id="pw" type="password" value={pw} onChange={(e) => setPw(e.target.value)} className="mt-1" /></div>
          <div><Label htmlFor="pw2">Confirm password</Label><Input id="pw2" type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} className="mt-1" /></div>
          {err && <p className="text-xs text-destructive" role="alert">{err}</p>}
          <Button type="submit" className="w-full">Update password</Button>
          <button type="button" onClick={() => setStep("email")} className="w-full text-sm text-muted-foreground hover:underline">Use a different email</button>
        </form>
      )}
      {step === "done" && (
        <div className="mt-6 space-y-4">
          <p className="text-sm">Your password has been reset. You can now sign in.</p>
          <Button asChild className="w-full"><Link to="/login">Back to sign in</Link></Button>
        </div>
      )}
      {step !== "done" && <p className="mt-4 text-center text-sm"><Link to="/login" className="font-semibold text-primary">Back to sign in</Link></p>}
    </div>
  );
}
