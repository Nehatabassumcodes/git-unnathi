import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { LayoutGrid, List, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { VehicleCard, PageHeader } from "@/components/site/VehicleCard";
import { useStore } from "@/lib/store";
import { CITIES, FUELS, TRANSMISSIONS, VEHICLE_TYPES } from "@/lib/vehicles";

type Search = { q?: string; type?: string; city?: string };

export const Route = createFileRoute("/vehicles/")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    q: typeof s.q === "string" ? s.q : undefined,
    type: typeof s.type === "string" ? s.type : undefined,
    city: typeof s.city === "string" ? s.city : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Buy Used Cars, Bikes & SUVs — AutoNest" },
      { name: "description", content: "Filter inspected pre-owned vehicles by type, fuel, transmission, price, year and city." },
      { property: "og:title", content: "Browse pre-owned vehicles — AutoNest" },
      { property: "og:description", content: "Search and filter certified second-hand vehicles across India." },
    ],
  }),
  component: VehiclesPage,
});

const PRICE_PRESETS: [string, number, number][] = [
  ["Under ₹1 Lakh", 0, 100000], ["₹1–5 Lakh", 100000, 500000], ["₹5–10 Lakh", 500000, 1000000], ["₹10–20 Lakh", 1000000, 2000000], ["Above ₹20 Lakh", 2000000, 0],
];
const SORTS = { relevance: "Relevance", priceAsc: "Price: low to high", priceDesc: "Price: high to low", yearDesc: "Year: newest first", yearAsc: "Year: oldest first", kmAsc: "Mileage: low to high", kmDesc: "Mileage: high to low" };
const YEAR_PRESETS: [string, string, string][] = [
  ["2026", "2026", "2026"], ["2025", "2025", "2025"], ["2024", "2024", "2024"], ["2023", "2023", "2023"], ["2022", "2022", "2022"], ["Older", "", "2021"],
];

function VehiclesPage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/vehicles/" });
  const { allVehicles } = useStore();
  const [types, setTypes] = useState<string[]>(search.type ? [search.type] : []);
  const [fuels, setFuels] = useState<string[]>([]);
  const [trans, setTrans] = useState<string[]>([]);
  const [minP, setMinP] = useState("");
  const [maxP, setMaxP] = useState("");
  const [minY, setMinY] = useState("");
  const [maxY, setMaxY] = useState("");
  const [city, setCity] = useState(search.city ?? "");
  const [sort, setSort] = useState<keyof typeof SORTS>("relevance");
  const [view, setView] = useState<"grid" | "list">("grid");
  const q = search.q ?? "";

  const results = useMemo(() => {
    const term = q.toLowerCase().trim();
    const list = allVehicles.filter((v) => {
      if (term && ![v.brand, v.model, v.variant, v.title].some((f) => f.toLowerCase().includes(term))) return false;
      if (types.length && !types.includes(v.type)) return false;
      if (fuels.length && !fuels.includes(v.fuel)) return false;
      if (trans.length && !trans.includes(v.transmission)) return false;
      if (minP && v.price < Number(minP)) return false;
      if (maxP && v.price > Number(maxP)) return false;
      if (minY && v.year < Number(minY)) return false;
      if (maxY && v.year > Number(maxY)) return false;
      if (city && v.city !== city) return false;
      return true;
    });
    const s = [...list];
    const by: Record<string, (a: typeof s[0], b: typeof s[0]) => number> = {
      priceAsc: (a, b) => a.price - b.price, priceDesc: (a, b) => b.price - a.price,
      yearDesc: (a, b) => b.year - a.year, yearAsc: (a, b) => a.year - b.year,
      kmAsc: (a, b) => a.km - b.km, kmDesc: (a, b) => b.km - a.km,
    };
    if (by[sort]) s.sort(by[sort]);
    return s;
  }, [allVehicles, q, types, fuels, trans, minP, maxP, minY, maxY, city, sort]);

  const toggle = (arr: string[], set: (a: string[]) => void, val: string) => set(arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val]);
  const reset = () => { setTypes([]); setFuels([]); setTrans([]); setMinP(""); setMaxP(""); setMinY(""); setMaxY(""); setCity(""); navigate({ search: {} }); };

  const Group = ({ title, items, sel, set }: { title: string; items: readonly string[]; sel: string[]; set: (a: string[]) => void }) => (
    <fieldset>
      <legend className="mb-2 font-semibold">{title}</legend>
      <div className="space-y-2">
        {items.map((i) => (
          <div key={i} className="flex items-center gap-2">
            <Checkbox id={`${title}-${i}`} checked={sel.includes(i)} onCheckedChange={() => toggle(sel, set, i)} />
            <Label htmlFor={`${title}-${i}`} className="font-normal">{i}</Label>
          </div>
        ))}
      </div>
    </fieldset>
  );

  const filters = (
    <div className="space-y-6 text-sm">
      <Group title="Vehicle type" items={VEHICLE_TYPES} sel={types} set={setTypes} />
      <Group title="Fuel type" items={FUELS} sel={fuels} set={setFuels} />
      <Group title="Transmission" items={TRANSMISSIONS} sel={trans} set={setTrans} />
      <fieldset>
        <legend className="mb-2 font-semibold">Price range</legend>
        <div className="flex flex-wrap gap-1.5">
          {PRICE_PRESETS.map(([l, a, b]) => {
            const active = minP === (a ? String(a) : "") && maxP === (b ? String(b) : "");
            return <button key={l} type="button" aria-pressed={active} onClick={() => { setMinP(a ? String(a) : ""); setMaxP(b ? String(b) : ""); }} className={`rounded-full border px-2.5 py-1 text-xs ${active ? "border-primary bg-primary text-primary-foreground" : "hover:bg-muted"}`}>{l}</button>;
          })}
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <div><Label htmlFor="minp" className="text-xs">Min ₹</Label><Input id="minp" type="number" min={0} value={minP} onChange={(e) => setMinP(e.target.value)} /></div>
          <div><Label htmlFor="maxp" className="text-xs">Max ₹</Label><Input id="maxp" type="number" min={0} value={maxP} onChange={(e) => setMaxP(e.target.value)} /></div>
        </div>
      </fieldset>
      <fieldset>
        <legend className="mb-2 font-semibold">Registration year</legend>
        <div className="mb-3 flex flex-wrap gap-1.5">
          {YEAR_PRESETS.map(([l, a, b]) => {
            const active = minY === a && maxY === b;
            return <button key={l} type="button" aria-pressed={active} onClick={() => { setMinY(a); setMaxY(b); }} className={`rounded-full border px-2.5 py-1 text-xs ${active ? "border-primary bg-primary text-primary-foreground" : "hover:bg-muted"}`}>{l}</button>;
          })}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div><Label htmlFor="miny" className="text-xs">From</Label><Input id="miny" type="number" min={2000} max={2026} placeholder="2015" value={minY} onChange={(e) => setMinY(e.target.value)} /></div>
          <div><Label htmlFor="maxy" className="text-xs">To</Label><Input id="maxy" type="number" min={2000} max={2026} placeholder="2026" value={maxY} onChange={(e) => setMaxY(e.target.value)} /></div>
        </div>
      </fieldset>
      <div>
        <Label htmlFor="city" className="font-semibold">City</Label>
        <select id="city" value={city} onChange={(e) => setCity(e.target.value)} className="mt-2 h-9 w-full rounded-md border bg-background px-2">
          <option value="">All cities</option>
          {CITIES.map((c) => <option key={c}>{c}</option>)}
        </select>
      </div>
      <Button variant="outline" className="w-full" onClick={reset}>Reset filters</Button>
    </div>
  );

  return (
    <>
      <PageHeader title="Pre-owned vehicles" sub="Every listing shows inspection score, ownership and RTO details up front." />
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-8 lg:grid-cols-[260px_1fr]">
        <aside className="hidden lg:block" aria-label="Filters">{filters}</aside>
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <Sheet>
              <SheetTrigger asChild><Button variant="outline" className="lg:hidden"><SlidersHorizontal className="h-4 w-4" />Filters</Button></SheetTrigger>
              <SheetContent side="left" className="overflow-y-auto"><SheetTitle className="mb-4">Filters</SheetTitle>{filters}</SheetContent>
            </Sheet>
            <p className="text-sm text-muted-foreground" aria-live="polite"><b className="text-foreground">{results.length}</b> vehicles found</p>
            {q && <button onClick={() => navigate({ search: (s) => ({ ...s, q: undefined }) })} className="inline-flex items-center gap-1 rounded-full bg-secondary px-3 py-1 text-xs">“{q}” <X className="h-3 w-3" aria-label="Clear search" /></button>}
            <div className="ml-auto flex items-center gap-2">
              <Label htmlFor="sort" className="sr-only">Sort by</Label>
              <select id="sort" value={sort} onChange={(e) => setSort(e.target.value as keyof typeof SORTS)} className="h-9 rounded-md border bg-background px-2 text-sm">
                {Object.entries(SORTS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </select>
              <Button size="icon" variant={view === "grid" ? "default" : "outline"} aria-label="Grid view" aria-pressed={view === "grid"} onClick={() => setView("grid")}><LayoutGrid className="h-4 w-4" /></Button>
              <Button size="icon" variant={view === "list" ? "default" : "outline"} aria-label="List view" aria-pressed={view === "list"} onClick={() => setView("list")}><List className="h-4 w-4" /></Button>
            </div>
          </div>
          {results.length === 0 ? (
            <div className="mt-10 rounded-xl border border-dashed p-12 text-center">
              <p className="font-display text-lg font-semibold">No vehicles match your filters</p>
              <Button className="mt-4" onClick={reset}>Clear all filters</Button>
            </div>
          ) : (
            <div className={`mt-6 grid gap-6 ${view === "grid" ? "sm:grid-cols-2 xl:grid-cols-3" : ""}`}>
              {results.map((v) => <VehicleCard key={v.id} v={v} list={view === "list"} />)}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
