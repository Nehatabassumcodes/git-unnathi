// localStorage helpers for favorites, compare list, and mock user session
// Keys renamed to match SRS specification

const FAVORITES_KEY = 'favoriteVehicles';
const COMPARE_KEY = 'compareVehicles';
const USER_KEY = 'userData';
const ENQUIRY_KEY = 'autonest_enquiries';
const LISTINGS_KEY = 'sellerListings';
const DRAFT_KEY = 'autonest_sell_draft';

// One-time migration from old keys to new SRS-compliant keys
function migrateKey(oldKey, newKey) {
  try {
    const old = localStorage.getItem(oldKey);
    if (old !== null && localStorage.getItem(newKey) === null) {
      localStorage.setItem(newKey, old);
      localStorage.removeItem(oldKey);
    }
  } catch {
    // ignore migration errors
  }
}

try {
  migrateKey('autonest_favorites', FAVORITES_KEY);
  migrateKey('autonest_compare', COMPARE_KEY);
  migrateKey('autonest_user', USER_KEY);
  migrateKey('autonest_seller_listings', LISTINGS_KEY);
} catch {
  // localStorage not available
}

export const getFavorites = () => {
  try {
    return JSON.parse(localStorage.getItem(FAVORITES_KEY)) || [];
  } catch {
    return [];
  }
};

export const toggleFavorite = (id) => {
  const favorites = getFavorites();
  const index = favorites.indexOf(id);
  if (index > -1) {
    favorites.splice(index, 1);
  } else {
    favorites.push(id);
  }
  localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
  return favorites;
};

export const isFavorite = (id) => getFavorites().includes(id);

export const getCompareList = () => {
  try {
    return JSON.parse(localStorage.getItem(COMPARE_KEY)) || [];
  } catch {
    return [];
  }
};

export const toggleCompare = (id) => {
  const list = getCompareList();
  const index = list.indexOf(id);
  if (index > -1) {
    list.splice(index, 1);
  } else {
    if (list.length >= 4) {
      return { list, error: 'You can compare up to 4 vehicles at a time.' };
    }
    list.push(id);
  }
  localStorage.setItem(COMPARE_KEY, JSON.stringify(list));
  return { list, error: null };
};

export const isCompared = (id) => getCompareList().includes(id);

export const removeFromCompare = (id) => {
  const list = getCompareList().filter((item) => item !== id);
  localStorage.setItem(COMPARE_KEY, JSON.stringify(list));
  return list;
};

export const clearCompare = () => {
  localStorage.removeItem(COMPARE_KEY);
};

// Mock user session
export const getUser = () => {
  try {
    return JSON.parse(localStorage.getItem(USER_KEY)) || null;
  } catch {
    return null;
  }
};

export const setUser = (user) => {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};

export const updateUser = (updates) => {
  const current = getUser();
  if (!current) return null;
  const updated = { ...current, ...updates };
  localStorage.setItem(USER_KEY, JSON.stringify(updated));
  return updated;
};

export const removeUser = () => {
  localStorage.removeItem(USER_KEY);
};

// Enquiries (contact seller submissions)
export const getEnquiries = () => {
  try {
    return JSON.parse(localStorage.getItem(ENQUIRY_KEY)) || [];
  } catch {
    return [];
  }
};

export const saveEnquiry = (enquiry) => {
  const enquiries = getEnquiries();
  enquiries.unshift(enquiry);
  localStorage.setItem(ENQUIRY_KEY, JSON.stringify(enquiries));
  return enquiries;
};

export const deleteEnquiry = (id) => {
  const enquiries = getEnquiries().filter((e) => e.id !== id);
  localStorage.setItem(ENQUIRY_KEY, JSON.stringify(enquiries));
  return enquiries;
};

// Seller listings (submitted via Sell Vehicle form)
export const getListings = () => {
  try {
    return JSON.parse(localStorage.getItem(LISTINGS_KEY)) || [];
  } catch {
    return [];
  }
};

export const saveListing = (listing) => {
  const listings = getListings();
  listings.unshift(listing);
  localStorage.setItem(LISTINGS_KEY, JSON.stringify(listings));
  return listings;
};

export const deleteListing = (id) => {
  const listings = getListings().filter((l) => l.id !== id);
  localStorage.setItem(LISTINGS_KEY, JSON.stringify(listings));
  return listings;
};

// Sell Vehicle form draft
export const getDraft = () => {
  try {
    return JSON.parse(localStorage.getItem(DRAFT_KEY)) || null;
  } catch {
    return null;
  }
};

export const saveDraft = (draft) => {
  localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
};

export const clearDraft = () => {
  localStorage.removeItem(DRAFT_KEY);
};
