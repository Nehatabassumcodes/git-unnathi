import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { GitCompare, X, ArrowRight, Plus } from 'lucide-react';
import { getCompareList, removeFromCompare, clearCompare } from '@/utils/storage';
import { getVehicleById, formatPrice, formatKm, vehicles } from '@/data/vehicles';
import VehicleCard from '@/components/VehicleCard';
import ImageWithFallback from '@/components/ImageWithFallback';
import LoadingSpinner from '@/components/LoadingSpinner';

export default function Compare() {
  const [compareIds, setCompareIds] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setCompareIds(getCompareList());
    const timer = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(timer);
  }, []);

  const handleRemove = (id) => setCompareIds(removeFromCompare(id));
  const handleClear = () => { clearCompare(); setCompareIds([]); };

  const compareVehicles = compareIds.map((id) => getVehicleById(id)).filter(Boolean);
  const availableToAdd = vehicles.filter((v) => !compareIds.includes(v.id));

  const specRows = [
    { label: 'Brand', key: 'brand' },
    { label: 'Model', key: 'model' },
    { label: 'Variant', key: 'variant' },
    { label: 'Type', key: 'vehicleType' },
    { label: 'Condition', key: 'condition' },
    { label: 'Year', key: 'year' },
    { label: 'Price', key: 'price', format: formatPrice },
    { label: 'Fuel', key: 'fuel' },
    { label: 'Transmission', key: 'transmission' },
    { label: 'Kilometers', key: 'kilometers', format: formatKm },
    { label: 'Owners', key: 'owners', format: (v) => `${v}` },
    { label: 'Color', key: 'color' },
    { label: 'City', key: 'city' },
  ];

  if (loading) return <LoadingSpinner label="Loading comparison..." />;

  if (compareVehicles.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-extrabold tracking-tight text-navy-900 sm:text-3xl">Compare Cars</h1>
          <p className="mt-2 text-sm text-navy-500">Add cars to compare them side-by-side. You can compare up to 4 at once.</p>
        </div>

        <div className="flex flex-col items-center justify-center rounded-2xl bg-white py-16 text-center shadow-card">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-navy-50">
            <GitCompare size={40} className="text-navy-300" />
          </div>
          <h3 className="mt-6 text-lg font-bold text-navy-900">No cars selected for comparison</h3>
          <p className="mt-2 max-w-sm text-sm text-navy-500">Browse cars and tap the "Compare" button to add them here.</p>
          <Link to="/vehicles" className="mt-6 btn-primary">Browse Cars <ArrowRight size={16} /></Link>
        </div>

        <div className="mt-10">
          <h2 className="text-lg font-bold text-navy-900">Popular Cars to Compare</h2>
          <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {vehicles.slice(0, 6).map((v) => <VehicleCard key={v.id} vehicle={v} />)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-navy-900 sm:text-3xl">Compare Cars</h1>
          <p className="mt-1 text-sm text-navy-500">{compareVehicles.length} of 4 cars selected</p>
        </div>
        <button onClick={handleClear} className="btn-ghost text-red-500 hover:bg-red-50" aria-label="Clear all compared cars">
          <X size={18} /> Clear All
        </button>
      </div>

      <div className="overflow-x-auto rounded-2xl bg-white shadow-card">
        <table className="w-full min-w-[640px]">
          <thead>
            <tr className="border-b border-navy-100">
              <th className="w-40 p-4 text-left text-sm font-bold text-navy-900">Vehicle</th>
              {compareVehicles.map((v) => (
                <th key={v.id} className="p-4 text-center">
                  <div className="relative">
                    <button onClick={() => handleRemove(v.id)} className="absolute -right-2 -top-2 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-red-50 text-red-500 shadow-sm transition-all hover:bg-red-100 hover:scale-110" aria-label={`Remove ${v.brand} ${v.model} from comparison`}>
                      <X size={15} />
                    </button>
                    <Link to={`/vehicles/${v.id}`} aria-label={`View ${v.brand} ${v.model} details`}>
                      <ImageWithFallback src={v.images[0]} alt={`${v.brand} ${v.model} ${v.variant}`} className="mx-auto aspect-[16/10] w-full rounded-xl object-cover" />
                    </Link>
                    <p className="mt-3 text-sm font-bold text-navy-900">{v.brand} {v.model}</p>
                    <p className="text-xs text-navy-500">{v.variant}</p>
                  </div>
                </th>
              ))}
              {compareVehicles.length < 4 && (
                <th className="w-40 p-4">
                  <Link to="/vehicles" className="flex aspect-[16/10] w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-navy-200 text-navy-400 transition-all hover:border-accent-400 hover:text-accent-500" aria-label="Add another car to compare">
                    <Plus size={24} />
                    <span className="text-xs font-semibold">Add Car</span>
                  </Link>
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {specRows.map((row, rowIdx) => (
              <tr key={row.key} className={rowIdx % 2 === 0 ? 'bg-navy-50/50' : ''}>
                <td className="p-4 text-sm font-semibold text-navy-700">{row.label}</td>
                {compareVehicles.map((v) => (
                  <td key={v.id} className="p-4 text-center text-sm font-medium text-navy-900">
                    {row.format ? row.format(v[row.key]) : v[row.key]}
                  </td>
                ))}
                {compareVehicles.length < 4 && <td />}
              </tr>
            ))}
            <tr>
              <td className="p-4 text-sm font-semibold text-navy-700">Features</td>
              {compareVehicles.map((v) => (
                <td key={v.id} className="p-4">
                  <div className="flex flex-wrap justify-center gap-1">
                    {v.features.slice(0, 5).map((f) => (
                      <span key={f} className="rounded-md bg-navy-100 px-2 py-0.5 text-xs text-navy-700">{f}</span>
                    ))}
                    {v.features.length > 5 && <span className="text-xs text-navy-400">+{v.features.length - 5} more</span>}
                  </div>
                </td>
              ))}
              {compareVehicles.length < 4 && <td />}
            </tr>
            <tr>
              <td className="p-4" />
              {compareVehicles.map((v) => (
                <td key={v.id} className="p-4 text-center">
                  <Link to={`/vehicles/${v.id}`} className="inline-flex items-center gap-1.5 rounded-lg bg-navy-900 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-navy-800">
                    View Details <ArrowRight size={14} />
                  </Link>
                </td>
              ))}
              {compareVehicles.length < 4 && <td />}
            </tr>
          </tbody>
        </table>
      </div>

      {availableToAdd.length > 0 && compareVehicles.length < 4 && (
        <div className="mt-10">
          <h2 className="text-lg font-bold text-navy-900">Add More Cars to Compare</h2>
          <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {availableToAdd.slice(0, 4).map((v) => <VehicleCard key={v.id} vehicle={v} />)}
          </div>
        </div>
      )}
    </div>
  );
}
