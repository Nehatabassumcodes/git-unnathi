import { useMemo, useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { SlidersHorizontal, X, Car, ChevronDown, ChevronLeft, ChevronRight, SearchX } from 'lucide-react';
import SearchBar from '@/components/SearchBar';
import VehicleCard from '@/components/VehicleCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import { vehicles, vehicleTypes, brands, cities, fuelTypes, transmissions, yearFilters } from '@/data/vehicles';

const sortOptions = [
  { label: 'Newest First', value: 'newest' },
  { label: 'Oldest First', value: 'oldest' },
  { label: 'Price: Low to High', value: 'price-asc' },
  { label: 'Price: High to Low', value: 'price-desc' },
  { label: 'Kilometers: Low to High', value: 'km-asc' },
  { label: 'Kilometers: High to Low', value: 'km-desc' },
  { label: 'Year: Newest First', value: 'year-desc' },
];

const ITEMS_PER_PAGE = 9;

const priceRangePresets = [
  { label: 'Under ₹2 Lakhs', min: null, max: 200000 },
  { label: '₹2–5 Lakhs', min: 200000, max: 500000 },
  { label: '₹5–10 Lakhs', min: 500000, max: 1000000 },
  { label: '₹10–20 Lakhs', min: 1000000, max: 2000000 },
  { label: 'Above ₹20 Lakhs', min: 2000000, max: null },
];

function getPageRange(current, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  if (current <= 3) return [1, 2, 3, 4, '...', total];
  if (current >= total - 2) return [1, '...', total - 2, total - 1, total];
  return [1, '...', current - 1, current, current + 1, '...', total];
}

export default function Vehicles() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [sortBy, setSortBy] = useState('newest');
  const [showFilters, setShowFilters] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [selectedTypes, setSelectedTypes] = useState(searchParams.get('type') ? [searchParams.get('type')] : []);
  const [selectedBrands, setSelectedBrands] = useState(searchParams.get('brand') ? [searchParams.get('brand')] : []);
  const [selectedCities, setSelectedCities] = useState(searchParams.get('location') ? [searchParams.get('location')] : []);
  const [selectedFuels, setSelectedFuels] = useState([]);
  const [selectedTransmissions, setSelectedTransmissions] = useState([]);
  const [selectedYears, setSelectedYears] = useState([]);
  const [minPrice, setMinPrice] = useState(searchParams.get('minPrice') || '');
  const [maxPrice, setMaxPrice] = useState(searchParams.get('maxPrice') || '');
  const [selectedPriceRanges, setSelectedPriceRanges] = useState([]);

  useEffect(() => {
    setQuery(searchParams.get('q') || '');
    setSelectedTypes(searchParams.get('type') ? [searchParams.get('type')] : []);
    setSelectedBrands(searchParams.get('brand') ? [searchParams.get('brand')] : []);
    setSelectedCities(searchParams.get('location') ? [searchParams.get('location')] : []);
    setMinPrice(searchParams.get('minPrice') || '');
    setMaxPrice(searchParams.get('maxPrice') || '');
  }, [searchParams]);

  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => setLoading(false), 400);
    return () => clearTimeout(timer);
  }, []);

  const toggleArrayFilter = (value, setter, current) => {
    if (current.includes(value)) setter(current.filter((v) => v !== value));
    else setter([...current, value]);
  };

  const clearAll = () => {
    setQuery('');
    setSelectedTypes([]);
    setSelectedBrands([]);
    setSelectedCities([]);
    setSelectedFuels([]);
    setSelectedTransmissions([]);
    setSelectedYears([]);
    setSelectedPriceRanges([]);
    setMinPrice('');
    setMaxPrice('');
    setSearchParams({});
    setCurrentPage(1);
  };

  const matchesYearFilter = (vehicleYear, yearFilterValue) => {
    const yearInt = parseInt(yearFilterValue);
    if (yearFilterValue === 'Older') return vehicleYear < 2022;
    return vehicleYear === yearInt;
  };

  // Detect invalid min > max price
  const hasInvalidPriceRange = minPrice && maxPrice && parseInt(minPrice) > parseInt(maxPrice);

  const filtered = useMemo(() => {
    let result = [...vehicles];

    if (query) {
      const q = query.toLowerCase();
      result = result.filter(
        (v) =>
          v.brand.toLowerCase().includes(q) ||
          v.model.toLowerCase().includes(q) ||
          v.variant.toLowerCase().includes(q) ||
          v.city.toLowerCase().includes(q) ||
          v.state.toLowerCase().includes(q)
      );
    }
    if (selectedTypes.length) result = result.filter((v) => selectedTypes.includes(v.vehicleType));
    if (selectedBrands.length) result = result.filter((v) => selectedBrands.includes(v.brand));
    if (selectedCities.length) result = result.filter((v) => selectedCities.includes(v.city));
    if (selectedFuels.length) result = result.filter((v) => selectedFuels.includes(v.fuel));
    if (selectedTransmissions.length) result = result.filter((v) => selectedTransmissions.includes(v.transmission));
    if (selectedYears.length) result = result.filter((v) => selectedYears.some((yf) => matchesYearFilter(v.year, yf)));
    if (minPrice && !hasInvalidPriceRange) result = result.filter((v) => v.price >= parseInt(minPrice));
    if (maxPrice && !hasInvalidPriceRange) result = result.filter((v) => v.price <= parseInt(maxPrice));
    if (selectedPriceRanges.length) {
      result = result.filter((v) => selectedPriceRanges.some((range) => {
        if (range.min === null) return v.price < range.max;
        if (range.max === null) return v.price >= range.min;
        return v.price >= range.min && v.price <= range.max;
      }));
    }

    switch (sortBy) {
      case 'price-asc': result.sort((a, b) => a.price - b.price); break;
      case 'price-desc': result.sort((a, b) => b.price - a.price); break;
      case 'km-asc': result.sort((a, b) => a.kilometers - b.kilometers); break;
      case 'km-desc': result.sort((a, b) => b.kilometers - a.kilometers); break;
      case 'year-desc': result.sort((a, b) => b.year - a.year); break;
      case 'oldest': result.sort((a, b) => a.year - b.year); break;
      default: result.sort((a, b) => new Date(b.dateAdded) - new Date(a.dateAdded));
    }

    return result;
  }, [query, selectedTypes, selectedBrands, selectedCities, selectedFuels, selectedTransmissions, selectedYears, minPrice, maxPrice, selectedPriceRanges, sortBy, hasInvalidPriceRange]);

  useEffect(() => { setCurrentPage(1); }, [query, selectedTypes, selectedBrands, selectedCities, selectedFuels, selectedTransmissions, selectedYears, minPrice, maxPrice, selectedPriceRanges, sortBy]);

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filtered.slice(start, start + ITEMS_PER_PAGE);
  }, [filtered, currentPage]);

  const goToPage = (page) => {
    setCurrentPage(Math.max(1, Math.min(totalPages, page)));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeFilterCount =
    selectedTypes.length + selectedBrands.length + selectedCities.length + selectedFuels.length +
    selectedTransmissions.length + selectedYears.length + selectedPriceRanges.length + (minPrice ? 1 : 0) + (maxPrice ? 1 : 0);

  const FilterCheckbox = ({ label, checked, onChange }) => (
    <label className="flex cursor-pointer items-center gap-2.5 py-1.5 text-sm text-navy-700 hover:text-navy-900">
      <input type="checkbox" checked={checked} onChange={onChange} className="h-4 w-4 rounded border-navy-300 text-accent-500 focus:ring-accent-400" />
      {label}
    </label>
  );

  const FilterSection = ({ title, children }) => (
    <div className="border-b border-navy-100 py-4">
      <h3 className="mb-2 text-sm font-bold text-navy-900">{title}</h3>
      <div className="max-h-44 overflow-y-auto pr-1">{children}</div>
    </div>
  );

  const FiltersPanel = () => (
    <div className="space-y-0">
      <div className="flex items-center justify-between pb-3">
        <h3 className="text-sm font-bold text-navy-900">Filters</h3>
        {activeFilterCount > 0 && (
          <button onClick={clearAll} className="text-xs font-semibold text-accent-600 hover:text-accent-700">Clear All ({activeFilterCount})</button>
        )}
      </div>

      <FilterSection title="Vehicle Type">
        {vehicleTypes.map((t) => <FilterCheckbox key={t} label={t} checked={selectedTypes.includes(t)} onChange={() => toggleArrayFilter(t, setSelectedTypes, selectedTypes)} />)}
      </FilterSection>

      <FilterSection title="Year">
        {yearFilters.map((y) => <FilterCheckbox key={y} label={y === 'Older' ? 'Older (pre-2022)' : y} checked={selectedYears.includes(y)} onChange={() => toggleArrayFilter(y, setSelectedYears, selectedYears)} />)}
      </FilterSection>

      <FilterSection title="Brand">
        {brands.map((b) => <FilterCheckbox key={b} label={b} checked={selectedBrands.includes(b)} onChange={() => toggleArrayFilter(b, setSelectedBrands, selectedBrands)} />)}
      </FilterSection>

      <FilterSection title="City">
        {cities.map((c) => <FilterCheckbox key={c} label={c} checked={selectedCities.includes(c)} onChange={() => toggleArrayFilter(c, setSelectedCities, selectedCities)} />)}
      </FilterSection>

      <FilterSection title="Fuel Type">
        {fuelTypes.map((f) => <FilterCheckbox key={f} label={f} checked={selectedFuels.includes(f)} onChange={() => toggleArrayFilter(f, setSelectedFuels, selectedFuels)} />)}
      </FilterSection>

      <FilterSection title="Transmission">
        {transmissions.map((t) => <FilterCheckbox key={t} label={t} checked={selectedTransmissions.includes(t)} onChange={() => toggleArrayFilter(t, setSelectedTransmissions, selectedTransmissions)} />)}
      </FilterSection>

      <FilterSection title="Price Range">
        {priceRangePresets.map((pr) => <FilterCheckbox key={pr.label} label={pr.label} checked={selectedPriceRanges.some((s) => s.label === pr.label)} onChange={() => {
          if (selectedPriceRanges.some((s) => s.label === pr.label)) setSelectedPriceRanges(selectedPriceRanges.filter((s) => s.label !== pr.label));
          else setSelectedPriceRanges([...selectedPriceRanges, pr]);
        }} />)}
      </FilterSection>

      <FilterSection title="Budget (₹)">
        <div className="flex gap-2">
          <label htmlFor="min-price" className="sr-only">Minimum price</label>
          <input id="min-price" type="number" placeholder="Min" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} className={`w-full rounded-lg border px-3 py-2 text-sm outline-none focus:border-accent-400 ${hasInvalidPriceRange ? 'border-red-400' : 'border-navy-200'}`} />
          <label htmlFor="max-price" className="sr-only">Maximum price</label>
          <input id="max-price" type="number" placeholder="Max" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} className={`w-full rounded-lg border px-3 py-2 text-sm outline-none focus:border-accent-400 ${hasInvalidPriceRange ? 'border-red-400' : 'border-navy-200'}`} />
        </div>
        {hasInvalidPriceRange && <p className="mt-1 text-xs font-medium text-red-500">Min price cannot exceed max price.</p>}
      </FilterSection>
    </div>
  );

  const pageRange = getPageRange(currentPage, totalPages);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6">
        <h1 className="text-2xl font-extrabold tracking-tight text-navy-900 sm:text-3xl">Browse Cars</h1>
        <p className="mt-1 text-sm text-navy-500">{hasInvalidPriceRange ? 'Fix price range to see results' : `${filtered.length} ${filtered.length === 1 ? 'car' : 'cars'} available`}</p>
      </div>

      <div className="mb-6 rounded-2xl bg-white p-4 shadow-card sm:p-5">
        <SearchBar variant="compact" />
      </div>

      <div className="mb-4 flex items-center justify-between lg:hidden">
        <button onClick={() => setShowFilters(true)} className="flex items-center gap-2 rounded-xl border border-navy-200 bg-white px-4 py-2.5 text-sm font-semibold text-navy-800" aria-label="Open filters">
          <SlidersHorizontal size={18} /> Filters
          {activeFilterCount > 0 && <span className="flex h-5 w-5 items-center justify-center rounded-full bg-accent-500 text-xs text-white">{activeFilterCount}</span>}
        </button>
        <div className="relative">
          <label htmlFor="mobile-sort" className="sr-only">Sort by</label>
          <select id="mobile-sort" value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="cursor-pointer appearance-none rounded-xl border border-navy-200 bg-white py-2.5 pl-4 pr-10 text-sm font-semibold text-navy-800 outline-none focus:border-accent-400">
            {sortOptions.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
        </div>
      </div>

      <div className="flex gap-6">
        <aside className="hidden w-64 flex-shrink-0 lg:block">
          <div className="sticky top-20 rounded-2xl bg-white p-5 shadow-card">
            <FiltersPanel />
          </div>
        </aside>

        {showFilters && (
          <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Filters panel">
            <div className="absolute inset-0 bg-navy-900/50 backdrop-blur-sm" onClick={() => setShowFilters(false)} />
            <div className="absolute left-0 top-0 h-full w-80 max-w-[85vw] overflow-y-auto bg-white p-5 shadow-xl">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-lg font-bold text-navy-900">Filters</h2>
                <button onClick={() => setShowFilters(false)} className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-navy-50" aria-label="Close filters">
                  <X size={20} />
                </button>
              </div>
              <FiltersPanel />
              <button onClick={() => setShowFilters(false)} className="mt-5 w-full rounded-xl bg-accent-500 py-3 text-sm font-bold text-white">
                Show {filtered.length} Results
              </button>
            </div>
          </div>
        )}

        <div className="flex-1">
          <div className="mb-4 hidden items-center justify-end lg:flex">
            <div className="relative">
              <label htmlFor="desktop-sort" className="sr-only">Sort by</label>
              <select id="desktop-sort" value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="cursor-pointer appearance-none rounded-xl border border-navy-200 bg-white py-2.5 pl-4 pr-10 text-sm font-semibold text-navy-800 outline-none focus:border-accent-400">
                {sortOptions.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
              <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
            </div>
          </div>

          {loading ? (
            <LoadingSpinner label="Loading cars..." />
          ) : hasInvalidPriceRange ? (
            <div className="flex flex-col items-center justify-center rounded-2xl bg-white py-20 text-center shadow-card">
              <SearchX size={48} className="text-navy-300" />
              <h3 className="mt-4 text-lg font-bold text-navy-900">Invalid price range</h3>
              <p className="mt-1 text-sm text-navy-500">Minimum price cannot be higher than maximum price.</p>
              <button onClick={clearAll} className="mt-4 btn-secondary">Clear All Filters</button>
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-2xl bg-white py-20 text-center shadow-card">
              <Car size={48} className="text-navy-300" />
              <h3 className="mt-4 text-lg font-bold text-navy-900">No cars found</h3>
              <p className="mt-1 max-w-xs text-sm text-navy-500">No cars match your current filters or search. Try adjusting or clearing them.</p>
              <button onClick={clearAll} className="mt-4 btn-secondary">Clear All Filters</button>
              <Link to="/vehicles" className="mt-2 text-xs font-semibold text-accent-600 hover:text-accent-700">Browse all cars</Link>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {paginated.map((v) => <VehicleCard key={v.id} vehicle={v} />)}
              </div>

              {totalPages > 1 && (
                <nav className="mt-8 flex items-center justify-center gap-2" aria-label="Pagination">
                  <button onClick={() => goToPage(currentPage - 1)} disabled={currentPage === 1} className="flex h-10 w-10 items-center justify-center rounded-xl border border-navy-200 bg-white text-navy-700 transition-all hover:border-navy-300 hover:bg-navy-50 disabled:cursor-not-allowed disabled:opacity-40" aria-label="Previous page">
                    <ChevronLeft size={20} />
                  </button>

                  {pageRange.map((page, idx) =>
                    page === '...' ? (
                      <span key={`ellipsis-${idx}`} className="flex h-10 w-10 items-center justify-center text-sm text-navy-400">...</span>
                    ) : (
                      <button
                        key={page}
                        onClick={() => goToPage(page)}
                        className={`flex h-10 w-10 items-center justify-center rounded-xl text-sm font-bold transition-all ${currentPage === page ? 'bg-accent-500 text-white shadow-sm' : 'border border-navy-200 bg-white text-navy-700 hover:border-navy-300 hover:bg-navy-50'}`}
                        aria-label={`Page ${page}`}
                        aria-current={currentPage === page ? 'page' : undefined}
                      >
                        {page}
                      </button>
                    )
                  )}

                  <button onClick={() => goToPage(currentPage + 1)} disabled={currentPage === totalPages} className="flex h-10 w-10 items-center justify-center rounded-xl border border-navy-200 bg-white text-navy-700 transition-all hover:border-navy-300 hover:bg-navy-50 disabled:cursor-not-allowed disabled:opacity-40" aria-label="Next page">
                    <ChevronRight size={20} />
                  </button>
                </nav>
              )}

              <p className="mt-4 text-center text-xs text-navy-400">
                Showing {paginated.length > 0 ? (currentPage - 1) * ITEMS_PER_PAGE + 1 : 0}–{(currentPage - 1) * ITEMS_PER_PAGE + paginated.length} of {filtered.length}
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
