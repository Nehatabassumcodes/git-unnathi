import { Link } from 'react-router-dom';
import {
  Search, Car, Bike, CarFront, Caravan,
  ShieldCheck, Layers, Eye, GitCompare, ArrowRight, Star, Quote, CheckCircle2, Users,
} from 'lucide-react';
import SearchBar from '@/components/SearchBar';
import VehicleCard from '@/components/VehicleCard';
import { getFeaturedVehicles, getRecentVehicles, brands } from '@/data/vehicles';

const categories = [
  { name: 'Cars', icon: Car, type: 'Car' },
  { name: 'Bikes', icon: Bike, type: 'Bike' },
  { name: 'SUVs', icon: CarFront, type: 'SUV' },
  { name: 'Sedans', icon: Car, type: 'Sedan' },
  { name: 'Hatchbacks', icon: Caravan, type: 'Hatchback' },
];

const whyChoose = [
  { icon: ShieldCheck, title: 'Verified Listings', desc: 'Every listing is checked for accuracy so you know exactly what you are getting.' },
  { icon: Layers, title: 'Wide Selection', desc: 'Thousands of cars across every budget, brand, and body type — all in one place.' },
  { icon: Eye, title: 'Transparent Information', desc: 'Full details, specs, and history upfront. No hidden surprises or last-minute changes.' },
  { icon: GitCompare, title: 'Easy Comparison', desc: 'Compare up to 4 cars side-by-side to find the one that fits you best.' },
];

const testimonials = [
  {
    name: 'Aarav Patel',
    role: 'Software Engineer, Bengaluru',
    rating: 5,
    text: 'I found my Hyundai Creta on AutoNest within two days. The listings had all the details I needed, and the comparison tool helped me choose between three options. Excellent experience.',
  },
  {
    name: 'Deepika Nair',
    role: 'Marketing Manager, Mumbai',
    rating: 5,
    text: 'Sold my Honda City through AutoNest in under a week. The platform is intuitive and I got genuine inquiries from real buyers. Highly recommend it for anyone selling a car.',
  },
  {
    name: 'Rohan Verma',
    role: 'Business Owner, Delhi',
    rating: 5,
    text: 'The verified listings gave me confidence. I bought a BMW 3 Series and everything matched the description perfectly. AutoNest made the whole process smooth and transparent.',
  },
];

const brandLogos = {
  Toyota: '🚗', Honda: '🚙', Hyundai: '🚘', Kia: '🚗', 'Maruti Suzuki': '🚙',
  Tata: '🚘', Mahindra: '🚙', BMW: '🚗', 'Mercedes-Benz': '🚘', Audi: '🚗',
  'Royal Enfield': '🏍️', Bajaj: '🏍️', KTM: '🏍️',
};

export default function Home() {
  const featured = getFeaturedVehicles().slice(0, 6);
  const recent = getRecentVehicles().slice(0, 8);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-navy-900">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/35113538/pexels-photo-35113538.jpeg?auto=compress&cs=tinysrgb&h=1080&w=1920"
            alt="Luxury car showroom interior"
            className="h-full w-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-navy-900/80 via-navy-900/70 to-navy-900/90" />
        </div>

        <div className="relative mx-auto max-w-5xl px-4 py-16 text-center sm:px-6 sm:py-24 lg:py-28">
          <span className="inline-flex items-center gap-2 rounded-full bg-accent-500/15 px-4 py-1.5 text-sm font-semibold text-accent-400">
            <CheckCircle2 size={16} />
            Trusted by 50,000+ buyers across India
          </span>
          <h1 className="mt-6 text-4xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl lg:text-6xl">
            Find Your Perfect
            <span className="block text-accent-500">Used Car</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base text-navy-200 sm:text-lg">
            Quality cars. Better prices. A smarter way to buy and sell.
          </p>

          {/* Search bar */}
          <div className="mx-auto mt-8 max-w-3xl rounded-2xl bg-white/95 p-4 shadow-xl backdrop-blur sm:p-5">
            <SearchBar variant="hero" />
          </div>
        </div>
      </section>

      {/* Browse by Category */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
        <div className="text-center">
          <h2 className="section-title">Browse by Category</h2>
          <p className="section-subtitle">Find the right type of car for your lifestyle</p>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {categories.map((cat) => (
            <Link
              key={cat.name}
              to={`/vehicles?type=${encodeURIComponent(cat.type)}`}
              className="card group flex flex-col items-center gap-3 p-6 text-center hover:-translate-y-1 hover:shadow-card-hover"
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-navy-50 text-navy-700 transition-all group-hover:bg-accent-500 group-hover:text-white">
                <cat.icon size={26} />
              </div>
              <span className="text-sm font-bold text-navy-800">{cat.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Vehicles */}
      <section className="bg-white py-14 lg:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between">
            <div>
              <h2 className="section-title">Featured Vehicles</h2>
              <p className="section-subtitle">Handpicked listings for you</p>
            </div>
            <Link to="/vehicles" className="hidden items-center gap-1 text-sm font-semibold text-accent-600 hover:text-accent-700 sm:flex">
              View All <ArrowRight size={16} />
            </Link>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((v) => (
              <VehicleCard key={v.id} vehicle={v} />
            ))}
          </div>

          <div className="mt-8 text-center sm:hidden">
            <Link to="/vehicles" className="btn-secondary">
              View All <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Recently Added */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="section-title">Recently Added</h2>
            <p className="section-subtitle">Fresh listings in the last few days</p>
          </div>
          <Link to="/vehicles?sort=newest" className="hidden items-center gap-1 text-sm font-semibold text-accent-600 hover:text-accent-700 sm:flex">
            View All <ArrowRight size={16} />
          </Link>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {recent.map((v) => (
            <VehicleCard key={v.id} vehicle={v} />
          ))}
        </div>
      </section>

      {/* Popular Brands */}
      <section className="bg-navy-50 py-14 lg:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="section-title">Popular Brands</h2>
            <p className="section-subtitle">Explore cars from your favorite manufacturers</p>
          </div>

          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {brands.map((b) => (
              <Link
                key={b}
                to={`/vehicles?brand=${encodeURIComponent(b)}`}
                className="card flex items-center gap-3 p-4 hover:-translate-y-0.5 hover:shadow-card-hover"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-white text-xl shadow-sm">
                  {brandLogos[b]}
                </span>
                <span className="text-sm font-bold text-navy-800">{b}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose AutoNest */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
        <div className="text-center">
          <h2 className="section-title">Why Choose AutoNest</h2>
          <p className="section-subtitle">We make buying and selling cars easier, safer, and smarter</p>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {whyChoose.map((item) => (
            <div key={item.title} className="card p-6 text-center hover:-translate-y-1 hover:shadow-card-hover">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-accent-50 text-accent-500">
                <item.icon size={26} />
              </div>
              <h3 className="mt-4 text-base font-bold text-navy-900">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-navy-500">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-navy-900 py-14 lg:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl font-extrabold tracking-tight text-white sm:text-3xl">What Our Users Say</h2>
            <p className="mt-2 text-sm text-navy-300 sm:text-base">Real stories from AutoNest buyers and sellers</p>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
            {testimonials.map((t) => (
              <div key={t.name} className="rounded-2xl bg-navy-800 p-6">
                <Quote className="text-accent-500" size={28} />
                <p className="mt-4 text-sm leading-relaxed text-navy-200">{t.text}</p>
                <div className="mt-5 flex items-center gap-1">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} size={16} className="fill-accent-500 text-accent-500" />
                  ))}
                </div>
                <div className="mt-4 flex items-center gap-3 border-t border-navy-700 pt-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent-500 text-sm font-bold text-white">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">{t.name}</p>
                    <p className="text-xs text-navy-400">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sell CTA */}
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-accent-500 to-accent-700 px-6 py-12 text-center sm:px-12 sm:py-16">
          <div className="absolute -right-12 -top-12 h-48 w-48 rounded-full bg-white/10" />
          <div className="absolute -bottom-16 -left-16 h-56 w-56 rounded-full bg-white/10" />
          <div className="relative">
            <Users className="mx-auto text-white/90" size={36} />
            <h2 className="mt-4 text-2xl font-extrabold text-white sm:text-3xl lg:text-4xl">
              Ready to sell your car?
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-sm text-white/90 sm:text-base">
              List your car in minutes and reach thousands of genuine buyers across India. It is free, fast, and easy.
            </p>
            <Link to="/sell" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-white px-8 py-3.5 text-sm font-bold text-accent-600 shadow-lg transition-all hover:bg-navy-50 hover:shadow-xl active:scale-95">
              Sell Your Car <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
