import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Car, ArrowRight, Trash2 } from 'lucide-react';
import VehicleCard from '@/components/VehicleCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import { getFavorites, toggleFavorite } from '@/utils/storage';
import { getVehicleById } from '@/data/vehicles';

export default function Favorites() {
  const [favIds, setFavIds] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setFavIds(getFavorites());
    const timer = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(timer);
  }, []);

  const handleRemove = (id) => {
    toggleFavorite(id);
    setFavIds(getFavorites());
  };

  const favVehicles = favIds.map((id) => getVehicleById(id)).filter(Boolean);

  if (loading) return <LoadingSpinner label="Loading your favorites..." />;

  if (favVehicles.length === 0) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center justify-center px-4 py-20 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-navy-50">
          <Heart size={40} className="text-navy-300" />
        </div>
        <h1 className="mt-6 text-2xl font-extrabold text-navy-900">No Favorites Yet</h1>
        <p className="mt-3 max-w-sm text-sm text-navy-500">
          Tap the heart icon on any car to save it here. Your favorite cars will appear on this page for easy access.
        </p>
        <Link to="/vehicles" className="mt-6 btn-primary">
          Browse Cars <ArrowRight size={16} />
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-navy-900 sm:text-3xl">Your Favorites</h1>
          <p className="mt-1 text-sm text-navy-500">{favVehicles.length} saved {favVehicles.length === 1 ? 'car' : 'cars'}</p>
        </div>
        <Link to="/vehicles" className="btn-ghost hidden sm:flex">
          <Car size={18} /> Browse More
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {favVehicles.map((v) => (
          <div key={v.id} className="relative">
            <VehicleCard vehicle={v} />
            <button
              onClick={() => handleRemove(v.id)}
              className="absolute right-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-red-50 text-red-500 shadow-sm transition-all hover:bg-red-100 hover:scale-110"
              aria-label={`Remove ${v.brand} ${v.model} from favorites`}
            >
              <Trash2 size={16} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
