import { useState } from 'react';
import { MapPin, Mail, Phone, Clock, Send, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/components/Toast';

export default function Contact() {
  const { show } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: undefined });
  };

  const validate = () => {
    const errs = {};
    if (!form.name) errs.name = 'Name is required';
    if (!form.email) {
      errs.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errs.email = 'Enter a valid email address';
    }
    if (!form.subject) errs.subject = 'Subject is required';
    if (!form.message) {
      errs.message = 'Message is required';
    } else if (form.message.length < 10) {
      errs.message = 'Message must be at least 10 characters';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) {
      show('Please fix the errors in the form.', 'error');
      return;
    }
    setSubmitted(true);
    show('Message sent successfully!', 'success');
  };

  const contactInfo = [
    { icon: MapPin, title: 'Address', value: 'Hi-Tech City, Hyderabad, Telangana 500081' },
    { icon: Phone, title: 'Phone', value: '+91 80000 12345' },
    { icon: Mail, title: 'Email', value: 'support@autonest.in' },
    { icon: Clock, title: 'Hours', value: 'Mon–Sat, 9:00 AM – 7:00 PM IST' },
  ];

  const errorText = 'mt-1 text-xs font-medium text-red-500';
  const labelClass = 'mb-1 block text-sm font-semibold text-navy-700';

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-extrabold tracking-tight text-navy-900 sm:text-3xl">Get in Touch</h1>
        <p className="mt-2 text-sm text-navy-500">Have questions? We are here to help. Reach out and we will respond within 24 hours.</p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-1">
          {contactInfo.map((info) => (
            <div key={info.title} className="card flex items-start gap-3 p-4">
              <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-accent-50 text-accent-500">
                <info.icon size={20} />
              </div>
              <div>
                <p className="text-sm font-bold text-navy-900">{info.title}</p>
                <p className="mt-0.5 text-sm text-navy-500">{info.value}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="lg:col-span-2">
          <div className="rounded-2xl bg-white p-6 shadow-card sm:p-8">
            {submitted ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                  <CheckCircle2 size={36} className="text-green-600" />
                </div>
                <h2 className="mt-4 text-xl font-bold text-navy-900">Message Sent!</h2>
                <p className="mt-2 max-w-sm text-sm text-navy-500">Thank you for reaching out. Our team will get back to you within 24 hours.</p>
                <button onClick={() => { setSubmitted(false); setForm({ name: '', email: '', subject: '', message: '' }); }} className="mt-6 btn-secondary">
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor="name" className={labelClass}>Name</label>
                    <input id="name" type="text" name="name" value={form.name} onChange={handleChange} placeholder="Your name" className={`input-field ${errors.name ? 'border-red-400' : ''}`} aria-required="true" aria-invalid={!!errors.name} />
                    {errors.name && <p className={errorText}>{errors.name}</p>}
                  </div>
                  <div>
                    <label htmlFor="email" className={labelClass}>Email</label>
                    <input id="email" type="email" name="email" value={form.email} onChange={handleChange} placeholder="you@example.com" className={`input-field ${errors.email ? 'border-red-400' : ''}`} aria-required="true" aria-invalid={!!errors.email} />
                    {errors.email && <p className={errorText}>{errors.email}</p>}
                  </div>
                </div>
                <div>
                  <label htmlFor="subject" className={labelClass}>Subject</label>
                  <input id="subject" type="text" name="subject" value={form.subject} onChange={handleChange} placeholder="What is this about?" className={`input-field ${errors.subject ? 'border-red-400' : ''}`} aria-required="true" aria-invalid={!!errors.subject} />
                  {errors.subject && <p className={errorText}>{errors.subject}</p>}
                </div>
                <div>
                  <label htmlFor="message" className={labelClass}>Message</label>
                  <textarea id="message" name="message" value={form.message} onChange={handleChange} rows={5} placeholder="Tell us how we can help..." className={`input-field resize-none ${errors.message ? 'border-red-400' : ''}`} aria-required="true" aria-invalid={!!errors.message} />
                  {errors.message && <p className={errorText}>{errors.message}</p>}
                </div>
                <button type="submit" className="btn-primary w-full sm:w-auto">
                  <Send size={18} /> Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
