import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  User, Mail, Calendar, LogOut, Heart, GitCompare, Car, Tag, Settings,
  Trash2, Eye, Plus, MapPin, Fuel, Settings2, Gauge, Phone, MessageSquare,
  CheckCircle2, X, Save, ChevronDown,
} from 'lucide-react';
import {
  getUser, removeUser, updateUser, getFavorites, getCompareList,
  getListings, deleteListing, getEnquiries, deleteEnquiry,
} from '@/utils/storage';
import { formatPrice, formatKm, getVehicleById, cities } from '@/data/vehicles';
import ImageWithFallback from '@/components/ImageWithFallback';

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUserState] = useState(null);
  const [listings, setListings] = useState([]);
  const [enquiries, setEnquiries] = useState([]);
  const [favIds, setFavIds] = useState([]);
  const [compareIds, setCompareIds] = useState([]);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [editForm, setEditForm] = useState({ name: '', email: '', mobile: '', city: '' });
  const [editErrors, setEditErrors] = useState({});
  const [profileSaved, setProfileSaved] = useState(false);

  useEffect(() => {
    const u = getUser();
    if (!u) {
      navigate('/login');
      return;
    }
    setUserState(u);
    setListings(getListings());
    setEnquiries(getEnquiries());
    setFavIds(getFavorites());
    setCompareIds(getCompareList());
    setEditForm({ name: u.name || '', email: u.email || '', mobile: u.mobile || '', city: u.city || '' });
  }, [navigate]);

  if (!user) return null;

  const myListings = listings.filter((l) => !l.userEmail || l.userEmail === (user.email || user.mobile));
  const favVehicles = favIds.map((id) => getVehicleById(id)).filter(Boolean);
  const compareVehicles = compareIds.map((id) => getVehicleById(id)).filter(Boolean);

  const handleLogout = () => {
    removeUser();
    navigate('/');
  };

  const handleDeleteListing = (id) => setListings(deleteListing(id));
  const handleDeleteEnquiry = (id) => setEnquiries(deleteEnquiry(id));

  const validateEdit = () => {
    const errs = {};
    if (!editForm.name) errs.name = 'Name is required';
    if (!editForm.email) {
      errs.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editForm.email)) {
      errs.email = 'Enter a valid email address';
    }
    if (editForm.mobile && !/^[6-9]\d{9}$/.test(editForm.mobile.replace(/\s|-/g, ''))) {
      errs.mobile = 'Enter a valid 10-digit Indian mobile number';
    }
    setEditErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSaveProfile = (e) => {
    e.preventDefault();
    if (!validateEdit()) return;
    const updated = updateUser(editForm);
    setUserState(updated);
    setShowEditProfile(false);
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 3000);
  };

  const stats = [
    { icon: Heart, label: 'Favorites', value: favVehicles.length, link: '/favorites', color: 'text-red-500 bg-red-50' },
    { icon: GitCompare, label: 'Comparing', value: compareVehicles.length, link: '/compare', color: 'text-blue-500 bg-blue-50' },
    { icon: Tag, label: 'Listings', value: myListings.length, link: '/sell', color: 'text-accent-500 bg-accent-50' },
    { icon: MessageSquare, label: 'Enquiries', value: enquiries.length, link: '#enquiries', color: 'text-green-500 bg-green-50' },
  ];

  const actions = [
    { icon: Car, label: 'Browse Cars', desc: 'Explore available listings', link: '/vehicles' },
    { icon: Tag, label: 'Sell Your Car', desc: 'List a new vehicle', link: '/sell' },
    { icon: Heart, label: 'View Favorites', desc: `${favVehicles.length} saved cars`, link: '/favorites' },
    { icon: GitCompare, label: 'Compare Cars', desc: `${compareVehicles.length} in comparison`, link: '/compare' },
  ];

  const errorText = 'mt-1 text-xs font-medium text-red-500';

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Profile saved toast */}
      {profileSaved && (
        <div className="mb-4 animate-fade-in rounded-xl bg-green-50 px-4 py-3 text-sm font-medium text-green-700">
          Profile updated successfully!
        </div>
      )}

      {/* Header card */}
      <div className="rounded-2xl bg-gradient-to-br from-navy-800 to-navy-950 p-6 text-white shadow-card sm:p-8">
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-accent-500 text-2xl font-extrabold">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="text-xl font-extrabold sm:text-2xl">{user.name}</h1>
              <p className="mt-1 flex items-center gap-1.5 text-sm text-navy-300"><Mail size={14} /> {user.email || user.mobile}</p>
              <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-navy-400">
                <span className="flex items-center gap-1"><Calendar size={12} /> Joined {new Date(user.joinedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                {user.mobile && <span className="flex items-center gap-1"><Phone size={12} /> {user.mobile}</span>}
                {user.city && <span className="flex items-center gap-1"><MapPin size={12} /> {user.city}</span>}
              </div>
            </div>
          </div>
          <button onClick={handleLogout} className="flex items-center gap-2 rounded-xl bg-white/10 px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-white/20">
            <LogOut size={18} /> Logout
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <Link key={s.label} to={s.link} className="card flex items-center gap-3 p-4 hover:-translate-y-0.5 hover:shadow-card-hover">
            <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${s.color}`}><s.icon size={22} /></div>
            <div><p className="text-2xl font-extrabold text-navy-900">{s.value}</p><p className="text-xs text-navy-500">{s.label}</p></div>
          </Link>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="mt-8">
        <h2 className="text-lg font-bold text-navy-900">Quick Actions</h2>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {actions.map((a) => (
            <Link key={a.label} to={a.link} className="card group flex items-center gap-4 p-5 hover:-translate-y-0.5 hover:shadow-card-hover">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-navy-50 text-navy-700 transition-all group-hover:bg-accent-500 group-hover:text-white"><a.icon size={22} /></div>
              <div className="flex-1"><p className="text-sm font-bold text-navy-900">{a.label}</p><p className="text-xs text-navy-500">{a.desc}</p></div>
            </Link>
          ))}
        </div>
      </div>

      {/* My Listings */}
      <div className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-navy-900">My Listings</h2>
          <Link to="/sell" className="btn-primary px-4 py-2 text-xs"><Plus size={16} /> Add New</Link>
        </div>
        {myListings.length === 0 ? (
          <div className="mt-4 flex flex-col items-center justify-center rounded-2xl bg-white py-12 text-center shadow-card">
            <Car size={40} className="text-navy-300" />
            <h3 className="mt-4 text-sm font-bold text-navy-900">No listings yet</h3>
            <p className="mt-1 text-xs text-navy-500">Cars you list for sale will appear here.</p>
            <Link to="/sell" className="mt-4 btn-secondary text-xs"><Tag size={16} /> Sell Your Car</Link>
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            {myListings.map((listing) => (
              <div key={listing.id} className="card flex flex-col gap-4 p-4 sm:flex-row sm:items-center">
                <div className="aspect-[16/10] w-full flex-shrink-0 overflow-hidden rounded-xl bg-navy-100 sm:h-24 sm:w-36">
                  <ImageWithFallback src={listing.images && listing.images.length > 0 ? listing.images[0] : null} alt={`${listing.brand} ${listing.model}`} className="h-full w-full object-cover" iconSize={28} />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div><h3 className="text-sm font-bold text-navy-900">{listing.brand} {listing.model}</h3><p className="text-xs text-navy-500">{listing.variant}</p></div>
                    <p className="text-sm font-extrabold text-accent-600">{formatPrice(listing.price)}</p>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-navy-500">
                    <span className="flex items-center gap-1"><Gauge size={12} /> {formatKm(listing.kilometers)}</span>
                    <span className="flex items-center gap-1"><Fuel size={12} /> {listing.fuel}</span>
                    <span className="flex items-center gap-1"><Settings2 size={12} /> {listing.transmission}</span>
                    <span className="flex items-center gap-1"><MapPin size={12} /> {listing.city}</span>
                    <span>{listing.year}</span>
                  </div>
                  <p className="mt-1 text-xs text-navy-400">Listed on {new Date(listing.dateAdded).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                </div>
                <div className="flex gap-2 sm:flex-col">
                  <Link to="/vehicles" className="flex items-center justify-center gap-1.5 rounded-lg border border-navy-200 px-3 py-2 text-xs font-semibold text-navy-700 transition-all hover:border-navy-300 hover:bg-navy-50"><Eye size={14} /> View</Link>
                  <button onClick={() => handleDeleteListing(listing.id)} className="flex items-center justify-center gap-1.5 rounded-lg border border-red-200 px-3 py-2 text-xs font-semibold text-red-500 transition-all hover:bg-red-50" aria-label={`Delete listing for ${listing.brand} ${listing.model}`}><Trash2 size={14} /> Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Enquiries */}
      <div id="enquiries" className="mt-8">
        <h2 className="flex items-center gap-2 text-lg font-bold text-navy-900">
          <MessageSquare size={20} className="text-navy-400" /> Enquiries
        </h2>
        {enquiries.length === 0 ? (
          <div className="mt-4 flex flex-col items-center justify-center rounded-2xl bg-white py-12 text-center shadow-card">
            <MessageSquare size={40} className="text-navy-300" />
            <h3 className="mt-4 text-sm font-bold text-navy-900">No enquiries yet</h3>
            <p className="mt-1 text-xs text-navy-500">When you contact a seller, your enquiries will appear here.</p>
            <Link to="/vehicles" className="mt-4 btn-secondary text-xs"><Car size={16} /> Browse Cars</Link>
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            {enquiries.map((enq) => (
              <div key={enq.id} className="card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <ImageWithFallback src={enq.vehicleImage} alt={enq.vehicleName} className="h-16 w-24 flex-shrink-0 rounded-lg object-cover" iconSize={20} />
                    <div>
                      <h3 className="text-sm font-bold text-navy-900">{enq.vehicleName}</h3>
                      <p className="text-xs text-navy-500">To: {enq.sellerName}</p>
                      <p className="mt-1 text-xs text-navy-400">{new Date(enq.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                    </div>
                  </div>
                  <button onClick={() => handleDeleteEnquiry(enq.id)} className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg border border-red-200 text-red-500 transition-all hover:bg-red-50" aria-label={`Delete enquiry for ${enq.vehicleName}`}><Trash2 size={14} /></button>
                </div>
                <div className="mt-3 rounded-lg bg-navy-50 p-3">
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-navy-500">
                    <span className="flex items-center gap-1"><User size={12} /> {enq.buyerName}</span>
                    <span className="flex items-center gap-1"><Mail size={12} /> {enq.buyerEmail}</span>
                    <span className="flex items-center gap-1"><Phone size={12} /> {enq.buyerPhone}</span>
                  </div>
                  <p className="mt-2 text-sm text-navy-700">{enq.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Favorites preview */}
      {favVehicles.length > 0 && (
        <div className="mt-8">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-bold text-navy-900"><Heart size={20} className="text-red-400" /> Saved Favorites</h2>
            <Link to="/favorites" className="text-sm font-semibold text-accent-600 hover:text-accent-700">View All</Link>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {favVehicles.slice(0, 3).map((v) => (
              <Link key={v.id} to={`/vehicles/${v.id}`} className="card flex items-center gap-3 p-3 hover:-translate-y-0.5 hover:shadow-card-hover">
                <ImageWithFallback src={v.images[0]} alt={`${v.brand} ${v.model}`} className="h-16 w-24 flex-shrink-0 rounded-lg object-cover" iconSize={20} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold text-navy-900">{v.brand} {v.model}</p>
                  <p className="text-xs text-navy-500">{v.year} · {formatKm(v.kilometers)}</p>
                  <p className="text-sm font-extrabold text-accent-600">{formatPrice(v.price)}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Compare preview */}
      {compareVehicles.length > 0 && (
        <div className="mt-8">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-bold text-navy-900"><GitCompare size={20} className="text-blue-400" /> Compared Vehicles</h2>
            <Link to="/compare" className="text-sm font-semibold text-accent-600 hover:text-accent-700">View All</Link>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {compareVehicles.slice(0, 4).map((v) => (
              <Link key={v.id} to={`/vehicles/${v.id}`} className="card flex items-center gap-3 p-3 hover:-translate-y-0.5 hover:shadow-card-hover">
                <ImageWithFallback src={v.images[0]} alt={`${v.brand} ${v.model}`} className="h-14 w-20 flex-shrink-0 rounded-lg object-cover" iconSize={20} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold text-navy-900">{v.brand} {v.model}</p>
                  <p className="text-xs text-navy-500">{formatPrice(v.price)}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Account settings / Edit Profile */}
      <div className="mt-8 rounded-2xl bg-white p-6 shadow-card">
        <div className="flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-lg font-bold text-navy-900"><Settings size={20} className="text-navy-400" /> Account Settings</h2>
          <button onClick={() => setShowEditProfile(!showEditProfile)} className="btn-ghost text-xs">
            {showEditProfile ? <><X size={16} /> Cancel</> : <><Settings size={16} /> Edit Profile</>}
          </button>
        </div>

        {showEditProfile ? (
          <form onSubmit={handleSaveProfile} className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-semibold text-navy-700">Full Name</label>
              <input type="text" value={editForm.name} onChange={(e) => { setEditForm({ ...editForm, name: e.target.value }); setEditErrors({ ...editErrors, name: undefined }); }} className={`input-field ${editErrors.name ? 'border-red-400' : ''}`} />
              {editErrors.name && <p className={errorText}>{editErrors.name}</p>}
            </div>
            <div>
              <label className="mb-1 block text-sm font-semibold text-navy-700">Email</label>
              <input type="email" value={editForm.email} onChange={(e) => { setEditForm({ ...editForm, email: e.target.value }); setEditErrors({ ...editErrors, email: undefined }); }} className={`input-field ${editErrors.email ? 'border-red-400' : ''}`} />
              {editErrors.email && <p className={errorText}>{editErrors.email}</p>}
            </div>
            <div>
              <label className="mb-1 block text-sm font-semibold text-navy-700">Mobile Number</label>
              <input type="tel" value={editForm.mobile} onChange={(e) => { setEditForm({ ...editForm, mobile: e.target.value }); setEditErrors({ ...editErrors, mobile: undefined }); }} placeholder="10-digit mobile number" className={`input-field ${editErrors.mobile ? 'border-red-400' : ''}`} />
              {editErrors.mobile && <p className={errorText}>{editErrors.mobile}</p>}
            </div>
            <div>
              <label className="mb-1 block text-sm font-semibold text-navy-700">City</label>
              <div className="relative">
                <select value={editForm.city} onChange={(e) => setEditForm({ ...editForm, city: e.target.value })} className="input-field cursor-pointer appearance-none pr-10">
                  <option value="">Select city</option>
                  {cities.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              </div>
            </div>
            <div className="sm:col-span-2">
              <button type="submit" className="btn-primary"><Save size={18} /> Save Changes</button>
            </div>
          </form>
        ) : (
          <>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="rounded-xl bg-navy-50 p-4">
                <label className="text-xs font-semibold text-navy-400">Name</label>
                <p className="mt-1 text-sm font-bold text-navy-900">{user.name}</p>
              </div>
              <div className="rounded-xl bg-navy-50 p-4">
                <label className="text-xs font-semibold text-navy-400">Email</label>
                <p className="mt-1 text-sm font-bold text-navy-900">{user.email || 'Not provided'}</p>
              </div>
              {user.mobile && (
                <div className="rounded-xl bg-navy-50 p-4">
                  <label className="text-xs font-semibold text-navy-400">Mobile</label>
                  <p className="mt-1 text-sm font-bold text-navy-900">{user.mobile}</p>
                </div>
              )}
              {user.city && (
                <div className="rounded-xl bg-navy-50 p-4">
                  <label className="text-xs font-semibold text-navy-400">City</label>
                  <p className="mt-1 text-sm font-bold text-navy-900">{user.city}</p>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
