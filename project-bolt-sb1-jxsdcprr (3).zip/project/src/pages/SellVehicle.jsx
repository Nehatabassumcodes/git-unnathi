import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  Camera, CheckCircle2, Tag, Upload, ArrowRight, ChevronDown, X,
  Save, Eye, Phone, Mail, User, Trash2, ImageIcon,
} from 'lucide-react';
import { brands, vehicleTypes, fuelTypes, transmissions, cities, formatPrice, formatKm } from '@/data/vehicles';
import { saveListing, saveDraft, getDraft, clearDraft, getUser } from '@/utils/storage';

const initialForm = {
  brand: '', model: '', variant: '', vehicleType: '', year: '',
  registrationYear: '', price: '', fuel: '', transmission: '',
  kilometers: '', owners: '1', color: '', state: '', city: '',
  area: '', pincode: '',
  description: '', features: '',
  sellerName: '', sellerPhone: '', sellerEmail: '',
};

export default function SellVehicle() {
  const [submitted, setSubmitted] = useState(false);
  const [submittedListing, setSubmitting] = useState(null);
  const [form, setForm] = useState(initialForm);
  const [images, setImages] = useState([]);
  const [errors, setErrors] = useState({});
  const [showPreview, setShowPreview] = useState(false);
  const [draftSaved, setDraftSaved] = useState(false);
  const fileInputRef = useRef(null);

  // Load draft on mount
  useEffect(() => {
    const draft = getDraft();
    if (draft) {
      setForm(draft.form || initialForm);
      setImages(draft.images || []);
    }
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: undefined });
  };

  // Image selection and preview
  const handleImageSelect = (e) => {
    const files = Array.from(e.target.files);
    files.forEach((file) => {
      if (file.size > 5 * 1024 * 1024) {
        setErrors((prev) => ({ ...prev, images: 'Each image must be under 5 MB.' }));
        return;
      }
      const reader = new FileReader();
      reader.onload = (ev) => {
        setImages((prev) => [...prev, ev.target.result]);
      };
      reader.readAsDataURL(file);
    });
    // Reset input so same file can be re-selected
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeImage = (index) => {
    setImages(images.filter((_, i) => i !== index));
  };

  // Validation
  const validate = () => {
    const errs = {};

    // Required text fields
    if (!form.brand) errs.brand = 'Brand is required';
    if (!form.model) errs.model = 'Model is required';
    if (!form.variant) errs.variant = 'Variant is required';
    if (!form.vehicleType) errs.vehicleType = 'Vehicle type is required';
    if (!form.fuel) errs.fuel = 'Fuel type is required';
    if (!form.transmission) errs.transmission = 'Transmission is required';
    if (!form.color) errs.color = 'Color is required';
    if (!form.city) errs.city = 'City is required';
    if (!form.state) errs.state = 'State is required';
    if (!form.area) errs.area = 'Area is required';
    if (!form.pincode) {
      errs.pincode = 'Pincode is required';
    } else if (!/^[1-9]\d{5}$/.test(form.pincode)) {
      errs.pincode = 'Enter a valid 6-digit Indian pincode';
    }
    if (!form.description) errs.description = 'Description is required';

    // Year validation
    const yearNum = parseInt(form.year);
    if (!form.year) {
      errs.year = 'Year is required';
    } else if (isNaN(yearNum) || yearNum < 1990 || yearNum > 2026) {
      errs.year = 'Year must be between 1990 and 2026';
    }

    // Registration year
    const regYearNum = parseInt(form.registrationYear);
    if (!form.registrationYear) {
      errs.registrationYear = 'Registration year is required';
    } else if (isNaN(regYearNum) || regYearNum < 1990 || regYearNum > 2026) {
      errs.registrationYear = 'Registration year must be between 1990 and 2026';
    } else if (regYearNum < yearNum) {
      errs.registrationYear = 'Registration year cannot be before manufacture year';
    }

    // Price validation
    const priceNum = parseInt(form.price);
    if (!form.price) {
      errs.price = 'Price is required';
    } else if (isNaN(priceNum) || priceNum < 10000) {
      errs.price = 'Price must be at least ₹10,000';
    }

    // Kilometers validation
    const kmNum = parseInt(form.kilometers);
    if (form.kilometers === '') {
      errs.kilometers = 'Kilometers is required';
    } else if (isNaN(kmNum) || kmNum < 0) {
      errs.kilometers = 'Kilometers must be a non-negative number';
    }

    // Seller fields
    if (!form.sellerName) errs.sellerName = 'Seller name is required';
    if (!form.sellerPhone) {
      errs.sellerPhone = 'Phone number is required';
    } else if (!/^[6-9]\d{9}$/.test(form.sellerPhone.replace(/\s|-/g, ''))) {
      errs.sellerPhone = 'Enter a valid 10-digit Indian mobile number';
    }
    if (!form.sellerEmail) {
      errs.sellerEmail = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.sellerEmail)) {
      errs.sellerEmail = 'Enter a valid email address';
    }

    // Images
    if (images.length === 0) {
      errs.images = 'At least one photo is required';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSaveDraft = () => {
    saveDraft({ form, images, savedAt: new Date().toISOString() });
    setDraftSaved(true);
    setTimeout(() => setDraftSaved(false), 3000);
  };

  const handlePreview = (e) => {
    e.preventDefault();
    if (validate()) {
      setShowPreview(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const user = getUser();
    const listing = {
      id: `seller-${Date.now()}`,
      brand: form.brand,
      model: form.model,
      variant: form.variant,
      vehicleType: form.vehicleType,
      year: parseInt(form.year),
      registrationYear: parseInt(form.registrationYear),
      price: parseInt(form.price),
      fuel: form.fuel,
      transmission: form.transmission,
      kilometers: parseInt(form.kilometers),
      owners: parseInt(form.owners),
      color: form.color,
      location: form.city,
      state: form.state,
      city: form.city,
      area: form.area,
      pincode: form.pincode,
      condition: 'Good',
      description: form.description,
      features: form.features
        ? form.features.split(',').map((f) => f.trim()).filter(Boolean)
        : [],
      images: images,
      seller: {
        name: form.sellerName,
        phone: form.sellerPhone,
        email: form.sellerEmail,
        type: 'Individual',
      },
      userEmail: user ? user.email : null,
      dateAdded: new Date().toISOString().split('T')[0],
      featured: false,
    };

    saveListing(listing);
    clearDraft();
    setSubmitting(listing);
    setSubmitted(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const resetForm = () => {
    setForm(initialForm);
    setImages([]);
    setErrors({});
    setSubmitted(false);
    setShowPreview(false);
    setSubmitting(null);
  };

  // === Success screen ===
  if (submitted && submittedListing) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center justify-center px-4 py-20 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-100">
          <CheckCircle2 size={44} className="text-green-600" />
        </div>
        <h1 className="mt-6 text-2xl font-extrabold text-navy-900 sm:text-3xl">Listing Submitted!</h1>
        <p className="mt-3 max-w-md text-sm text-navy-500">
          Your {submittingListing.brand} {submittingListing.model} has been listed on AutoNest. You can view it in your Dashboard under My Listings.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Link to="/dashboard" className="btn-primary">Go to Dashboard <ArrowRight size={16} /></Link>
          <button onClick={resetForm} className="btn-secondary">List Another Car</button>
        </div>
      </div>
    );
  }

  // === Preview screen ===
  if (showPreview) {
    const features = form.features
      ? form.features.split(',').map((f) => f.trim()).filter(Boolean)
      : [];

    return (
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-extrabold tracking-tight text-navy-900">Preview Listing</h1>
          <button onClick={() => setShowPreview(false)} className="btn-ghost">
            <X size={18} /> Edit
          </button>
        </div>

        {/* Preview card */}
        <div className="overflow-hidden rounded-2xl bg-white shadow-card">
          {/* Image gallery */}
          {images.length > 0 && (
            <div className="relative aspect-[16/10] bg-navy-100">
              <img src={images[0]} alt={`${form.brand} ${form.model}`} className="h-full w-full object-cover" />
              <span className="absolute left-4 top-4 rounded-md bg-navy-900/80 px-2.5 py-1 text-xs font-semibold text-white backdrop-blur-sm">
                {form.year}
              </span>
            </div>
          )}

          <div className="p-6">
            <h2 className="text-xl font-extrabold text-navy-900">{form.brand} {form.model}</h2>
            <p className="mt-0.5 text-sm text-navy-500">{form.variant}</p>

            {/* Specs */}
            <div className="mt-4 grid grid-cols-2 gap-y-2 text-sm text-navy-600 sm:grid-cols-4">
              <span><strong className="block text-xs text-navy-400">Price</strong> {formatPrice(parseInt(form.price))}</span>
              <span><strong className="block text-xs text-navy-400">Kilometers</strong> {formatKm(parseInt(form.kilometers))}</span>
              <span><strong className="block text-xs text-navy-400">Fuel</strong> {form.fuel}</span>
              <span><strong className="block text-xs text-navy-400">Transmission</strong> {form.transmission}</span>
              <span><strong className="block text-xs text-navy-400">Owners</strong> {form.owners}</span>
              <span><strong className="block text-xs text-navy-400">Color</strong> {form.color}</span>
              <span><strong className="block text-xs text-navy-400">Location</strong> {form.city}, {form.state}{form.area ? `, ${form.area}` : ''} {form.pincode || ''}</span>
              <span><strong className="block text-xs text-navy-400">Type</strong> {form.vehicleType}</span>
            </div>

            {/* Description */}
            <div className="mt-5 border-t border-navy-100 pt-4">
              <h3 className="text-sm font-bold text-navy-900">Description</h3>
              <p className="mt-2 text-sm leading-relaxed text-navy-600">{form.description}</p>
            </div>

            {/* Features */}
            {features.length > 0 && (
              <div className="mt-5 border-t border-navy-100 pt-4">
                <h3 className="text-sm font-bold text-navy-900">Features</h3>
                <div className="mt-2 flex flex-wrap gap-2">
                  {features.map((f) => (
                    <span key={f} className="rounded-md bg-navy-50 px-2.5 py-1 text-xs text-navy-700">{f}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Seller info */}
            <div className="mt-5 border-t border-navy-100 pt-4">
              <h3 className="text-sm font-bold text-navy-900">Seller Information</h3>
              <div className="mt-2 grid grid-cols-1 gap-2 text-sm text-navy-600 sm:grid-cols-3">
                <span className="flex items-center gap-1.5"><User size={14} className="text-navy-400" /> {form.sellerName}</span>
                <span className="flex items-center gap-1.5"><Phone size={14} className="text-navy-400" /> {form.sellerPhone}</span>
                <span className="flex items-center gap-1.5"><Mail size={14} className="text-navy-400" /> {form.sellerEmail}</span>
              </div>
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="mt-5 border-t border-navy-100 pt-4">
                <h3 className="text-sm font-bold text-navy-900">All Photos ({images.length})</h3>
                <div className="mt-2 flex gap-2 overflow-x-auto">
                  {images.map((img, i) => (
                    <img key={i} src={img} alt={`Photo ${i + 1}`} className="h-20 w-28 flex-shrink-0 rounded-lg object-cover" />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex flex-col gap-3 pb-8 sm:flex-row sm:justify-end">
          <button onClick={() => setShowPreview(false)} className="btn-secondary">Back to Edit</button>
          <button onClick={handleSubmit} className="btn-primary">
            <CheckCircle2 size={18} /> Submit Listing
          </button>
        </div>
      </div>
    );
  }

  // === Form ===
  const inputClass = 'input-field';
  const labelClass = 'mb-1 block text-sm font-semibold text-navy-700';
  const errorClass = 'mt-1 text-xs font-medium text-red-500';

  const Select = ({ name, label, value, options, placeholder }) => (
    <div>
      <label htmlFor={`field-${name}`} className={labelClass}>{label}</label>
      <div className="relative">
        <select
          id={`field-${name}`}
          name={name}
          value={value}
          onChange={handleChange}
          className={`${inputClass} cursor-pointer appearance-none pr-10 ${errors[name] ? 'border-red-400' : ''}`}
        >
          <option value="">{placeholder}</option>
          {options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
      </div>
      {errors[name] && <p className={errorClass}>{errors[name]}</p>}
    </div>
  );

  const Field = ({ name, label, type = 'text', placeholder, min, max }) => (
    <div>
      <label htmlFor={`field-${name}`} className={labelClass}>{label}</label>
      <input
        id={`field-${name}`}
        name={name}
        type={type}
        min={min}
        max={max}
        value={form[name]}
        onChange={handleChange}
        placeholder={placeholder}
        className={`${inputClass} ${errors[name] ? 'border-red-400' : ''}`}
      />
      {errors[name] && <p className={errorClass}>{errors[name]}</p>}
    </div>
  );

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-extrabold tracking-tight text-navy-900 sm:text-3xl">Sell Your Car</h1>
        <p className="mt-2 text-sm text-navy-500">List your car in minutes and reach thousands of genuine buyers. It is free.</p>
      </div>

      {/* Steps */}
      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
        {[
          { icon: Tag, title: '1. Enter Details', desc: 'Tell us about your car' },
          { icon: Camera, title: '2. Add Photos', desc: 'Upload clear images' },
          { icon: CheckCircle2, title: '3. Get Inquiries', desc: 'Receive buyer calls' },
        ].map((step) => (
          <div key={step.title} className="card flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-accent-50 text-accent-500">
              <step.icon size={20} />
            </div>
            <div>
              <p className="text-sm font-bold text-navy-900">{step.title}</p>
              <p className="text-xs text-navy-500">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Draft saved toast */}
      {draftSaved && (
        <div className="mb-4 animate-fade-in rounded-xl bg-green-50 px-4 py-3 text-sm font-medium text-green-700">
          Draft saved! You can come back later and continue.
        </div>
      )}

      <form onSubmit={handlePreview} className="space-y-6">
        {/* Seller Information */}
        <div className="rounded-2xl bg-white p-6 shadow-card">
          <h2 className="text-lg font-bold text-navy-900">Seller Information</h2>
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Field name="sellerName" label="Seller Name" placeholder="Your full name" />
            <Field name="sellerPhone" label="Phone Number" placeholder="10-digit mobile number" />
            <Field name="sellerEmail" label="Email" type="email" placeholder="you@example.com" />
          </div>
        </div>

        {/* Vehicle Information */}
        <div className="rounded-2xl bg-white p-6 shadow-card">
          <h2 className="text-lg font-bold text-navy-900">Vehicle Information</h2>
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Select name="brand" label="Brand" value={form.brand} options={brands} placeholder="Select Brand" />
            <Field name="model" label="Model" placeholder="e.g. Swift, City, Creta" />
            <Field name="variant" label="Variant" placeholder="e.g. VXi, SX, ZX" />
            <Select name="vehicleType" label="Vehicle Type" value={form.vehicleType} options={vehicleTypes} placeholder="Select Type" />
          </div>
        </div>

        {/* Specifications */}
        <div className="rounded-2xl bg-white p-6 shadow-card">
          <h2 className="text-lg font-bold text-navy-900">Specifications</h2>
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Field name="year" label="Year" type="number" min="1990" max="2026" placeholder="e.g. 2021" />
            <Field name="registrationYear" label="Registration Year" type="number" min="1990" max="2026" placeholder="e.g. 2021" />
            <Field name="price" label="Price (₹)" type="number" min="10000" placeholder="e.g. 595000" />
            <Select name="fuel" label="Fuel Type" value={form.fuel} options={fuelTypes} placeholder="Select Fuel" />
            <Select name="transmission" label="Transmission" value={form.transmission} options={transmissions} placeholder="Select Transmission" />
            <Field name="kilometers" label="Kilometers Driven" type="number" min="0" placeholder="e.g. 18500" />
            <div>
              <label htmlFor="field-owners" className={labelClass}>Number of Owners</label>
              <select id="field-owners" name="owners" value={form.owners} onChange={handleChange} className={`${inputClass} cursor-pointer`}>
                <option value="1">1st Owner</option>
                <option value="2">2nd Owner</option>
                <option value="3">3rd Owner</option>
                <option value="4">4th+ Owner</option>
              </select>
            </div>
            <Field name="color" label="Color" placeholder="e.g. Pearl White" />
          </div>
        </div>

        {/* Location */}
        <div className="rounded-2xl bg-white p-6 shadow-card">
          <h2 className="text-lg font-bold text-navy-900">Location</h2>
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Select name="city" label="City" value={form.city} options={cities} placeholder="Select City" />
            <Field name="state" label="State" placeholder="e.g. Telangana" />
            <Field name="area" label="Area" placeholder="e.g. Hi-Tech City" />
            <Field name="pincode" label="Pincode" placeholder="e.g. 500081" />
          </div>
        </div>

        {/* Description & Features */}
        <div className="rounded-2xl bg-white p-6 shadow-card">
          <h2 className="text-lg font-bold text-navy-900">Description &amp; Features</h2>
          <div className="mt-5 space-y-4">
            <div>
              <label htmlFor="field-description" className={labelClass}>Description</label>
              <textarea
                id="field-description"
                name="description"
                value={form.description}
                onChange={handleChange}
                rows={4}
                placeholder="Describe your car's condition, service history, and any notable features..."
                className={`${inputClass} resize-none ${errors.description ? 'border-red-400' : ''}`}
              />
              {errors.description && <p className={errorClass}>{errors.description}</p>}
            </div>
            <div>
              <label htmlFor="field-features" className={labelClass}>Features (comma-separated)</label>
              <input id="field-features" name="features" value={form.features} onChange={handleChange} placeholder="e.g. Sunroof, ABS, Airbags, Alloy Wheels" className={inputClass} />
            </div>
          </div>
        </div>

        {/* Photos with multi-select and preview */}
        <div className="rounded-2xl bg-white p-6 shadow-card">
          <h2 className="text-lg font-bold text-navy-900">Upload Photos</h2>
          <p className="mt-1 text-xs text-navy-500">Add clear photos of your car — exterior, interior, and engine bay. Max 5 MB per image.</p>

          {/* Upload area */}
          <label
            className="mt-4 flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-navy-200 bg-navy-50 py-8 transition-all hover:border-accent-400 hover:bg-accent-50"
          >
            <Upload size={28} className="text-navy-400" />
            <span className="text-sm font-semibold text-navy-600">Click to select photos</span>
            <span className="text-xs text-navy-400">You can select multiple images at once</span>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageSelect}
              className="hidden"
            />
          </label>

          {errors.images && <p className={`mt-2 ${errorClass}`}>{errors.images}</p>}

          {/* Image previews */}
          {images.length > 0 && (
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {images.map((img, i) => (
                <div key={i} className="group relative aspect-square overflow-hidden rounded-xl border border-navy-200">
                  <img src={img} alt={`Upload ${i + 1}`} className="h-full w-full object-cover" />
                  {i === 0 && (
                    <span className="absolute left-2 top-2 rounded bg-accent-500 px-1.5 py-0.5 text-xs font-bold text-white">
                      Cover
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => removeImage(i)}
                    className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-red-50 text-red-500 opacity-0 shadow-sm transition-all group-hover:opacity-100 hover:bg-red-100"
                    aria-label={`Remove photo ${i + 1}`}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {images.length > 0 && (
            <p className="mt-3 text-xs text-navy-400">{images.length} photo{images.length > 1 ? 's' : ''} selected</p>
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-3 pb-8 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex gap-3">
            <Link to="/" className="btn-secondary">Cancel</Link>
            <button type="button" onClick={handleSaveDraft} className="btn-ghost">
              <Save size={18} /> Save Draft
            </button>
          </div>
          <div className="flex gap-3">
            <button type="submit" className="btn-secondary">
              <Eye size={18} /> Preview Listing
            </button>
            <button type="button" onClick={handleSubmit} className="btn-primary">
              <CheckCircle2 size={18} /> Submit Listing
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
