import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Heart, GitCompare, ChevronLeft, MapPin, Fuel, Settings2, Gauge, Calendar,
  Users, Palette, Phone, CheckCircle2, ArrowRight, BadgeCheck, X, Mail, User, Send, Car, Share2,
} from 'lucide-react';
import {
  getVehicleById, getRelatedVehicles, formatPrice, formatKm,
} from '@/data/vehicles';
import {
  toggleFavorite, isFavorite, toggleCompare, isCompared, getUser, saveEnquiry,
} from '@/utils/storage';
import VehicleCard from '@/components/VehicleCard';
import ImageWithFallback from '@/components/ImageWithFallback';
import LoadingSpinner from '@/components/LoadingSpinner';

export default function VehicleDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const vehicle = getVehicleById(id);

  const [fav, setFav] = useState(false);
  const [compared, setCompared] = useState(false);
  const [compareError, setCompareError] = useState(null);
  const [showContactForm, setShowContactForm] = useState(false);
  const [contactSuccess, setContactSuccess] = useState(false);
  const [contactForm, setContactForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [contactErrors, setContactErrors] = useState({});
  const [activeImage, setActiveImage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [shareMessage, setShareMessage] = useState('');

  useEffect(() => {
    if (vehicle) {
      setLoading(true);
      const timer = setTimeout(() => setLoading(false), 400);
      setFav(isFavorite(vehicle.id));
      setCompared(isCompared(vehicle.id));
      setActiveImage(0);
      setShowContactForm(false);
      setContactSuccess(false);
      return () => clearTimeout(timer);
    }
  }, [vehicle]);

  if (!vehicle) {
    return (
      <div className="mx-auto flex max-w-3xl flex-col items-center justify-center px-4 py-20 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-red-50">
          <Car size={40} className="text-red-400" />
        </div>
        <h1 className="mt-6 text-2xl font-extrabold text-navy-900">Vehicle Not Found</h1>
        <p className="mt-2 max-w-sm text-sm text-navy-500">This listing may have been removed, sold, or the link is invalid. Please browse our available cars.</p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <Link to="/vehicles" className="btn-primary">Browse All Cars</Link>
          <Link to="/" className="btn-secondary">Back to Home</Link>
        </div>
      </div>
    );
  }

  if (loading) {
    return <LoadingSpinner label="Loading vehicle details..." />;
  }

  const related = getRelatedVehicles(vehicle);
  const user = getUser();

  const handleShare = async () => {
    const shareUrl = window.location.href;
    const shareTitle = `${vehicle.brand} ${vehicle.model} ${vehicle.variant} — ${formatPrice(vehicle.price)}`;
    const shareText = `Check out this ${vehicle.brand} ${vehicle.model} on AutoNest!`;
    if (navigator.share) {
      try {
        await navigator.share({ title: shareTitle, text: shareText, url: shareUrl });
      } catch (e) {
        // user cancelled — do nothing
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareUrl);
        setShareMessage('Link copied to clipboard!');
      } catch {
        setShareMessage('Copy not supported — please copy the URL manually.');
      }
      setTimeout(() => setShareMessage(''), 3000);
    }
  };

  const handleFav = () => {
    const updated = toggleFavorite(vehicle.id);
    setFav(updated.includes(vehicle.id));
  };

  const handleCompare = () => {
    const result = toggleCompare(vehicle.id);
    setCompared(result.list.includes(vehicle.id));
    if (result.error) {
      setCompareError(result.error);
      setTimeout(() => setCompareError(null), 3000);
    }
  };

  const handleContactSeller = () => {
    const u = getUser();
    if (!u) {
      navigate('/login');
      return;
    }
    // Pre-fill from user profile
    setContactForm({
      name: u.name || '',
      email: u.email || '',
      phone: u.mobile || '',
      message: '',
    });
    setShowContactForm(true);
    setContactSuccess(false);
  };

  const validateContact = () => {
    const errs = {};
    if (!contactForm.name) errs.name = 'Name is required';
    if (!contactForm.email) {
      errs.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactForm.email)) {
      errs.email = 'Enter a valid email address';
    }
    if (!contactForm.phone) {
      errs.phone = 'Phone number is required';
    } else if (!/^[6-9]\d{9}$/.test(contactForm.phone.replace(/\s|-/g, ''))) {
      errs.phone = 'Enter a valid 10-digit Indian mobile number';
    }
    if (!contactForm.message) {
      errs.message = 'Please enter a message';
    } else if (contactForm.message.length < 10) {
      errs.message = 'Message must be at least 10 characters';
    }
    setContactErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleContactSubmit = (e) => {
    e.preventDefault();
    if (!validateContact()) return;
    saveEnquiry({
      id: `enq-${Date.now()}`,
      vehicleId: vehicle.id,
      vehicleName: `${vehicle.brand} ${vehicle.model} ${vehicle.variant}`,
      vehicleImage: vehicle.images[0],
      sellerName: vehicle.seller.name,
      buyerName: contactForm.name,
      buyerEmail: contactForm.email,
      buyerPhone: contactForm.phone,
      message: contactForm.message,
      date: new Date().toISOString(),
    });
    setContactSuccess(true);
  };

  const conditionColor = vehicle.condition === 'Excellent' ? 'text-green-600 bg-green-50' : vehicle.condition === 'Good' ? 'text-blue-600 bg-blue-50' : 'text-amber-600 bg-amber-50';

  const specs = [
    { icon: Calendar, label: 'Year', value: vehicle.year },
    { icon: Gauge, label: 'Kilometers', value: formatKm(vehicle.kilometers) },
    { icon: Fuel, label: 'Fuel', value: vehicle.fuel },
    { icon: Settings2, label: 'Transmission', value: vehicle.transmission },
    { icon: Users, label: 'Owners', value: `${vehicle.owners} Owner${vehicle.owners > 1 ? 's' : ''}` },
    { icon: Palette, label: 'Color', value: vehicle.color },
  ];

  const errorText = 'mt-1 text-xs font-medium text-red-500';

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      {/* Breadcrumb */}
      <div className="mb-4 flex items-center gap-2 text-sm text-navy-500">
        <Link to="/" className="hover:text-accent-600">Home</Link>
        <span>/</span>
        <Link to="/vehicles" className="hover:text-accent-600">Cars</Link>
        <span>/</span>
        <span className="font-medium text-navy-800">{vehicle.brand} {vehicle.model}</span>
      </div>

      <button onClick={() => navigate(-1)} className="mb-4 flex items-center gap-1 text-sm font-medium text-navy-600 hover:text-accent-600">
        <ChevronLeft size={18} /> Back
      </button>

      {compareError && (
        <div className="mb-4 rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700">{compareError}</div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Left: Gallery + details */}
        <div className="lg:col-span-2">
          {/* Main image */}
          <div className="relative aspect-[16/10] overflow-hidden rounded-2xl bg-navy-100 shadow-card">
            <ImageWithFallback src={vehicle.images[activeImage]} alt={`${vehicle.brand} ${vehicle.model} ${vehicle.variant} — view ${activeImage + 1}`} className="h-full w-full object-cover" />
            {vehicle.featured && (
              <span className="absolute left-4 top-4 rounded-md bg-accent-500 px-3 py-1 text-xs font-bold text-white shadow-sm">Featured</span>
            )}
          </div>

          {/* Thumbnails */}
          {vehicle.images.length > 1 && (
            <div className="mt-3 flex gap-3">
              {vehicle.images.map((img, i) => (
                <button key={i} onClick={() => setActiveImage(i)} aria-label={`View image ${i + 1} of ${vehicle.images.length}`} aria-pressed={activeImage === i} className={`aspect-[16/10] w-32 overflow-hidden rounded-lg border-2 transition-all ${activeImage === i ? 'border-accent-500' : 'border-transparent opacity-70 hover:opacity-100'}`}>
                  <ImageWithFallback src={img} alt={`${vehicle.brand} ${vehicle.model} thumbnail ${i + 1}`} className="h-full w-full object-cover" iconSize={20} />
                </button>
              ))}
            </div>
          )}

          {/* Description */}
          <div className="mt-6 rounded-2xl bg-white p-6 shadow-card">
            <h2 className="text-lg font-bold text-navy-900">About This Car</h2>
            <p className="mt-3 text-sm leading-relaxed text-navy-600">{vehicle.description}</p>
          </div>

          {/* Specifications */}
          <div className="mt-6 rounded-2xl bg-white p-6 shadow-card">
            <h2 className="text-lg font-bold text-navy-900">Specifications</h2>
            <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3">
              {specs.map((s) => (
                <div key={s.label} className="flex flex-col gap-1 rounded-xl bg-navy-50 p-3">
                  <span className="flex items-center gap-1.5 text-xs font-medium text-navy-400"><s.icon size={14} /> {s.label}</span>
                  <span className="text-sm font-bold text-navy-900">{s.value}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 border-t border-navy-100 pt-4 text-sm sm:grid-cols-3">
              <div><span className="text-navy-400">Registration Year</span><p className="font-semibold text-navy-800">{vehicle.registrationYear}</p></div>
              <div><span className="text-navy-400">Location</span><p className="font-semibold text-navy-800">{vehicle.city}, {vehicle.state}</p></div>
              <div><span className="text-navy-400">Listed On</span><p className="font-semibold text-navy-800">{new Date(vehicle.dateAdded).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p></div>
            </div>
          </div>

          {/* Features */}
          <div className="mt-6 rounded-2xl bg-white p-6 shadow-card">
            <h2 className="text-lg font-bold text-navy-900">Features &amp; Equipment</h2>
            <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {vehicle.features.map((f) => (
                <div key={f} className="flex items-center gap-2 text-sm text-navy-700">
                  <CheckCircle2 size={16} className="flex-shrink-0 text-accent-500" />{f}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Price card + actions + contact form */}
        <div className="lg:col-span-1">
          <div className="sticky top-20 space-y-4">
            {/* Price card */}
            <div className="rounded-2xl bg-white p-6 shadow-card">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-xl font-extrabold text-navy-900">{vehicle.brand} {vehicle.model}</h1>
                  <p className="text-sm text-navy-500">{vehicle.variant}</p>
                </div>
                <button onClick={handleFav} className="flex h-10 w-10 items-center justify-center rounded-full bg-navy-50 transition-all hover:scale-110" aria-label={fav ? 'Remove from favorites' : 'Add to favorites'}>
                  <Heart size={20} className={fav ? 'fill-accent-500 text-accent-500' : 'text-navy-600'} />
                </button>
              </div>

              <div className="mt-4">
                <p className="text-3xl font-extrabold text-accent-600">{formatPrice(vehicle.price)}</p>
                <p className="mt-1 text-xs text-navy-400">Fixed price · Negotiable on inspection</p>
              </div>

              <div className="mt-3">
                <span className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold ${conditionColor}`}>
                  <CheckCircle2 size={14} /> Condition: {vehicle.condition}
                </span>
              </div>

              <div className="mt-4 flex items-center gap-2 text-sm text-navy-600">
                <MapPin size={16} className="text-navy-400" />{vehicle.location}, {vehicle.state}
              </div>

              {/* Actions */}
              <div className="mt-5 space-y-2.5">
                <button onClick={handleContactSeller} className="btn-primary w-full">
                  <Phone size={18} /> Contact Seller
                </button>
                <button onClick={handleCompare} className={`w-full rounded-xl border px-4 py-3 text-sm font-semibold transition-all ${compared ? 'border-accent-500 bg-accent-50 text-accent-600' : 'border-navy-200 text-navy-700 hover:border-navy-300 hover:bg-navy-50'}`}>
                  <GitCompare size={18} className="inline" /> {compared ? 'Added to Compare' : 'Add to Compare'}
                </button>
                <button onClick={handleShare} className="w-full rounded-xl border border-navy-200 px-4 py-3 text-sm font-semibold text-navy-700 transition-all hover:border-navy-300 hover:bg-navy-50">
                  <Share2 size={18} className="inline" /> Share This Listing
                </button>
                {shareMessage && (
                  <div className="animate-fade-in rounded-xl bg-green-50 px-4 py-2.5 text-center text-sm font-medium text-green-700">
                    {shareMessage}
                  </div>
                )}
                <Link to="/compare" className="btn-secondary w-full">View Comparison Page</Link>
              </div>

              {/* Contact form */}
              {showContactForm && (
                <div className="mt-4 animate-fade-in rounded-xl border border-navy-100 bg-navy-50 p-4">
                  {contactSuccess ? (
                    <div className="text-center">
                      <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                        <CheckCircle2 size={28} className="text-green-600" />
                      </div>
                      <p className="mt-3 text-sm font-bold text-navy-900">Enquiry Sent!</p>
                      <p className="mt-1 text-xs text-navy-500">The seller will get back to you soon. You can track this in your Dashboard.</p>
                      <button onClick={() => { setShowContactForm(false); setContactSuccess(false); }} className="mt-3 text-xs font-semibold text-accent-600 hover:text-accent-700">Close</button>
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-navy-900">Contact the Seller</h3>
                        <button onClick={() => setShowContactForm(false)} className="flex h-6 w-6 items-center justify-center rounded hover:bg-navy-100">
                          <X size={16} className="text-navy-400" />
                        </button>
                      </div>
                      <p className="mt-1 text-xs text-navy-500">Send a message to {vehicle.seller.name}</p>
                      <form onSubmit={handleContactSubmit} className="mt-3 space-y-3">
                        <div>
                          <div className="relative">
                            <User className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={16} />
                            <input type="text" placeholder="Your name" value={contactForm.name} onChange={(e) => { setContactForm({ ...contactForm, name: e.target.value }); setContactErrors({ ...contactErrors, name: undefined }); }} className={`input-field pl-9 py-2.5 text-sm ${contactErrors.name ? 'border-red-400' : ''}`} />
                          </div>
                          {contactErrors.name && <p className={errorText}>{contactErrors.name}</p>}
                        </div>
                        <div>
                          <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={16} />
                            <input type="email" placeholder="Your email" value={contactForm.email} onChange={(e) => { setContactForm({ ...contactForm, email: e.target.value }); setContactErrors({ ...contactErrors, email: undefined }); }} className={`input-field pl-9 py-2.5 text-sm ${contactErrors.email ? 'border-red-400' : ''}`} />
                          </div>
                          {contactErrors.email && <p className={errorText}>{contactErrors.email}</p>}
                        </div>
                        <div>
                          <div className="relative">
                            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={16} />
                            <input type="tel" placeholder="Your phone" value={contactForm.phone} onChange={(e) => { setContactForm({ ...contactForm, phone: e.target.value }); setContactErrors({ ...contactErrors, phone: undefined }); }} className={`input-field pl-9 py-2.5 text-sm ${contactErrors.phone ? 'border-red-400' : ''}`} />
                          </div>
                          {contactErrors.phone && <p className={errorText}>{contactErrors.phone}</p>}
                        </div>
                        <div>
                          <textarea placeholder="Your message to the seller..." value={contactForm.message} onChange={(e) => { setContactForm({ ...contactForm, message: e.target.value }); setContactErrors({ ...contactErrors, message: undefined }); }} rows={3} className={`input-field resize-none py-2.5 text-sm ${contactErrors.message ? 'border-red-400' : ''}`} />
                          {contactErrors.message && <p className={errorText}>{contactErrors.message}</p>}
                        </div>
                        <button type="submit" className="btn-primary w-full py-2.5 text-sm">
                          <Send size={16} /> Send Enquiry
                        </button>
                      </form>
                    </>
                  )}
                </div>
              )}

              {/* Trust badges */}
              <div className="mt-5 space-y-2 border-t border-navy-100 pt-4">
                <div className="flex items-center gap-2 text-xs text-navy-600"><BadgeCheck size={16} className="text-green-500" /> Verified Listing</div>
                <div className="flex items-center gap-2 text-xs text-navy-600"><CheckCircle2 size={16} className="text-green-500" /> Quality Checked</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Related vehicles */}
      {related.length > 0 && (
        <div className="mt-12">
          <div className="flex items-end justify-between">
            <h2 className="section-title">Similar Cars</h2>
            <Link to="/vehicles" className="hidden items-center gap-1 text-sm font-semibold text-accent-600 hover:text-accent-700 sm:flex">View All <ArrowRight size={16} /></Link>
          </div>
          <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((v) => <VehicleCard key={v.id} vehicle={v} />)}
          </div>
        </div>
      )}
    </div>
  );
}
