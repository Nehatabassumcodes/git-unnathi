import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Car, Mail, Lock, User, Eye, EyeOff, ArrowRight, Phone, MapPin, ChevronDown } from 'lucide-react';
import { setUser } from '@/utils/storage';
import { cities } from '@/data/vehicles';

export default function Register() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', mobile: '', city: '', password: '', confirmPassword: '' });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: undefined });
  };

  const validate = () => {
    const errs = {};
    if (!form.name) errs.name = 'Full name is required';
    if (!form.email) {
      errs.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errs.email = 'Enter a valid email address';
    }
    if (!form.mobile) {
      errs.mobile = 'Mobile number is required';
    } else if (!/^[6-9]\d{9}$/.test(form.mobile.replace(/\s|-/g, ''))) {
      errs.mobile = 'Enter a valid 10-digit Indian mobile number';
    }
    if (!form.city) errs.city = 'Please select your city';
    if (!form.password) {
      errs.password = 'Password is required';
    } else if (form.password.length < 6) {
      errs.password = 'Password must be at least 6 characters long';
    }
    if (!form.confirmPassword) {
      errs.confirmPassword = 'Please confirm your password';
    } else if (form.password !== form.confirmPassword) {
      errs.confirmPassword = 'Passwords do not match';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    setUser({
      name: form.name,
      email: form.email,
      mobile: form.mobile,
      city: form.city,
      joinedAt: new Date().toISOString(),
    });
    navigate('/dashboard');
  };

  const inputClass = (field) => `input-field pl-10 ${errors[field] ? 'border-red-400' : ''}`;
  const errorText = 'mt-1 text-xs font-medium text-red-500';

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-12 sm:px-6 lg:py-16">
      <div className="rounded-2xl bg-white p-8 shadow-card">
        <Link to="/" className="mb-6 flex items-center justify-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent-500 text-white">
            <Car size={22} strokeWidth={2.5} />
          </div>
          <span className="text-xl font-extrabold tracking-tight text-navy-900">
            Auto<span className="text-accent-500">Nest</span>
          </span>
        </Link>

        <h1 className="text-center text-2xl font-extrabold text-navy-900">Create Account</h1>
        <p className="mt-1 text-center text-sm text-navy-500">Join AutoNest to buy and sell cars with ease.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          {/* Name */}
          <div>
            <label className="mb-1 block text-sm font-semibold text-navy-700">Full Name</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              <input type="text" name="name" value={form.name} onChange={handleChange} placeholder="Your full name" className={inputClass('name')} />
            </div>
            {errors.name && <p className={errorText}>{errors.name}</p>}
          </div>

          {/* Email */}
          <div>
            <label className="mb-1 block text-sm font-semibold text-navy-700">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              <input type="email" name="email" value={form.email} onChange={handleChange} placeholder="you@example.com" className={inputClass('email')} />
            </div>
            {errors.email && <p className={errorText}>{errors.email}</p>}
          </div>

          {/* Mobile */}
          <div>
            <label className="mb-1 block text-sm font-semibold text-navy-700">Mobile Number</label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              <input type="tel" name="mobile" value={form.mobile} onChange={handleChange} placeholder="10-digit mobile number" className={inputClass('mobile')} />
            </div>
            {errors.mobile && <p className={errorText}>{errors.mobile}</p>}
          </div>

          {/* City */}
          <div>
            <label className="mb-1 block text-sm font-semibold text-navy-700">City / Location</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              <select
                name="city"
                value={form.city}
                onChange={handleChange}
                className={`${inputClass('city')} cursor-pointer appearance-none pr-10`}
              >
                <option value="">Select your city</option>
                {cities.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
            </div>
            {errors.city && <p className={errorText}>{errors.city}</p>}
          </div>

          {/* Password */}
          <div>
            <label className="mb-1 block text-sm font-semibold text-navy-700">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                value={form.password}
                onChange={handleChange}
                placeholder="At least 6 characters"
                className={`${inputClass('password')} pr-10`}
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-600" aria-label="Toggle password visibility">
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {errors.password && <p className={errorText}>{errors.password}</p>}
          </div>

          {/* Confirm Password */}
          <div>
            <label className="mb-1 block text-sm font-semibold text-navy-700">Confirm Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              <input
                type={showPassword ? 'text' : 'password'}
                name="confirmPassword"
                value={form.confirmPassword}
                onChange={handleChange}
                placeholder="Re-enter your password"
                className={inputClass('confirmPassword')}
              />
            </div>
            {errors.confirmPassword && <p className={errorText}>{errors.confirmPassword}</p>}
          </div>

          <label className="flex cursor-pointer items-start gap-2 text-sm text-navy-600">
            <input type="checkbox" required className="mt-0.5 h-4 w-4 rounded border-navy-300 text-accent-500 focus:ring-accent-400" />
            <span>I agree to AutoNest's <a href="#" onClick={(e) => e.preventDefault()} className="font-medium text-accent-600">Terms</a> and <a href="#" onClick={(e) => e.preventDefault()} className="font-medium text-accent-600">Privacy Policy</a></span>
          </label>

          <button type="submit" className="btn-primary w-full">
            Create Account <ArrowRight size={18} />
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-navy-500">
          Already have an account?{' '}
          <Link to="/login" className="font-bold text-accent-600 hover:text-accent-700">Log in</Link>
        </p>

        <p className="mt-4 rounded-lg bg-navy-50 px-4 py-2.5 text-center text-xs text-navy-400">
          Demo project — no real authentication. Your account is stored locally only.
        </p>
      </div>
    </div>
  );
}
