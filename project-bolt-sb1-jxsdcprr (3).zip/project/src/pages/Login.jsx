import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Car, Mail, Lock, Eye, EyeOff, ArrowRight, X, CheckCircle2 } from 'lucide-react';
import { setUser } from '@/utils/storage';

export default function Login() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);
  const [forgotError, setForgotError] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: undefined });
  };

  const validate = () => {
    const errs = {};
    if (!form.email) {
      errs.email = 'Email or mobile number is required';
    } else {
      const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);
      const isMobile = /^[6-9]\d{9}$/.test(form.email.replace(/\s|-/g, ''));
      if (!isEmail && !isMobile) {
        errs.email = 'Enter a valid email or 10-digit mobile number';
      }
    }
    if (!form.password) {
      errs.password = 'Password is required';
    } else if (form.password.length < 6) {
      errs.password = 'Password must be at least 6 characters';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);
    if (isEmail) {
      setUser({
        name: form.email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
        email: form.email,
        joinedAt: new Date().toISOString(),
      });
    } else {
      setUser({
        name: 'User',
        mobile: form.email,
        email: '',
        joinedAt: new Date().toISOString(),
      });
    }
    navigate('/dashboard');
  };

  const handleForgotSubmit = (e) => {
    e.preventDefault();
    if (!forgotEmail) {
      setForgotError('Please enter your email address.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(forgotEmail)) {
      setForgotError('Enter a valid email address.');
      return;
    }
    setForgotError('');
    setForgotSent(true);
  };

  const closeForgot = () => {
    setShowForgot(false);
    setForgotSent(false);
    setForgotEmail('');
    setForgotError('');
  };

  const inputClass = (field) => `input-field pl-10 ${errors[field] ? 'border-red-400' : ''}`;
  const errorText = 'mt-1 text-xs font-medium text-red-500';

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-12 sm:px-6 lg:py-16">
      <div className="rounded-2xl bg-white p-8 shadow-card">
        <Link to="/" className="mb-6 flex items-center justify-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent-500 text-white">
            <Car size={22} strokeWidth={2.5} />
          </div>
          <span className="text-xl font-extrabold tracking-tight text-navy-900">
            Auto<span className="text-accent-500">Nest</span>
          </span>
        </Link>

        <h1 className="text-center text-2xl font-extrabold text-navy-900">Welcome Back</h1>
        <p className="mt-1 text-center text-sm text-navy-500">Log in to manage your listings and favorites.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="mb-1 block text-sm font-semibold text-navy-700" htmlFor="login-email">Email or Mobile Number</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              <input id="login-email" type="text" name="email" value={form.email} onChange={handleChange} placeholder="you@example.com or 9876543210" className={inputClass('email')} />
            </div>
            {errors.email && <p className={errorText}>{errors.email}</p>}
          </div>

          <div>
            <label className="mb-1 block text-sm font-semibold text-navy-700">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                value={form.password}
                onChange={handleChange}
                placeholder="Enter your password"
                className={`${inputClass('password')} pr-10`}
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-600" aria-label="Toggle password visibility">
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {errors.password && <p className={errorText}>{errors.password}</p>}
          </div>

          <div className="flex items-center justify-between text-sm">
            <label className="flex cursor-pointer items-center gap-2 text-navy-600">
              <input type="checkbox" className="h-4 w-4 rounded border-navy-300 text-accent-500 focus:ring-accent-400" />
              Remember me
            </label>
            <button type="button" onClick={() => setShowForgot(true)} className="font-medium text-accent-600 hover:text-accent-700">
              Forgot password?
            </button>
          </div>

          <button type="submit" className="btn-primary w-full">
            Log In <ArrowRight size={18} />
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-navy-500">
          Do not have an account?{' '}
          <Link to="/register" className="font-bold text-accent-600 hover:text-accent-700">Register here</Link>
        </p>

        <p className="mt-4 rounded-lg bg-navy-50 px-4 py-2.5 text-center text-xs text-navy-400">
          Demo project — no real authentication. Any email and password will work.
        </p>
      </div>

      {/* Forgot Password modal */}
      {showForgot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-navy-900/50 backdrop-blur-sm" onClick={closeForgot} />
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-xl">
            {forgotSent ? (
              <div className="text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                  <CheckCircle2 size={36} className="text-green-600" />
                </div>
                <h2 className="mt-4 text-lg font-bold text-navy-900">Reset Link Sent</h2>
                <p className="mt-2 text-sm text-navy-500">
                  A password reset link has been sent to <strong>{forgotEmail}</strong>. In this demo, no actual email is sent — please use any email and password to log in.
                </p>
                <button onClick={closeForgot} className="mt-6 btn-primary w-full">Got it</button>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-navy-900">Reset Password</h2>
                  <button onClick={closeForgot} className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-navy-50">
                    <X size={20} />
                  </button>
                </div>
                <p className="mt-2 text-sm text-navy-500">Enter your email and we will send you a password reset link.</p>
                {forgotError && <div className="mt-3 rounded-lg bg-red-50 px-4 py-2 text-sm font-medium text-red-700">{forgotError}</div>}
                <form onSubmit={handleForgotSubmit} className="mt-4 space-y-4">
                  <div>
                    <label className="mb-1 block text-sm font-semibold text-navy-700">Email</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
                      <input type="email" value={forgotEmail} onChange={(e) => { setForgotEmail(e.target.value); setForgotError(''); }} placeholder="you@example.com" className="input-field pl-10" />
                    </div>
                  </div>
                  <button type="submit" className="btn-primary w-full">Send Reset Link</button>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
