import { Link } from 'react-router-dom';
import { Home, Car, ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center justify-center px-4 py-20 text-center sm:py-28">
      <div className="text-8xl font-extrabold text-accent-500 sm:text-9xl">404</div>
      <h1 className="mt-4 text-2xl font-extrabold text-navy-900 sm:text-3xl">Page Not Found</h1>
      <p className="mt-3 max-w-md text-sm text-navy-500">
        The page you are looking for might have been moved, deleted, or never existed. Let's get you back on track.
      </p>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Link to="/" className="btn-primary">
          <Home size={18} /> Back to Home
        </Link>
        <Link to="/vehicles" className="btn-secondary">
          <Car size={18} /> Browse Cars
        </Link>
      </div>
    </div>
  );
}
