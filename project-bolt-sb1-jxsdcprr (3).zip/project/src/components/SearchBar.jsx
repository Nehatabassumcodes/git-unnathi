import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, ChevronDown } from 'lucide-react';
import { vehicleTypes, brands, cities } from '@/data/vehicles';

const budgetRanges = [
  { label: 'Under ₹5 Lakh', min: 0, max: 500000 },
  { label: '₹5–10 Lakh', min: 500000, max: 1000000 },
  { label: '₹10–20 Lakh', min: 1000000, max: 2000000 },
  { label: '₹20–40 Lakh', min: 2000000, max: 4000000 },
  { label: 'Above ₹40 Lakh', min: 4000000, max: 10000000 },
];

function Select({ label, value, onChange, options, allLabel }) {
  return (
    <div className="relative flex-1">
      <label className="mb-1 block text-xs font-semibold text-navy-500">{label}</label>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full cursor-pointer appearance-none rounded-xl border border-navy-200 bg-white py-3 pl-4 pr-10 text-sm font-medium text-navy-800 outline-none transition-all focus:border-accent-400 focus:ring-2 focus:ring-accent-100"
        >
          <option value="">{allLabel}</option>
          {options.map((opt) => (
            <option key={opt} value={opt}>
              {opt}
            </option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
      </div>
    </div>
  );
}

export default function SearchBar({ variant = 'hero' }) {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [type, setType] = useState('');
  const [brand, setBrand] = useState('');
  const [location, setLocation] = useState('');
  const [budget, setBudget] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (query) params.set('q', query);
    if (type) params.set('type', type);
    if (brand) params.set('brand', brand);
    if (location) params.set('location', location);
    if (budget) {
      const range = budgetRanges.find((b) => b.label === budget);
      if (range) {
        params.set('minPrice', range.min);
        params.set('maxPrice', range.max);
      }
    }
    navigate(`/vehicles?${params.toString()}`);
  };

  if (variant === 'hero') {
    return (
      <form onSubmit={handleSearch} className="w-full">
        {/* Main search input */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-400" size={20} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by brand, model, or location..."
            className="w-full rounded-2xl border border-navy-200 bg-white py-4 pl-12 pr-32 text-base text-navy-900 shadow-sm outline-none transition-all placeholder:text-navy-400 focus:border-accent-400 focus:ring-4 focus:ring-accent-100"
          />
          <button
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded-xl bg-accent-500 px-5 py-2.5 text-sm font-bold text-white transition-all hover:bg-accent-600 active:scale-95"
          >
            Search Cars
          </button>
        </div>

        {/* Quick filters */}
        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end">
          <Select label="Vehicle Type" value={type} onChange={setType} options={vehicleTypes} allLabel="All Types" />
          <Select label="Brand" value={brand} onChange={setBrand} options={brands} allLabel="All Brands" />
          <Select label="Location" value={location} onChange={setLocation} options={cities} allLabel="All Cities" />
          <Select label="Budget" value={budget} onChange={setBudget} options={budgetRanges.map((b) => b.label)} allLabel="Any Budget" />
        </div>
      </form>
    );
  }

  // Compact variant for listing page
  return (
    <form onSubmit={handleSearch} className="flex flex-col gap-3 sm:flex-row sm:items-end">
      <div className="relative flex-1">
        <label className="mb-1 block text-xs font-semibold text-navy-500">Search</label>
        <Search className="absolute left-3 top-[38px] text-navy-400" size={18} />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Brand, model, or location..."
          className="w-full rounded-xl border border-navy-200 bg-white py-3 pl-10 pr-4 text-sm outline-none focus:border-accent-400 focus:ring-2 focus:ring-accent-100"
        />
      </div>
      <Select label="Type" value={type} onChange={setType} options={vehicleTypes} allLabel="All" />
      <Select label="Brand" value={brand} onChange={setBrand} options={brands} allLabel="All" />
      <Select label="City" value={location} onChange={setLocation} options={cities} allLabel="All" />
      <button type="submit" className="btn-primary h-[46px] whitespace-nowrap">
        <Search size={18} />
        Search
      </button>
    </form>
  );
}
