import { Car } from 'lucide-react';

export default function LoadingSpinner({ label = 'Loading...', iconSize = 32 }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="relative">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-navy-50">
          <Car size={iconSize} className="text-navy-300" />
        </div>
        <div className="absolute inset-0 h-16 w-16 animate-spin rounded-full border-2 border-transparent border-t-accent-500" />
      </div>
      <p className="mt-4 text-sm font-medium text-navy-400">{label}</p>
    </div>
  );
}
