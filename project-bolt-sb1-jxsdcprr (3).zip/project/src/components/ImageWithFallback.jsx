import { useState } from 'react';
import { Car } from 'lucide-react';

export default function ImageWithFallback({ src, alt, className, iconSize = 28 }) {
  const [error, setError] = useState(false);

  if (error || !src) {
    return (
      <div className={`flex items-center justify-center bg-navy-100 ${className}`}>
        <Car size={iconSize} className="text-navy-300" />
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      className={className}
      loading="lazy"
      onError={() => setError(true)}
    />
  );
}
