import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Menu, X, Heart, GitCompare, Search, Car, User } from 'lucide-react';
import { getUser, removeUser } from '@/utils/storage';

const navItems = [
  { label: 'Buy Cars', path: '/vehicles' },
  { label: 'Sell Your Car', path: '/sell' },
  { label: 'Compare', path: '/compare' },
  { label: 'Favorites', path: '/favorites' },
  { label: 'Contact', path: '/contact' },
];

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileSearch, setMobileSearch] = useState('');
  const navigate = useNavigate();
  const user = getUser();

  const handleSearch = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (mobileSearch) params.set('q', mobileSearch);
    navigate(`/vehicles?${params.toString()}`);
    setMobileOpen(false);
    setMobileSearch('');
  };

  const handleLogout = () => {
    removeUser();
    setMobileOpen(false);
    navigate('/');
  };

  const linkClass = ({ isActive }) =>
    `text-sm font-medium transition-colors hover:text-accent-500 ${isActive ? 'text-accent-500' : 'text-navy-700'}`;

  return (
    <header className="sticky top-0 z-50 border-b border-navy-100 bg-white/90 backdrop-blur-md">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2" onClick={() => setMobileOpen(false)} aria-label="AutoNest home">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-accent-500 text-white">
            <Car size={20} strokeWidth={2.5} />
          </div>
          <span className="text-xl font-extrabold tracking-tight text-navy-900">
            Auto<span className="text-accent-500">Nest</span>
          </span>
        </Link>

        <div className="hidden items-center gap-7 lg:flex">
          {navItems.map((item) => (
            <NavLink key={item.path} to={item.path} className={linkClass}>
              {item.label}
            </NavLink>
          ))}
        </div>

        <div className="hidden items-center gap-3 lg:flex">
          {user ? (
            <>
              <Link to="/dashboard" className="btn-ghost" aria-label="Go to dashboard">
                <User size={18} /> Dashboard
              </Link>
              <button onClick={handleLogout} className="btn-secondary px-5 py-2.5">
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn-ghost">Login</Link>
              <Link to="/register" className="btn-primary px-5 py-2.5">Register</Link>
            </>
          )}
        </div>

        <button
          className="flex h-10 w-10 items-center justify-center rounded-lg text-navy-700 transition-colors hover:bg-navy-50 lg:hidden"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle navigation menu"
          aria-expanded={mobileOpen}
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {mobileOpen && (
        <div className="animate-fade-in border-t border-navy-100 bg-white lg:hidden">
          <div className="space-y-1 px-4 py-4 sm:px-6">
            <form onSubmit={handleSearch} className="relative mb-3" role="search">
              <label htmlFor="mobile-search" className="sr-only">Search cars</label>
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" size={18} />
              <input
                id="mobile-search"
                type="text"
                value={mobileSearch}
                onChange={(e) => setMobileSearch(e.target.value)}
                placeholder="Search by brand, model, or city..."
                className="w-full rounded-xl border border-navy-200 bg-navy-50 py-2.5 pl-10 pr-4 text-sm outline-none focus:border-accent-400"
              />
            </form>

            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setMobileOpen(false)}
                className={({ isActive }) =>
                  `block rounded-lg px-4 py-3 text-sm font-medium transition-colors hover:bg-navy-50 ${isActive ? 'bg-accent-50 text-accent-600' : 'text-navy-700'}`
                }
              >
                {item.label}
              </NavLink>
            ))}

            <div className="flex gap-3 pt-3">
              {user ? (
                <>
                  <Link to="/dashboard" onClick={() => setMobileOpen(false)} className="btn-secondary flex-1">
                    <User size={18} /> Dashboard
                  </Link>
                  <button onClick={handleLogout} className="btn-primary flex-1">Logout</button>
                </>
              ) : (
                <>
                  <Link to="/login" onClick={() => setMobileOpen(false)} className="btn-secondary flex-1">Login</Link>
                  <Link to="/register" onClick={() => setMobileOpen(false)} className="btn-primary flex-1">Register</Link>
                </>
              )}
            </div>

            <div className="flex gap-2 pt-2">
              <Link to="/favorites" onClick={() => setMobileOpen(false)} className="btn-ghost flex-1">
                <Heart size={18} /> Favorites
              </Link>
              <Link to="/compare" onClick={() => setMobileOpen(false)} className="btn-ghost flex-1">
                <GitCompare size={18} /> Compare
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
