import { Link } from 'react-router-dom';
import { Car, Facebook, Twitter, Instagram, Youtube, MapPin, Mail, Phone } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-navy-800 bg-navy-900 text-navy-300">
      {/* Main footer */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-accent-500 text-white">
                <Car size={20} strokeWidth={2.5} />
              </div>
              <span className="text-xl font-extrabold tracking-tight text-white">
                Auto<span className="text-accent-500">Nest</span>
              </span>
            </Link>
            <p className="mt-4 text-sm leading-relaxed text-navy-400">
              Find your next ride, for less. Quality cars. Better prices. A smarter way to buy and sell.
            </p>
            <div className="mt-5 flex gap-3">
              {[Facebook, Twitter, Instagram, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy-800 text-navy-400 transition-all hover:bg-accent-500 hover:text-white"
                  aria-label="Social link"
                >
                  <Icon size={17} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">Quick Links</h4>
            <ul className="mt-4 space-y-3 text-sm">
              <li><Link to="/vehicles" className="transition-colors hover:text-accent-400">Buy Cars</Link></li>
              <li><Link to="/sell" className="transition-colors hover:text-accent-400">Sell Your Car</Link></li>
              <li><Link to="/compare" className="transition-colors hover:text-accent-400">Compare</Link></li>
              <li><Link to="/favorites" className="transition-colors hover:text-accent-400">Favorites</Link></li>
              <li><Link to="/contact" className="transition-colors hover:text-accent-400">Contact</Link></li>
            </ul>
          </div>

          {/* About */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">About</h4>
            <ul className="mt-4 space-y-3 text-sm">
              <li><Link to="/" className="transition-colors hover:text-accent-400">About AutoNest</Link></li>
              <li><a href="#" onClick={(e) => e.preventDefault()} className="transition-colors hover:text-accent-400">Privacy Policy</a></li>
              <li><a href="#" onClick={(e) => e.preventDefault()} className="transition-colors hover:text-accent-400">Terms &amp; Conditions</a></li>
              <li><Link to="/dashboard" className="transition-colors hover:text-accent-400">Dashboard</Link></li>
            </ul>
          </div>

          {/* Contact info */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">Get in Touch</h4>
            <ul className="mt-4 space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin size={16} className="mt-0.5 flex-shrink-0 text-accent-500" />
                <span>Hi-Tech City, Hyderabad, Telangana 500081</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone size={16} className="flex-shrink-0 text-accent-500" />
                <span>+91 80000 12345</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail size={16} className="flex-shrink-0 text-accent-500" />
                <span>support@autonest.in</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-navy-800">
        <div className="mx-auto max-w-7xl px-4 py-5 sm:px-6 lg:px-8">
          <p className="text-center text-xs text-navy-500">
            © {new Date().getFullYear()} AutoNest. All rights reserved. Made in India.
          </p>
        </div>
      </div>
    </footer>
  );
}
