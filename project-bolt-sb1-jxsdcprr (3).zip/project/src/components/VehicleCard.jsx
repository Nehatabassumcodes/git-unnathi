import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, GitCompare, Fuel, Settings2, MapPin, Gauge, Eye } from 'lucide-react';
import { formatPrice, formatKm } from '@/data/vehicles';
import { toggleFavorite, isFavorite, toggleCompare, isCompared } from '@/utils/storage';
import ImageWithFallback from '@/components/ImageWithFallback';

export default function VehicleCard({ vehicle }) {
  const [fav, setFav] = useState(isFavorite(vehicle.id));
  const [compared, setCompared] = useState(isCompared(vehicle.id));
  const [compareError, setCompareError] = useState(null);

  const handleFav = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const updated = toggleFavorite(vehicle.id);
    setFav(updated.includes(vehicle.id));
  };

  const handleCompare = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const result = toggleCompare(vehicle.id);
    setCompared(result.list.includes(vehicle.id));
    setCompareError(result.error);
    if (result.error) {
      setTimeout(() => setCompareError(null), 3000);
    }
  };

  return (
    <div className="card group overflow-hidden hover:shadow-card-hover hover:-translate-y-1">
      {/* Image */}
      <div className="relative aspect-[16/10] overflow-hidden bg-navy-100">
        <Link to={`/vehicles/${vehicle.id}`} aria-label={`View details of ${vehicle.brand} ${vehicle.model} ${vehicle.variant}`}>
          <ImageWithFallback
            src={vehicle.images[0]}
            alt={`${vehicle.brand} ${vehicle.model} ${vehicle.variant} — ${vehicle.color} ${vehicle.year}`}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </Link>

        {/* Badges */}
        <div className="absolute left-3 top-3 flex gap-2">
          {vehicle.featured && (
            <span className="rounded-md bg-accent-500 px-2.5 py-1 text-xs font-bold text-white shadow-sm">
              Featured
            </span>
          )}
          <span className="rounded-md bg-navy-900/80 px-2.5 py-1 text-xs font-semibold text-white backdrop-blur-sm">
            {vehicle.year}
          </span>
        </div>

        {/* Favorite */}
        <button
          onClick={handleFav}
          className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 shadow-sm backdrop-blur-sm transition-all hover:scale-110 active:scale-95"
          aria-label={fav ? 'Remove from favorites' : 'Add to favorites'}
          aria-pressed={fav}
        >
          <Heart
            size={18}
            className={fav ? 'fill-accent-500 text-accent-500' : 'text-navy-600'}
          />
        </button>

        {/* Compare error toast */}
        {compareError && (
          <div className="absolute bottom-3 left-3 right-3 rounded-lg bg-red-600 px-3 py-2 text-center text-xs font-medium text-white shadow-md">
            {compareError}
          </div>
        )}
      </div>

      {/* Body */}
      <div className="p-4">
        <Link to={`/vehicles/${vehicle.id}`} className="block">
          <h3 className="truncate text-base font-bold text-navy-900 transition-colors group-hover:text-accent-600">
            {vehicle.brand} {vehicle.model}
          </h3>
          <p className="mt-0.5 truncate text-sm text-navy-500">{vehicle.variant}</p>
        </Link>

        {/* Specs */}
        <div className="mt-3 grid grid-cols-2 gap-y-2 text-xs text-navy-600">
          <span className="flex items-center gap-1.5">
            <Gauge size={14} className="text-navy-400" />
            {formatKm(vehicle.kilometers)}
          </span>
          <span className="flex items-center gap-1.5">
            <Fuel size={14} className="text-navy-400" />
            {vehicle.fuel}
          </span>
          <span className="flex items-center gap-1.5">
            <Settings2 size={14} className="text-navy-400" />
            {vehicle.transmission}
          </span>
          <span className="flex items-center gap-1.5">
            <MapPin size={14} className="text-navy-400" />
            {vehicle.city}
          </span>
        </div>

        {/* Price */}
        <div className="mt-3 flex items-end justify-between border-t border-navy-100 pt-3">
          <div>
            <p className="text-lg font-extrabold text-navy-900">{formatPrice(vehicle.price)}</p>
            <p className="text-xs text-navy-400">{vehicle.owners} Owner{vehicle.owners > 1 ? 's' : ''}</p>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-3 flex gap-2">
          <Link
            to={`/vehicles/${vehicle.id}`}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-navy-900 px-3 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-navy-800"
          >
            <Eye size={15} />
            View Details
          </Link>
          <button
            onClick={handleCompare}
            className={`flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2.5 text-xs font-semibold transition-all ${
              compared
                ? 'border-accent-500 bg-accent-50 text-accent-600'
                : 'border-navy-200 text-navy-700 hover:border-navy-300 hover:bg-navy-50'
            }`}
            aria-label={compared ? 'Remove from compare' : 'Add to compare'}
            aria-pressed={compared}
          >
            <GitCompare size={15} />
            Compare
          </button>
        </div>
      </div>
    </div>
  );
}
