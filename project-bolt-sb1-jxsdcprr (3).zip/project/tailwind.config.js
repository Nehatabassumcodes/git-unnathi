/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
      },
      colors: {
        navy: {
          50: '#f0f3f8',
          100: '#dce3ed',
          200: '#b8c6db',
          300: '#8ea3c2',
          400: '#5f7aa0',
          500: '#3f5a82',
          600: '#304468',
          700: '#273552',
          800: '#1e2942',
          900: '#161e33',
          950: '#0d1326',
        },
        accent: {
          50: '#fff5f0',
          100: '#ffe8db',
          200: '#ffcdb8',
          300: '#ffa885',
          400: '#ff7a4d',
          500: '#ff5722',
          600: '#f03e0e',
          700: '#c7300b',
          800: '#9f2810',
          900: '#802412',
        },
      },
      boxShadow: {
        card: '0 2px 8px -2px rgba(13, 19, 38, 0.08), 0 4px 16px -4px rgba(13, 19, 38, 0.06)',
        'card-hover': '0 8px 24px -4px rgba(13, 19, 38, 0.12), 0 16px 48px -8px rgba(13, 19, 38, 0.10)',
      },
      animation: {
        'fade-up': 'fadeUp 0.5s ease-out forwards',
        'fade-in': 'fadeIn 0.4s ease-out forwards',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};
