# AutoNest — Used Car Marketplace

A full-featured, responsive web application for browsing, comparing, buying, and selling used cars in India. Built with React, Vite, and Tailwind CSS. All data persists in the browser via localStorage — no backend required.

## Features

### Browsing & Search
- **36 vehicle listings** with full specs, photos, and seller details
- **Search** by brand, model, variant, city, or state
- **Filters** — vehicle type, brand, city, fuel type, transmission, year, and price range
- **Sorting** — newest, oldest, price (low/high), kilometers (low/high), year
- **Pagination** with smart page-button ellipsis for large result sets
- **No results state** with clear-all-filters action
- **Invalid price range detection** with dedicated error state

### Vehicle Details
- Multi-image gallery with thumbnail navigation
- Full specifications grid (year, kilometers, fuel, transmission, owners, color)
- Features & equipment checklist
- Related/similar cars section
- **Contact Seller** form with validation (name, email, phone, message) — saves enquiries to localStorage

### Favorites & Compare
- **Favorites** — save cars via heart icon, view on dedicated page, persisted in localStorage
- **Compare** — compare up to 4 cars side-by-side with a full spec table, persisted in localStorage
- Empty states with helpful calls-to-action

### Sell Vehicle
- Multi-section form: seller info, vehicle details, specifications, location, description
- **Photo upload** with drag-select, preview grid, cover badge, and remove buttons
- **Save Draft** — form state persists in localStorage for later continuation
- **Preview** screen — review the full listing before submitting
- **Submit** — listing saved to localStorage and visible in Dashboard
- Comprehensive validation (required fields, year ranges, price minimum, phone format, email format)

### Authentication (Demo)
- **Register** — name, email, mobile, city, password + confirm password with per-field validation
- **Login** — email/password validation, forgot-password demo modal
- Session stored in localStorage; navbar adapts to login state

### Dashboard
- Profile header with joined date, mobile, and city
- Stats cards (favorites, comparing, listings, enquiries)
- Quick action shortcuts
- **My Listings** — view and delete submitted listings
- **Enquiries** — track all contact-seller submissions, delete individual enquiries
- **Favorites & Compare previews** with links to full pages
- **Edit Profile** — update name, email, mobile, city with validation

### Contact Page
- Contact info cards (address, phone, email, hours)
- Contact form with per-field validation and toast notifications

### UI/UX & Accessibility
- Responsive design — mobile, tablet, and desktop layouts
- Mobile hamburger menu with working search
- Mobile filter drawer with backdrop overlay
- Loading spinner states on all data pages
- Broken image fallback with car icon placeholder
- Toast notification system
- Keyboard-friendly focus-visible outlines
- Proper form labels (`htmlFor`/`id` associations)
- ARIA attributes on interactive elements (`aria-label`, `aria-expanded`, `aria-current`, `aria-pressed`, `aria-invalid`)
- Screen-reader-only labels on icon-only controls
- 404 page with navigation back to home and browse

## Technologies

| Technology | Purpose |
|---|---|
| React 18 | UI framework |
| Vite 5 | Build tool & dev server |
| React Router 6 | Client-side routing |
| Tailwind CSS 3 | Utility-first styling |
| Lucide React | Icon library |
| localStorage | Data persistence (favorites, compare, listings, enquiries, user session, drafts) |

## Setup & Run

### Prerequisites
- Node.js 18+ and npm

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

The app runs at `http://localhost:5173`.

### Build

```bash
npm run build
```

Output is in the `dist/` directory.

### Lint

```bash
npm run lint
```

### Type Check

```bash
npm run typecheck
```

## Routes

| Route | Page | Description |
|---|---|---|
| `/` | Home | Hero search, categories, featured & recent cars, brands, testimonials, sell CTA |
| `/vehicles` | Browse Cars | Search, filters, sorting, pagination, vehicle grid |
| `/vehicles/:id` | Vehicle Details | Gallery, specs, features, contact seller, related cars |
| `/sell` | Sell Vehicle | Multi-section listing form with draft, preview, and submit |
| `/favorites` | Favorites | Saved favorite vehicles with remove option |
| `/compare` | Compare | Side-by-side comparison of up to 4 cars |
| `/login` | Login | Email/password form with forgot-password modal |
| `/register` | Register | Name, email, mobile, city, password with validation |
| `/dashboard` | Dashboard | Profile, stats, listings, enquiries, favorites/compare previews |
| `/contact` | Contact | Contact info and validated contact form |
| `*` | 404 | Not found page with navigation links |

## Screenshots

<!-- Add screenshots here after running the app -->

### Home Page
![Home Page](screenshots/home.svg)

### Browse Cars
![Browse Cars](screenshots/vehicles.svg)

### Vehicle Details
![Vehicle Details](screenshots/vehicle-details.svg)

### Sell Vehicle Form
![Sell Vehicle](screenshots/sell.svg)

### Compare Cars
![Compare](screenshots/compare.svg)

### Dashboard
![Dashboard](screenshots/dashboard.svg)

### Mobile Responsive
![Mobile](screenshots/mobile.svg)

## Project Structure

```
src/
├── components/
│   ├── Footer.jsx
│   ├── ImageWithFallback.jsx   # Broken image placeholder
│   ├── LoadingSpinner.jsx      # Animated loading state
│   ├── Navbar.jsx              # Responsive nav with hamburger menu
│   ├── SearchBar.jsx           # Hero & compact search variants
│   ├── Toast.jsx               # Toast notification provider
│   └── VehicleCard.jsx         # Reusable vehicle card
├── data/
│   └── vehicles.js             # 36 vehicle records + helpers
├── pages/
│   ├── Compare.jsx
│   ├── Contact.jsx
│   ├── Dashboard.jsx
│   ├── Favorites.jsx
│   ├── Home.jsx
│   ├── Login.jsx
│   ├── NotFound.jsx
│   ├── Register.jsx
│   ├── SellVehicle.jsx
│   ├── VehicleDetails.jsx
│   └── Vehicles.jsx
├── utils/
│   └── storage.js              # localStorage helpers
├── App.jsx                     # Routes + ToastProvider
├── index.css                   # Tailwind + custom styles
└── main.jsx                    # Entry point
```

## Data Persistence

All data is stored in the browser's localStorage:

| Key | Content |
|---|---|
| `favoriteVehicles` | Array of favorited vehicle IDs |
| `compareVehicles` | Array of vehicle IDs in comparison |
| `userData` | Current user session object |
| `autonest_enquiries` | Contact seller enquiry submissions |
| `sellerListings` | User-submitted vehicle listings |
| `autonest_sell_draft` | Saved draft of the sell vehicle form |
